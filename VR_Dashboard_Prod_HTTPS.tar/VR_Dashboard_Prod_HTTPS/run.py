from app import create_app
import os

app = create_app('prod')

if __name__ == "__main__":
    cert = os.path.join(app.config.get('BASE_DIR'), 'cert.pem')
    key = os.path.join(app.config.get('BASE_DIR'), 'key.pem')
    app.run(host='0.0.0.0', port=443, ssl_context=(cert, key))

