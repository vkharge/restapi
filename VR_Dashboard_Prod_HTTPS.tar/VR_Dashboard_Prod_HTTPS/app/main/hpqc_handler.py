from xml.dom import minidom
from math import ceil
import requests
import urllib3
from collections import OrderedDict
import time


def get_node_data(node):
    if len(node.childNodes) == 0:
        result = None
    else:
        result = node.firstChild.data
    return result


def task(params, arr, index):
    totalResults = get_testcases_count(url_get_test_cases, params)
    arr[index] = totalResults


def get_test_cases_count(testset_id):
    test_case_statuses = OrderedDict({"Passed": 0, "Failed": 0, "No Run": 0, "Blocked": 0, "N/A": 0, "Not Completed": 0,
                                      "Running": 0})

    for test_status in test_case_statuses.keys():
        # print('For Test Status :', test_status)
        params = {'filter': '{cycle-id[' + str(testset_id) + ']; status["' + test_status + '"]}',
                  'fields': 'id,status',
                  'page-size': MAX_PAGE_SIZE, 'page-number': 1}
        totalResults = get_testcases_count(url_get_test_cases, params)
        test_case_statuses[test_status] = totalResults

    test_case_statuses["Total"] = sum(test_case_statuses.values())
    test_case_statuses["Execution %"] = round(
        ((test_case_statuses["Passed"] + test_case_statuses["Failed"]) / test_case_statuses["Total"]) * 100, 2) if \
    test_case_statuses["Total"] != 0 else 0
    test_case_statuses["Pass %"] = round((test_case_statuses["Passed"] / test_case_statuses["Total"]) * 100, 2) \
        if test_case_statuses["Total"] != 0 else 0

    # print("Pass %", test_case_statuses["Pass %"])
    return test_case_statuses


def get_test_cases_using_testset_id(testset_id):
    params = {'filter': '{cycle-id[' + str(testset_id) + ']}', 'fields': 'test.name,id,status',
              'page-size': MAX_PAGE_SIZE, 'page-number': 1}
    elements, pageNumber, totalResults, totalPages = get_hpqc_test_cases(url_get_test_cases, params)

    # print(pageNumber, totalPages, len(elements))
    # Handling Pagination Cases
    while pageNumber < totalPages:
        params['page-number'] += 1
        temp_elements, pageNumber, X, Y = get_hpqc_test_cases(url_get_test_cases, params)
        elements = {**elements, **temp_elements}
        # print(pageNumber, totalPages, len(elements))

    # print('Total Test Cases :', len(elements), totalResults)
    if len(elements) == int(totalResults):
        return elements
    else:
        raise Exception("Number of elements and total Entities does not match")


def get_hpqc_folders(element_id):
    params = {'filter': '{parent-id[' + str(element_id) + ']}', 'page-size': MAX_PAGE_SIZE, 'page-number': 1}
    folder_elements, folder_total_count, pageNumber, totalPages = get_hpqc_folder_data(url_get_test_folders, params)
    # Handling Pagination Cases
    while pageNumber < totalPages:
        params['page-number'] += 1
        temp_folder_elements, X, pageNumber, Y = get_hpqc_folder_data(url_get_test_folders, params)
        folder_elements.extend(temp_folder_elements)

    if len(folder_elements) == folder_total_count:
        return folder_elements, folder_total_count


def get_hpqc_testsets(element_id):
    params = {'filter': '{parent-id[' + str(element_id) + ']}', 'page-size': MAX_PAGE_SIZE, 'page-number': 1}
    test_suite_elements, test_suite_count, pageNumber, totalPages = \
        get_hpqc_folder_data(url_get_test_sets, params, True)

    # Handling Pagination Cases
    while pageNumber < totalPages:
        params['page-number'] += 1
        temp_elements, X, pageNumber, Y = get_hpqc_folder_data(url_get_test_sets, params, True)
        test_suite_elements.extend(temp_elements)

    if len(test_suite_elements) == test_suite_count:
        return test_suite_elements, test_suite_count


def get_hpqc_folder_data_using_id(element_id):
    element_id = int(element_id)
    folder_elements, folder_total_count = get_hpqc_folders(element_id)
    test_suite_elements, test_suite_count = get_hpqc_testsets(element_id)

    dataelements = test_suite_elements + folder_elements

    if len(dataelements) == folder_total_count + test_suite_count:
        return dataelements, test_suite_count + folder_total_count
    else:
        raise Exception("Number of test folder elements and total Entities does not match")


def get_hpqc_folder_data_using_name(name):
    params = {'filter': '{name[' + name + ']}', 'page-size': MAX_PAGE_SIZE, 'page-number': 1}
    elements, totalResults, pageNumber, totalPages = get_hpqc_folder_data(url_get_test_folders, params)
    # print(pageNumber, totalPages, len(elements))
    # Handling Pagination Cases
    while pageNumber < totalPages:
        params['page-number'] += 1
        temp_elements, X, pageNumber, Y = get_hpqc_folder_data(url_get_test_folders, params)
        elements.extend(temp_elements)
        # print("For Test Folder Data Using Name", pageNumber, totalPages, len(temp_elements))

    # print('Total Folders by Name :', len(elements))
    if len(elements) == totalResults:
        return elements, totalResults
    else:
        raise Exception("Number of test folder elements using Name and total Entities does not match")


def get_hpqc_folder_data(given_url, params, isSuite=False):
    response = requests.get(given_url, params=params, headers=headers, verify=False)

    print(response.status_code)
    # print(response.url)

    mydoc = minidom.parseString(response.text)
    master_record = mydoc.getElementsByTagName("Entities")[0]
    records = mydoc.getElementsByTagName("Entity")

    # print(master_record, type(master_record), '\n\n')

    totalResults = int(master_record.attributes.get('TotalResults').value)
    pageSize = int(master_record.attributes.get('PageSize').value)
    pageNumber = int(master_record.attributes.get('PageNumber').value)

    # print('TotalResults: {}, PageSize: {}, PageNumber: {}'.format(totalResults, pageSize, pageNumber))

    elements = []
    for rec in records:
        type_of_record = rec.attributes['Type'].value
        element_id = get_node_data(rec.getElementsByTagName('Value')[0])
        parentId = get_node_data(rec.getElementsByTagName('Value')[1])

        status = ''

        if isSuite:
            status = get_node_data(rec.getElementsByTagName('Value')[2])
            name = get_node_data(rec.getElementsByTagName('Value')[3])
            testLabPath = get_node_data(rec.getElementsByTagName('Value')[4])
        else:
            name = get_node_data(rec.getElementsByTagName('Value')[2])
            testLabPath = get_node_data(rec.getElementsByTagName('Value')[3])

        element = {'type': type_of_record, 'id': element_id, 'parentId': parentId, 'name': name,
                   'testLabPath': testLabPath, 'status': status}
        elements.append(element)
        # print(element)

    totalPages = ceil(totalResults / pageSize) if totalResults > pageSize else 1

    return elements, totalResults, pageNumber, totalPages


def get_hpqc_test_cases(given_url, params):
    response = requests.get(given_url, params=params, headers=headers, verify=False)

    # print(response.status_code)
    # print(response.url)

    mydoc = minidom.parseString(response.text)
    master_record = mydoc.getElementsByTagName("Entities")[0]
    records = mydoc.getElementsByTagName("Entity")
    valid_records = []

    # print('len of records', len(records))

    for record in records:
        if record.attributes.get('Type').value == 'test-instance':
            valid_records.append(record)

    # print('len of valid records', len(valid_records))
    # print(master_record, type(master_record), '\n\n')

    totalResults = int(master_record.attributes.get('TotalResults').value)
    pageSize = int(master_record.attributes.get('PageSize').value)
    pageNumber = int(master_record.attributes.get('PageNumber').value)

    # print('TotalResults: {}, PageSize: {}, PageNumber: {}'.format(totalResults, pageSize, pageNumber))
    elements = {}
    for rec in valid_records:
        type_of_record = rec.attributes['Type'].value
        fields = rec.getElementsByTagName('Fields')[0]
        relatedEntities = rec.getElementsByTagName('Fields')[1]

        data = {}
        for field in fields.getElementsByTagName('Field'):
            key = field.getAttribute('Name')
            value = get_node_data(field.getElementsByTagName('Value')[0])

            if key in ['id', 'status']:
                data[key] = value

        for field in relatedEntities.getElementsByTagName('Field'):
            key = field.getAttribute('Name')
            value = get_node_data(field.getElementsByTagName('Value')[0])

            if key == 'id':
                data['testcase_id'] = value
            elif key == 'name':
                data[key] = value

        if len(data) != 4:
            raise Exception("XML data is incorrect")


        # print(data)

        if elements.get(data['name']):
            totalResults -= 1

        elements[data['name']] = data

    totalPages = ceil(totalResults / pageSize) if totalResults > pageSize else 1

    return elements, pageNumber, totalResults, totalPages


def update_passed_testcases(testSetDbId, testerName, buildNumber, testCaseIds):
    params = {
        'tester': testerName,
        'testInstanceIDs': ','.join(testCaseIds),
        'status': 'Passed',
        'build': buildNumber,
        'runName': testSetDbId
    }
    response = requests.post(url_update_test_status_passed, params=params, headers=headers, verify=False)

    print(response.status_code)
    print(response.url)
    print(response.text)

    assert response.status_code == 201


def update_failed_testcase(testSetDbId, testerName, buildNumber, testCaseId, bugIds):
    params = {
        'tester': testerName,
        'testInstanceID': testCaseId,
        'status': 'Failed',
        'build': buildNumber,
        'runName': testSetDbId,
        'bugIDs': bugIds
    }
    response = requests.post(url_update_test_status_failed, params=params, headers=headers, verify=False)

    print(response.status_code)
    print(response.url)
    print(response.text)

    assert response.status_code == 201


def get_testcases_count(given_url, params):
    response = requests.get(given_url, params=params, headers=headers, verify=False)

    # print(response.status_code)
    # print(response.url)
    # print(response.text)

    mydoc = minidom.parseString(response.text)
    master_record = mydoc.getElementsByTagName("Entities")[0]

    totalResults = int(master_record.attributes.get('TotalResults').value)

    return totalResults


urllib3.disable_warnings()

url_get_test_folders = \
    'https://quality-api.eng.vmware.com/QCIntgr2/rest/rest.php/domains/SOLUTIONS/projects/CINS/test-set-folders'
url_get_test_sets = \
    'https://quality-api.eng.vmware.com/QCIntgr2/rest/rest.php/domains/SOLUTIONS/projects/CINS/test-sets'
url_get_test_cases = \
    'https://quality-api.eng.vmware.com/QCIntgr2/rest/rest.php/domains/SOLUTIONS/projects/CINS/test-instances'
url_update_test_status_failed = 'https://quality-api.eng.vmware.com:8443/QCIntgrt/rest/SOLUTIONS/CINS/run'
url_update_test_status_passed = 'https://quality-api.eng.vmware.com:8443/QCIntgrt/rest/SOLUTIONS/CINS/runs'

root_names = ['NSX-Transformers', 'NSXv-TestLabs']
root_id = 320
MAX_PAGE_SIZE = 1000

headers = {
    'APIKey': '0QtXw0uiqtMu2xfMreui0IKNpHxxSZ1S',
    'Content-Type': 'application/xml',
    'Accept': 'application/xml'
}

if __name__ == '__main__':
    sTime = time.time()
    folder_elements, folder_total_count = get_hpqc_testsets(7986)#(16358)
    print(folder_total_count)
    [print(i) for i in folder_elements]
    print("Takes Time -", time.time() - sTime)
