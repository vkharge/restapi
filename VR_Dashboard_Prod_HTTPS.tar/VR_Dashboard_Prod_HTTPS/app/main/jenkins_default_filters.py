from app.models import JenkinsBranches
from app import db


def delete_branch(branch_name):
    record = JenkinsBranches.query.filter(JenkinsBranches.branch == branch_name).first()
    if record:
        db.session.delete(record)
        db.session.commit()


def add_branch(branch_name):
    record = JenkinsBranches(branch_name)
    db.session.add(record)
    db.session.commit()


def get_branches_from_db():
    data = JenkinsBranches.query.all()
    print('Jenkins_Branches Data :', data)
    return data


def get_branch_names_list():
    data = get_branches_from_db()
    branch_names = [record.branch for record in data]
    return branch_names
