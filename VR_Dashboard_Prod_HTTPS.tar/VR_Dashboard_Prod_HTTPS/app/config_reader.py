import configparser
import os

parser = configparser.ConfigParser()
BASE_DIR = os.environ.get('BASE_DIR')
parser.read(os.path.join(BASE_DIR, 'app', 'config-properties.ini'))
print("Config has sections - ", parser.sections())


def get_dashboard_config():
    return parser["Dashboard-Config"]


def get_db_config():
    return parser["Database-Config"]


def get_jenkins_config():
    return parser["Jenkins-Config"]


def get_buildweb_config():
    return parser["Buildweb-Config"]

