$(document).ready(function () {

    // Initialize tooltip component
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
    
    // Initialize popover component
    $(function () {
        $('[data-toggle="popover"]').popover()
    })


    $('table.selectabletable').DataTable({
        "pageLength": -1,
        "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]]
    });

    $('.bugcolumn').css("display","none");
    $('.hpqcstatuscolumn').css("display", "none");


    // JS Tree Code
    $('#hpqctree').jstree({
        'core':{
            'multiple': false,

            'data' : {
                'url' : '/gethpqctestfoldersdata',
                'data' : function (node) {
                    return { 'id' : node.id };
                }
            }
        }
    });


    $('#hpqctree').on("changed.jstree", function (e, data) {
        $('#dvLoading').fadeIn(300);

        id_of_selected_test_set = data.selected[0];
        name_of_selected_test_set = $('#' + data.selected[0]).attr('name');
        selected_element = $('#' + data.selected[0]);
        isTestSet = selected_element.hasClass( "test-set" );
        // console.log(id_of_selected_test_set);
        // console.log(name_of_selected_test_set);
        // console.log(isTestSet);

        // console.log($('.hpqctestset').val());
        // console.log($('.hpqctestset').attr('name'));
        // console.log($('.hpqctestset').attr('id'));
        $('#alerts').closest('div').html('<p id="alerts" aria-hidden="true"></p>');
        
        if (isTestSet) {
            $('.hpqctestset').val(name_of_selected_test_set);
            $('.hpqctestset').attr('name', name_of_selected_test_set);
            $('.hpqctestset').attr('id', id_of_selected_test_set);
            $('.hpqctestset').css('border', '1px solid green');
            $('.hpqctestset').css('background-color', '#dff0d8');
            $('.bugcolumn').css("display","table-cell");
            $('.hpqcstatuscolumn').css("display", "table-cell");
            $('.selectabletable tbody .bugId').val("");
            $('.selectabletable tbody .hpqcstatuscolumn').text("");
            $('#updatebtn').prop("disabled", false);

           $.getJSON("/gethpqctestcasedata", {'id' : id_of_selected_test_set },
               function (data, textStatus, jqXHR) {
                    e.preventDefault();
                    // console.log(data);
                    testNames = $('.testname');
                    total_tests_in_run = testNames.length - 1;
                    match_count = 0;
                    testNames.each(function (index, value) { 
                        tdElement = $(this);
                        suiteTestName = $(this).text();
                        if(data.hasOwnProperty(suiteTestName)){
                            // console.log('Exist');
                            match_count += 1
                            hpqcStatus = data[suiteTestName]['status']
                            // console.log(hpqcStatus);
                            tdElement.siblings('.hpqcstatuscolumn').text(hpqcStatus);
                            tdElement.siblings('.hpqcstatuscolumn').attr('id', data[suiteTestName]['id']);
                        }
                        // console.log($(this).text());

                    });
                    var msg = match_count + ' testcases are present in HPQC out of ' + total_tests_in_run;
                    create_warning_alert(msg);
                    $('#modalInfoText').html(msg);
                    $('#dvLoading').fadeOut(1000);
                    $('#myInfoModal').modal('show');
                    
                    var collection = $('.hpqcstatuscolumn:empty');
                    alert(collection.length);
                    collection.each(function() {
                        // console.log(this);
                        rowToHide = $(this).parent();
                        // console.log(rowToHide);
                        rowToHide.hide();
                    });

                    var collection = $('.hpqcstatuscolumn:not(:empty)');
                    alert(collection.length);
                    collection.each(function() {
                        // console.log(this);
                        rowToHide = $(this).parent();
                        // console.log(rowToHide);
                        rowToHide.show();
                    });
               }
           );

        } else {
            $('.hpqctestset').val('');
            $('.hpqctestset').removeAttr('name');
            $('.hpqctestset').removeAttr('id');
            $('.hpqctestset').css('border', '1px solid red');
            $('.hpqctestset').css('background-color', '');
            $('.bugcolumn').css("display","none");
            $('.hpqcstatuscolumn').css("display", "none");
            $('.selectabletable tbody .hpqcstatuscolumn').text("");
            $('.selectabletable tbody .bugId').val("");
            $('.hpqcstatuscolumn').removeAttr("id");
            $('#updatebtn').prop("disabled", true);

            $('#dvLoading').fadeOut(1000);
        }

        
        
      });


      $('#updatebtn').click(function (e) {
        $('#testerName').val('');
        $('#alerts').closest('div').html('<p id="alerts" aria-hidden="true"></p>');
      });


      $('#gotTesterName').click(function (e) { 
          e.preventDefault();
          testerName = $('#testerName').val();
          if (testerName === ""){
              create_danger_alert('Tester Name Cannot Be Blank !');
              $('#myModal').modal('hide');
              return 0;
          }
          else if(testerName.length < 5){
                create_danger_alert('Tester Name Cannot Be less than 5 characters !');
                $('#myModal').modal('hide');
                return 0;
          }

          $('#myModal').modal('hide');

          $('#dvLoading').fadeIn(300);

          var selected_rows = $('.selectabletable tbody tr').filter(".info");
          no_of_rows_selected = selected_rows.length;
          if (no_of_rows_selected == 0){
                create_danger_alert('Please select atleast 1 testcase to update in HPQC');
                $('#dvLoading').fadeOut(1000);
                return 0;
          }

        //   console.log(selected_rows.length);

          var updateHpqcData = [];

          errorFlag = false;

          selected_rows.each(function (index, value) {
            //    console.log(index, $(this));
               var hpqcStatusColumn = $(this).children('.hpqcstatuscolumn');
               var testStatus = $(this).children('.teststatus').text();
               var testCaseId = hpqcStatusColumn.attr("id");
               var hpqcStatus = hpqcStatusColumn.text();
               var testName = $(this).children('.testname').text();
               
            //    console.log('testStatus : '+ testStatus);
            //    console.log('testCaseId :' + testCaseId);
            //    console.log('hpqcStatus :' + hpqcStatus);
            //    console.log('testName :' + testName);

               if(hpqcStatus == ''){
                    create_warning_alert('TestCase - ' + testName + ' does not exist in HPQC, It will be ignored.');
                    // console.log(testName + ' - This testcase does not exist in HPQC, It will be ignored.');
               }
               else{
                   testCaseData = {'testName': testName, 'testStatus': testStatus, 'testCaseId': testCaseId }
                   if(testStatus === 'FAILED'){
                        bugId = $(this).children('.bugcolumn').children('.bugId').val();
                        if(bugId === ""){
                            create_danger_alert('BugId cannot be left blank for TestCase - ' + testName);
                            $('#dvLoading').fadeOut(1000);
                            errorFlag = true;
                            return 0;
                        }
                        else if(bugId.length < 5){
                            create_danger_alert('BugId cannot be less than 5 digits for TestCase - ' + testName);
                            $('#dvLoading').fadeOut(1000);
                            errorFlag = true;
                            return 0;
                        }
                        // console.log('bugId :' + bugId);
                        testCaseData['bugId'] = bugId;
                   }
                //    console.log('Updating HPQC for testcase - '+ testName);
                   updateHpqcData.push(testCaseData);
               }
               
          });

        if(errorFlag != true){

            // console.log(updateHpqcData);

            var testSetDbId = getUrlVars()["id"];
            var featureName = $('#featureName').text();
            var buildNumber = $('#buildNumber').text();

            formData = {
                'formData' : updateHpqcData, 
                'testSetDbId': testSetDbId, 
                'featureName': featureName,
                'testerName': testerName,
                'buildNumber': buildNumber
            }

            $.ajax({
                type: "post",
                url: "/updatehpqc",
                data: JSON.stringify(formData),
                contentType: "application/json; charset=utf-8",
                success: function (response) {
                        create_success_alert('<b>Congratulations !!! </b> HPQC Updated Successfully.')

                        $.getJSON("/gethpqctestcasedata", {'id' : $('.hpqctestset').attr('id') },
                        function (data, textStatus, jqXHR) {
                            e.preventDefault();
                            // console.log(data);
                            testNames = $('.testname');
                            
                            testNames.each(function (index, value) { 
                                tdElement = $(this);
                                suiteTestName = $(this).text();
                                if(data.hasOwnProperty(suiteTestName)){
                                    hpqcStatus = data[suiteTestName]['status'];
                                    tdElement.siblings('.hpqcstatuscolumn').text(hpqcStatus);
                                    tdElement.siblings('.hpqcstatuscolumn').attr('id', data[suiteTestName]['id']);
                                }
        
                            });
                        });

                    $('#dvLoading').fadeOut(1000);
                },
                error: function(data) {
                    console.log(data);
                    console.log("Error" + data['responseText']);
                    create_danger_alert('HPQC Update Failed !!! Are You Sure You gave the tester name correct ?');
                    create_danger_alert('Error: '+ data['responseText']);
                    $('#dvLoading').fadeOut(1000);
                },
            });
        }

      });

      $('.bugId').click(function (e) { 
          e.preventDefault();
          e.stopPropagation();   
      });

      $('.bugId').focus(function (e) { 
            e.preventDefault();
            e.stopPropagation();
      });

      $('.selectabletable tbody').on('click', 'tr', function(e){
        var $tr = $(this);
        var $table = $tr.closest('.table');
        var our_index = $($tr,$table).index();
        $('.selectionbtn').removeClass('active');

        if (e.shiftKey) {
            var last_index = $table.data('last-index');
            if (last_index) {
                if (last_index < our_index) {
                    while(last_index < our_index) {
                        $('tbody tr:eq('+(++last_index)+')', $table).click();
                    }   
                    $('tbody tr:eq('+(last_index)+')', $table).click();
                } else {  
                    while(last_index > our_index) {
                        $('tbody tr:eq('+(--last_index)+')', $table).click();
                    }
                    $('tbody tr:eq('+(last_index)+')', $table).click();
                } 
            }
            $table.data('last-index',our_index);
        } else {
            $table.data('last-index',our_index);
        }
        
        if ($tr.hasClass('info')) {
            $tr.removeClass('info');
        } else {
            $tr.addClass('info');
        }
    });

    $('.selectionbtn').click(function (e) { 
        e.preventDefault();
        $(this).addClass('active').siblings().removeClass('active');
        var selectedButtonName = $(this).attr('name');
        // console.log(selectedButtonName);
        // allRows = $('.selectabletable tbody tr');
        allRows = $('.selectabletable tbody tr').filter(function( index ) {
             col = $(this).children('.hpqcstatuscolumn').text();
             return col != '';
        });
        if(selectedButtonName === "all"){
            allRows.addClass('info');
        }else if(selectedButtonName === "none"){
            allRows.removeClass('info');
        }else if(selectedButtonName === "passed"){
            allRows.removeClass('info');
            allRows.each(function (index, value) { 
                status = $(this).children('.teststatus').text();
                // console.log(index + ":" + status);
                // console.log($(this));
                if(status === "PASSED"){
                    $(this).addClass('info')
                } 
            });
        }else if(selectedButtonName === "failed"){
            allRows.removeClass('info');
            allRows.each(function (index, value) { 
                status = $(this).children('.teststatus').text();
                if(status === "FAILED"){
                    $(this).addClass('info')
                } 
            });
        }

    });


    function create_warning_alert(msg) {
        $('#alerts').before(
            '<div class="alert alert-warning alert-dismissable">'+
                '<button type="button" class="close" ' + 
                        'data-dismiss="alert" aria-hidden="true">' + 
                    '&times;' + 
                '</button>' + 
                msg + 
             '</div>');     
    }

    function create_success_alert(msg) {
        $('#alerts').before(
            '<div class="alert alert-success alert-dismissable">'+
                '<button type="button" class="close" ' + 
                        'data-dismiss="alert" aria-hidden="true">' + 
                    '&times;' + 
                '</button>' + 
                msg + 
             '</div>');     
    }

    function create_danger_alert(msg) {
        $('#alerts').before(
            '<div class="alert alert-danger alert-dismissable">'+
                '<button type="button" class="close" ' + 
                        'data-dismiss="alert" aria-hidden="true">' + 
                    '&times;' + 
                '</button>' + 
                msg + 
             '</div>');     
    }

    function getUrlVars()
    {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for(var i = 0; i < hashes.length; i++)
        {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    }
});