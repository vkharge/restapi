
$(document).ready(function() {

    timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    console.log('TimeZone : ' + timeZone);

    branch_default = $('.filter form #branch_default').html();
    feature_default = $('.filter form #feature_default').html();
    start_date = $('.filter form #start_date').val();
    end_date = $('.filter form #end_date').val();

    // JS Tree Code
    $('#hpqctree').jstree({
        'core':{
            'multiple': false,

            'data' : {
                'url' : '/gethpqctestfoldersdataforreport',
                'data' : function (node) {
                    return { 'id' : node.id };
                }
            }
        }
    });

    $("#home_content").on("click", ".rerun_failed", function(e){
        e.preventDefault();
        $('#dvLoading').fadeIn(300);
        id = $(this).attr('id');
        // alert("Inside modal with id "+ id)
        $('#run_failed_jobs_modal #run_suiteid').html(id);

        $.ajax({
            type: "GET",
            url: "/getbuilds",
            data: { "id": id },
            success: function (response) {
                
                $('#run_failed_jobs_modal #run_feature').html(response.feature);

                if(response.nsxbuild){
                    $('#run_failed_jobs_modal #run_nsxbuild').val(response.nsxbuild);
                    $('#run_failed_jobs_modal #run_nsxbuild_component').show();
                }else{
                    $('#run_failed_jobs_modal #run_nsxbuild').val('');
                    $('#run_failed_jobs_modal #run_nsxbuild_component').hide();
                }

                if(response.esxbuild){
                    $('#run_failed_jobs_modal #run_esxbuild').val(response.esxbuild);
                    $('#run_failed_jobs_modal #run_esxbuild_component').show();
                }else{
                    $('#run_failed_jobs_modal #run_esxbuild').val('');
                    $('#run_failed_jobs_modal #run_esxbuild_component').hide();
                }

                if(response.vcbuild){
                    $('#run_failed_jobs_modal #run_vcbuild').val(response.vcbuild);
                    $('#run_failed_jobs_modal #run_vcbuild_component').show();
                }else{
                    $('#run_failed_jobs_modal #run_vcbuild').val('');
                    $('#run_failed_jobs_modal #run_vcbuild_component').hide();
                }

                $('#run_failed_jobs_modal').modal('show');     
                $('#dvLoading').fadeOut(300);
            },
            error: function(data) {
                console.log("Error" + data['responseText']);
                $('#dvLoading').fadeOut(300);
            },
        });

    });

    $('#gobtn').prop("disabled", true);

    $('#hpqctree').on("changed.jstree", function (e, data) {

        id_of_selected_test_set = data.selected[0];
        name_of_selected_test_set = $('#' + data.selected[0]).attr('name');
        selected_element = $('#' + data.selected[0]);
        isTestSet = selected_element.hasClass( "test-set");
        // console.log(id_of_selected_test_set);
        // console.log(name_of_selected_test_set);
        // console.log(isTestSet);

        // console.log($('.hpqctestset').val());
        // console.log($('.hpqctestset').attr('name'));
        // console.log($('.hpqctestset').attr('id'));

        $('.hpqctestset').val(name_of_selected_test_set);
        $('.hpqctestset').attr('name', name_of_selected_test_set);
        $('.hpqctestset').attr('id', id_of_selected_test_set);
        $('.hpqctestset').css('border', '1px solid green');
        $('.hpqctestset').css('background-color', '#dff0d8');

        $('#gobtn').prop("disabled", false);
        

        if (isTestSet) {
            $('.hpqctestset').addClass('test-set');
        } else {
            $('.hpqctestset').removeClass('test-set');
        }
        
      });

    formdata = {
        'branch': branch_default,
        'feature': feature_default,
        'start_date': start_date,
        'end_date': end_date
    }

    $.ajax({
        type: "post",
        url: "/getsummarycontent",
        data: formdata,
        success: function (response) {
            $('#summary_content').html(response);
        },
        error: function(data) {
        console.log("Error" + data['responseText']);
        },
    });

    get_buildwise_content(false);

    $('#gobtn').click(function (e) { 
        e.preventDefault();
        consolidate_folders = $('#consolidate_folders').prop("checked");
        $('#dvLoading').fadeIn(300);
        name = $('.hpqctestset').attr('name');
        id = $('.hpqctestset').attr('id');
        isTestSet = $('.hpqctestset').hasClass( "test-set");
        // console.log("name - " + name);
        // console.log("id - " + id);
        // console.log("isTestSet - " + isTestSet);

        if(isTestSet){

            $.ajax({
                type: "get",
                url: "/getcountfortestset",
                data: { 'id' : id, 'name' : name},
                success: function (response) {
                    $('#RIGHT_DIV_LOWER').html(response);
                    $('#dvLoading').fadeOut(1000);
                },
                error: function(data) {
                    console.log("Error in /getcountfortestset " + data['responseText']);
                    $('#dvLoading').fadeOut(1000);
                },
            });

        }else{

            if(consolidate_folders){
                $.ajax({
                    type: "get",
                    url: "/getfolderwisecountfortestfolder",
                    data: { 'id' : id, 'name' : name},
                    success: function (response) {
                        $('#RIGHT_DIV_LOWER').html(response);
                        $('#dvLoading').fadeOut(1000);
                    },
                    error: function(data) {
                        console.log("Error in /getcountfortestfolder " + data['responseText']);
                        $('#dvLoading').fadeOut(1000);
                    },
                });
            }
            else{
                $.ajax({
                    type: "get",
                    url: "/getcountfortestfolder",
                    data: { 'id' : id, 'name' : name},
                    success: function (response) {
                        $('#RIGHT_DIV_LOWER').html(response);
                        $('#dvLoading').fadeOut(1000);
                    },
                    error: function(data) {
                        console.log("Error in /getcountfortestfolder " + data['responseText']);
                        $('#dvLoading').fadeOut(1000);
                    },
                });
            }
        }
       
    });

    $('.nav li').on('click', 'a', function () {
         $(this).parent().addClass('active').siblings().removeClass('active');
         selector_id = $(this).attr('id');
         content_id = '#'+selector_id.split('_')[0]+'_content';
         if(['hpqcreport_selector', 'jenkins_selector', 'schedulejob_selector'].indexOf(selector_id) >= 0){
            $('.filter-panel').css('display', 'none');
         }
         else{
            $('.filter-panel').css('display', 'block');
         }

         $(content_id).fadeIn(2000).siblings().hide();

         if($('#jenkins_content').is(':visible')){
            $('#alerts').html('<p id="alert"></p>');
            refresh_jenkins(true);
         }

         if($('#schedulejob_content').is(':visible')){
            $('#schedule_alerts').html('<p id="schedule_alert"></p>');
            get_schedule_table();
         }

      });

    $("#jenkins_data").on('click', '.killqueuedjobs', function () { 
        queued_job_id = $(this).attr('id');
        // console.log('queued_job_id : ' + queued_job_id);
        $('#sure_yes').attr('name', queued_job_id);
        $('#sure_yes').removeClass('running');
        $('#sure_yes').removeClass('scheduled');
        $('#sure_yes').addClass('queued');

    });


    $("#jenkins_data").on('click', '.killrunningjobs', function () { 
        running_job_id = $(this).attr('id');
        // console.log('running_job_id : ' + running_job_id);

        $('#sure_yes').attr('name', running_job_id);
        $('#sure_yes').removeClass('scheduled');
        $('#sure_yes').removeClass('queued');
        $('#sure_yes').addClass('running');

    });

    $("#jenkins_data").on('click', '.killscheduledjobs', function () { 
        scheduled_job_id = $(this).attr('id');
        // console.log('scheduled_job_id : ' + scheduled_job_id);

        $('#sure_yes').attr('name', scheduled_job_id);
        $('#sure_yes').removeClass('running');
        $('#sure_yes').removeClass('queued');
        $('#sure_yes').addClass('scheduled');

    });


    $('#sure_yes').click(function (e) { 
        e.preventDefault();
        $('#confirmModal').modal('hide');

        id = $('#sure_yes').attr('name');
        isRunningJob = $('#sure_yes').hasClass('running');
        isQueuedJob = $('#sure_yes').hasClass('queued');
        isScheduledJob = $('#sure_yes').hasClass('scheduled');

        // console.log(id, ':', isRunningJob);

        if(isRunningJob === true){
            $.ajax({
                type: "post",
                url: "/killrunningjobs",
                data: { 'id' : id },
                success: function (response) {
                    create_success_alert('Running Job Killed Successfully', '#alert');
                    refresh_jenkins(true);
                },
                error: function(data) {
                    console.log("Error in killrunningjobs" + data['responseText']);
                    create_danger_alert('Error in Killing a Running Job', '#alert');
                }
            });
        } else if(isQueuedJob === true){
            $.ajax({
                type: "post",
                url: "/killqueuedjobs",
                data: { 'id' : id },
                success: function (response) {
                    create_success_alert('Queued Job Killed Successfully', '#alert');
                    refresh_jenkins(true);
                },
                error: function(data) {
                    console.log("Error in killqueuedjobs" + data['responseText']);
                    create_danger_alert('Error in Killing a Queued Job', '#alert');
                }
            });
        } else if(isScheduledJob === true){
            $.ajax({
                type: "post",
                url: "/killscheduledjobs",
                data: { 'id' : id },
                success: function (response) {
                    create_success_alert('Scheduled Job Killed Successfully', '#alert');
                    refresh_jenkins(true);
                },
                error: function(data) {
                    console.log("Error in killscheduledjobs" + data['responseText']);
                    create_danger_alert('Error in Killing a Scheduled Job', '#alert');
                }
            });
        }
        
    });


    $("#branch li a").click(function (e) { 
        e.preventDefault();
        $("#branch_default").html(this.text);
    });

    $("#feature li a").click(function (e) { 
        e.preventDefault();
        $("#feature_default").html(this.text);
    });

    $("#home_content").on("click",".clickable_feature", function(){
        var myWindow = window.open();
        id = $(this).attr('id');
        // Retrieve root URL
        var url = location.protocol + '//' + location.host + '/gettestcases?id='+ id;
        // console.log("URL:"+url);
        myWindow.location.href = url;
    });
    
    $("#home_content").on("click",".update_hpqc", function(){
        var myWindow = window.open();
        id = $(this).attr('id');
        // Retrieve root URL
        var url = location.protocol + '//' + location.host + '/updatehpqc?id='+ id;
        // console.log("URL:"+url);
        myWindow.location.href = url;
    });

    $('.filter #filter_form').submit(function (e) { 
        e.preventDefault();
        branch_default = $('.filter form #branch_default').html();
        feature_default = $('.filter form #feature_default').html();
        start_date = $('.filter form #start_date').val();
        end_date = $('.filter form #end_date').val();
        
        start_date_obj = new Date(start_date);
        end_date_obj = new Date(end_date);
        // console.log(start_date_obj , end_date_obj);
        if(start_date_obj > end_date_obj){
            alert('Start Date cannot be greater than End Date');
            return false;
        }
        // console.log('Valid Data');
        // console.log('Submitted Data :' + branch_default + ' , ' +feature_default + ' , ' + start_date + ' , ' + end_date);

        formdata = {
            'branch': branch_default,
            'feature': feature_default,
            'start_date': start_date,
            'end_date': end_date
        }

        if ($('#home_content').is(":visible")) {
            $('#dvLoading').fadeIn(300);
            $.ajax({
                type: "post",
                url: "/gethomecontent",
                data: formdata,
                success: function (response) {
                    $('#home_content').html(response);
                    $('#dvLoading').fadeOut(1000);
                },
                error: function(data) {
                console.log("Error" + data['responseText']);
                $('#dvLoading').fadeOut(1000);
                },
            });

        } else if ($('#summary_content').is(":visible")) {
            $('#dvLoading').fadeIn(300);
            $.ajax({
                type: "post",
                url: "/getsummarycontent",
                data: formdata,
                success: function (response) {
                    $('#summary_content').html(response);
                    $('#dvLoading').fadeOut(1000);
                },
                error: function(data) {
                console.log("Error" + data['responseText']);
                $('#dvLoading').fadeOut(1000);
                },
            });

        } else if ($('#buildwise_content').is(":visible")) {
            get_buildwise_content(true)

        } else if ($('#suitecomparison_content').is(":visible")) {
            if(feature_default == 'All'){
                alert('Please Select a Feature. Feature cannot be All.')
            }
            else{
                $('#dvLoading').fadeIn(300);

                $.ajax({
                    type: "post",
                    url: "/getsuitecomparisoncontent",
                    data: formdata,
                    success: function (response) {
                        $('#suitecomparison_content').html(response);
                        $('#dvLoading').fadeOut(1000);
                    },
                    error: function(data) {
                    console.log("Error" + data['responseText']);
                    $('#dvLoading').fadeOut(1000);
                    },
                });
            }
        } else {
            console.log('ERROR : None of the Contents Visible... ');
        }


    });
    
    $( document ).ajaxComplete(function(event, request, settings) {
        console.log(settings['url']);
        // console.log('After Ajax- Table is :' + $('table.datatable').length + ' ' +  $('table.datatable').attr('name'));
        if ($('table.datatable')){

            $('table.datatable').dataTable({
                "bDestroy": true
            }).fnDestroy();
            
            $('table.datatable').each(function(){
                var name = $(this).attr('name');
                // console.log(name);
                if(name == 'home_table'){
                    // console.log('Inside home table');
                    $(this).DataTable({
                        "pageLength": 50,
                        "bDestroy": true,
                        order: [[0, 'desc']]
                    });
                }
                else if(name == 'suitecomparison_table'){
                    // console.log('Inside Suite comparison table');
                    $(this).DataTable({
                        "pageLength": 100,
                        "bDestroy": true,
                        "lengthMenu": [[100, 200, 300, -1], [100, 200, 300, "All"]],
                        order: [[0, 'asc']]
                    });
                }
                else if(name == 'summary_table'){
                    // console.log('Inside Summary table');
                    $(this).DataTable({
                        "pageLength": 50,
                        "bDestroy": true,
                        order: [[0, 'asc']]
                    });
                }
                else if(name == 'buildwise_table'){
                    // console.log('Inside Buildwise table');
                    $(this).DataTable({
                        "dom": '<"top"if>',
                        "bDestroy": true,
                        "paging":   false,
                        "info":     true,
                        "ordering": false,
                        // "aoColumns": [
                        //     { "bSortable": false }
                        // ],
                    });
                }
                else if(name == 'runningjobs_table'){
                    $(this).DataTable({
                        "bDestroy": true,
                        "paging":   false,
                        "info":     false,
                        order: [[0, 'asc']]
                    });
                }
                else if(name == 'queuedjobs_table'){
                    $(this).DataTable({
                        "bDestroy": true,
                        "paging":   false,
                        "info":     false,
                        order: [[0, 'asc']]
                    });
                }
                else if(name == 'scheduledjobs_table'){
                    $(this).DataTable({
                        "pageLength": 50,
                        "bDestroy": true,
                        "paging":   false,
                        "info":     false,
                        order: [[0, 'asc']]
                    });
                }
                else if(name == 'schedule_datatable'){
                    $(this).DataTable({
                        "dom": '<"pull-left"f>tip',
                        "pageLength": 50,
                        "bDestroy": true,
                        "paging":   false,
                        "info":     false,
                        order: [[0, 'asc']]
                    });
                }
                
            });

            // $('table.datatable').DataTable({
            //     "pageLength": 50,
            //     "bDestroy": true,
            //     order: [[0, 'desc']]
            // });
        }

      });

      $('#refresh_jenkins').click(function (e) { 
          e.preventDefault();
          $('#alerts').html('<p id="alert"></p>');
          refresh_jenkins(true);  
      });

      $('#refresh_schedule').click(function (e) { 
        e.preventDefault();
        $('#schedule_alerts').html('<p id="schedule_alert"></p>');
        get_schedule_table();  
    });

    $('#scheduletable_data').on('click', "#schedule_wait li a", function (e) { 
        e.preventDefault();
        $("#schedule_wait_default").html(this.text);
    });


    $('#scheduletable_data').on('change', '#schedule_nsxbuild', function (e) {
        e.preventDefault();
        nsxBuild = $('#schedule_nsxbuild').val();
        
        if(nsxBuild != ""){
            $('#schedule_wait_element').css('display', 'block');
            $('#schedule_branch_content').css('display', 'none');
        }else{
            $('#schedule_wait_default').html('0 hr');
            $('#schedule_wait_element').css('display', 'none');
            $('#schedule_branch_content').css('display', 'block');
        } 
    });

    $('#scheduletable_data').on('change', '#schedule_future', function () {
        schedule_for_future = $('#schedule_future').prop("checked");
        if(schedule_for_future){
            $('#schedule_datetime_element').css('display', 'block');
        }else{
            $('#datetimepicker').datetimepicker('clear');
            $('#schedule_datetime_element').css('display', 'none');
        }
    });

    $('#scheduletable_data').on('change', '#schedule_vc', function () {
        schedule_with_vc = $('#schedule_vc').prop("checked");
        if(schedule_with_vc){
            $('#schedule_vc_element').css('display', 'block');
        }else{
            $('#schedule_vcbuild').val('');
            $('#schedule_vc_element').css('display', 'none');
        }
    });

    $('#scheduletable_data').on('click','#schedule_submit',function () {

        $('#dvLoading').fadeIn(300);

        nsxbuild = $('#schedule_nsxbuild').val();
        esxbuild = $('#schedule_esxbuild').val();
        wait = $('#schedule_wait_default').html();
        kill_queued = $('#schedule_queued').prop("checked");
        kill_running = $('#schedule_running').prop("checked");

        nsxbranch = $("#schedule_branch_default").html();

        schedule_for_future = $('#schedule_future').prop("checked");
        future_datetime = $('#datetimepicker').datetimepicker('viewDate').format();

        timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        console.log('TimeZone : ' + timeZone);


        // console.log('Future Datetime :' + future_datetime);

        var selected_rows = $('#scheduletable_data tbody tr').filter(".info");

        if(selected_rows.length == 0){
            create_danger_alert('Please select atleast one job to schedule from the job table', '#schedule_alert');
            $('#dvLoading').fadeOut(1000);
        }else{

            var selected_jobs = []

                
            selected_rows.each(function (index, value) {
                var jobName = $(this).children().first().attr('name');
                selected_jobs.push(jobName);
            });

            // console.log('selected jobs : '+ selected_jobs);

            // console.log(nsxbuild + ':' + esxbuild + ':' + wait + ':' +kill_queued + ':' + kill_running);

            formData = {
                'jobs' : selected_jobs,
                'nsxbuild' : nsxbuild,
                'esxbuild' : esxbuild,
                'wait' : wait,
                'kill_queued' : kill_queued,
                'kill_running' : kill_running,
                'nsxbranch' : nsxbranch,
                'schedule_for_future' : schedule_for_future,
                'future_datetime' : future_datetime,
                'timeZone': timeZone
            }

            if(schedule_for_future == true){
                schedule_jenkins_job(formData)
            }else{
                if( wait != '0 hr'){
                    if (nsxbuild === ''){
                        create_danger_alert('Cannot Schedule Build for '+ wait +' without having nsxbuild number','#schedule_alert');
                    }else{
                        schedule_jenkins_job(formData);
                    }
                }else{
                    start_jenkins_job(formData);             
                }
            }
        
            $('#dvLoading').fadeOut(1000);

            // $.ajax({
            //     type: "GET",
            //     url: "/getnoofrunningjobs",
            //     success: function (response) {
            //         // console.log(response);
            //         // console.log(response.no_of_jobs_running);
            //         // console.log(response.max_jobs_allowed_for_scheduling);
            //         var max_allowed_job_to_schedule = response.max_jobs_allowed_for_scheduling;
            //         console.log("Number of running Jobs "+response.no_of_jobs_running);
            //         no_of_running_jobs = response.no_of_jobs_running;

            //         if( (no_of_running_jobs + selected_rows.length) > max_allowed_job_to_schedule ){
            //             create_danger_alert('Due to hardware resource constraints cannot schedule '+ selected_rows.length +' jobs, Number of jobs that are allowed : '+(max_allowed_job_to_schedule - no_of_running_jobs), '#schedule_alert'); 
            //         } 
            //         else {             

            //             // Copy the code back here for limiting the number of jobs to be scheduled
                           
            //         }

            //         $('#dvLoading').fadeOut(1000);
            //     },
            //     error: function(data) {
            //         create_danger_alert('Error in Getting Number of Running Jenkins Jobs', '#schedule_alert'); 
            //         $('#dvLoading').fadeOut(1000);
            //     }
            // });
        }
        
    });

    $('#scheduletable_data').on('click', '.selection_btn', function (e) { 
        e.preventDefault();
        $(this).addClass('active').siblings().removeClass('active');

        var selectedButtonName = $(this).attr('name');
        // console.log(selectedButtonName);
        allRows = $('#scheduletable_data tbody tr');

        if(selectedButtonName === "schedule_all"){
            allRows.addClass('info');
        }else if(selectedButtonName === "schedule_none"){
            allRows.removeClass('info');
        }

    });

    $('#scheduletable_data').on('click', '#schedule_branches li a', function (e) {
        e.preventDefault();
        $("#schedule_branch_default").html(this.text);
    });

    $('#scheduletable_data').on('click', 'tbody tr', function(e){
        var $tr = $(this);
        var $table = $tr.closest('.table');
        var our_index = $($tr,$table).index();
        $('.selection_btn').removeClass('active');

        if (e.shiftKey) {
            var last_index = $table.data('last-index');
            if (last_index) {
                if (last_index < our_index) {
                    while(last_index < our_index) {
                        $('tbody tr:eq('+(++last_index)+')', $table).click();
                    }   
                    $('tbody tr:eq('+(last_index)+')', $table).click();
                } else {  
                    while(last_index > our_index) {
                        $('tbody tr:eq('+(--last_index)+')', $table).click();
                    }
                    $('tbody tr:eq('+(last_index)+')', $table).click();
                } 
            }
            $table.data('last-index',our_index);
        } else {
            $table.data('last-index',our_index);
        }
        
        if ($tr.hasClass('info')) {
            $tr.removeClass('info');
        } else {
            $tr.addClass('info');
        }
    });


      function start_jenkins_job(formData){
        $('#dvLoading').fadeIn(300);

        $.ajax({
            type: "post",
            url: "/startjenkinsjob",
            data: JSON.stringify(formData),
            contentType: "application/json; charset=utf-8",
            success: function (response) {
                create_success_alert('Started Jobs : '+ formData['jobs'], '#schedule_alert');
                $('#dvLoading').fadeOut(1000);
            },
            error: function(data) {
                console.log("Error in starting jobs" + data['responseText']);
                create_danger_alert('Error in starting jobs', '#schedule_alert');
                $('#dvLoading').fadeOut(1000);
            }
        });
      }

      function schedule_jenkins_job(formData){
        $('#dvLoading').fadeIn(300);

        $.ajax({
            type: "post",
            url: "/schedulejenkinsjob",
            data: JSON.stringify(formData),
            contentType: "application/json; charset=utf-8",
            success: function (response) {
                if(formData['schedule_for_future']){
                    create_success_alert('Scheduled Jobs for future ! You can check them in Scheduled Jobs', '#schedule_alert');
                }
                else{
                    create_success_alert('Scheduled Jobs to wait for the build for '+ formData['wait'], '#schedule_alert');
                }
                $('#dvLoading').fadeOut(1000);
            },
            error: function(data) {
                console.log("Error in scheduling jobs" + data['responseText']);
                create_danger_alert('Error in scheduling jobs', '#schedule_alert');
                $('#dvLoading').fadeOut(1000);
            }
        });
      }

      function get_buildwise_content(loaders){
        if(loaders){
            $('#dvLoading').fadeIn(300);
        }
        $.ajax({
            type: "post",
            url: "/getbuildwisecontent",
            data: formdata,
            success: function (response) {
                $('#buildwise_content').html(response);
                if(loaders){ $('#dvLoading').fadeOut(1000); }
            },
            error: function(data) {
            console.log("Error" + data['responseText']);
            if(loaders){ $('#dvLoading').fadeOut(1000); }
            },
        });
      }

      function get_schedule_table(){

        $('#dvLoading').fadeIn(300);
        $.ajax({
            type: "get",
            url: "/getalljenkinsjobs",
            success: function (response) {
                $('#scheduletable_data').html(response);

                $('#datetimepicker').datetimepicker({
                    sideBySide: true,
                    minDate: new Date(),
                    stepping: 10
                });

                $('#dvLoading').fadeOut(1000);
            },
            error: function(data) {
                console.log("Error" + data['responseText']);
                $('#dvLoading').fadeOut(1000);
            }

        });
        
      }

      function refresh_jenkins(loaders){

        if(loaders){
            $('#dvLoading').fadeIn(300);
        }
        $.ajax({
            type: "get",
            url: "/getjenkinstable",
            success: function (response) {
                $('#jenkins_data').html(response);
                if(loaders){ $('#dvLoading').fadeOut(1000); }
            },
            error: function(data) {
                console.log("Error" + data['responseText']);
                if(loaders){ $('#dvLoading').fadeOut(1000); }
            }
        });
    }

    function create_warning_alert(msg, id) {
        $(id).before(
            '<div class="alert alert-warning alert-dismissable">'+
                '<button type="button" class="close" ' + 
                        'data-dismiss="alert" aria-hidden="true">' + 
                    '&times;' + 
                '</button>' + 
                msg + 
             '</div>');     
    }

    function create_success_alert(msg, id) {
        $(id).before(
            '<div class="alert alert-success alert-dismissable">'+
                '<button type="button" class="close" ' + 
                        'data-dismiss="alert" aria-hidden="true">' + 
                    '&times;' + 
                '</button>' + 
                msg + 
             '</div>');     
    }

    function create_danger_alert(msg, id) {
        $(id).before(
            '<div class="alert alert-danger alert-dismissable">'+
                '<button type="button" class="close" ' + 
                        'data-dismiss="alert" aria-hidden="true">' + 
                    '&times;' + 
                '</button>' + 
                msg + 
             '</div>');     
    }

});


