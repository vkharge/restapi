$(document).ready(function () {
    $('table.testcases-table').DataTable({
        "pageLength": 100
    });
});

