$(document).ready(function () {
    


$('#public-methods').multiSelect({
    selectableHeader: "<div class='custom-header'>All Columns</div>",
    selectionHeader: "<div class='custom-header'>Default Columns</div>",
    keepOrder: true
});

$('#select-all').click(function(){
  $('#public-methods').multiSelect('select_all');
  return false;
});


$('#refresh').on('click', function(){
  $('#public-methods').multiSelect('refresh');
  return false;
});
$('#add-option').on('click', function(){
  $('#public-methods').multiSelect('addOption', { value: 42, text: 'test 42', index: 0 });
  return false;
});

$("#branch li a").click(function (e) { 
  e.preventDefault();
  $("#branch_default").html(this.text);
});

$("#feature li a").click(function (e) { 
  e.preventDefault();
  $("#feature_default").html(this.text);
});


$('#default_selection_form').submit(function (e) { 
  e.preventDefault();
  selected_columns = []
  $('#public-methods > option:selected').each(function() {
      // this should loop through all the selected elements
      selected_columns.push($(this).val())
  });

  branch_default = $('form #branch_default').html();
  feature_default = $('form #feature_default').html();
  difference_between_dates = $('#difference_between_dates').val();
  admin_password = $("#admin_password").val();
  default_suites = $('#default_suites').val();
  default_runs = $('#default_runs').val();

  default_add_branch = $('#default_add_branch').val();
  default_delete_branch = $('#default_delete_branch').val();
  
  formdata = {
      'branch_default': branch_default,
      'feature_default': feature_default,
      'difference_between_dates': difference_between_dates,
      'selected_columns': selected_columns,
      'default_suites': default_suites,
      'default_runs': default_runs,
      'default_add_branch': default_add_branch,
      'default_delete_branch': default_delete_branch
  }
  // console.log(selected_columns);
  // console.log(branch_default, feature_default, difference_between_dates, admin_password, default_suites);

  $.ajax({
    type: "post",
    url: "/check_password",
    data: {'admin_password': admin_password},
    success: function (response) {
        console.log('Correct Admin Password');
        $.ajax({
          type: "post",
          url: "/change_defaults",
          data: formdata,
          success: function (response) {
              alert('Changed the default values successfully !!! ');
              location.reload();
          },
          error: function(data) {
              alert('Error in changing the default values');
              console.log("Error" + data);
          }
        });
  
    },
    error: function(data) {
      alert('Admin Password is Wrong !!! ');
      console.log("Error" + data);
    }
  });

});



});