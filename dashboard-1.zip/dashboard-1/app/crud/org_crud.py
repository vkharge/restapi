from sqlalchemy.orm import Session

from app.crud.queries import create_org_query, get_orgs_query, \
    get_mapping_by_org_id_query, get_org_by_name_query, get_org_by_id_query
from app.db_models import models
from app.common.exceptions import DuplicateEntity, CannotDelete
from app.schemas import req_schemas


def create_org(payload: req_schemas.Org, db: Session):
    org = get_org_by_name_query(payload.name, db, raise_exception=False,
                                case_sensitive=False)

    if org.first():
        raise DuplicateEntity(f"Duplicate Org name {payload.name}")

    return create_org_query(payload, db)


def get_orgs(db: Session):
    orgs = get_orgs_query(db).all()
    return {"count": len(orgs), "orgs": orgs}


def get_org_by_id(org_id: int, db: Session):
    return get_org_by_id_query(org_id, db).first()


def get_org_by_name(org_name: str, db: Session):
    return get_org_by_name_query(org_name, db).first()


def delete_org(org_id: int, db: Session):
    org = get_org_by_id_query(org_id, db)
    org_in_mapping = get_mapping_by_org_id_query(org.first().name, db,
                                                 raise_exception=False)
    if org_in_mapping.first():
        raise CannotDelete(f"Org with id {org_id} cannot be deleted")

    org.delete(synchronize_session=False)
    db.commit()

    return


def update_org(org_id: int, payload: req_schemas.Org, db: Session):

    org = get_org_by_id_query(org_id, db)

    org.update(payload.dict())
    db.commit()
    return org.first()
