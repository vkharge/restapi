from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.common.data import SUITE_HEADER, TESTCASE_HEADER
from app.crud.queries import get_orgs_query, get_org_by_name_query, \
    get_product_by_name_query, get_sub_product_by_name_query, \
    get_products_for_given_org_id_query, \
    get_sub_products_for_given_product_id_query, get_environments_query, \
    get_test_types_query, get_suite_data_by_all_filters_query, \
    get_suite_data_by_suite_id_query, get_testcases_by_suite_id_query
from app.db_models import models
from app.db_models.models import Org, Product, SubProduct, TestCase


# View/Routes Methods
def get_ops_by_name(org_name, product_name, sub_product_name, db: Session):
    org = get_org_by_name(org_name, db)
    product = get_product_by_name(product_name, db)
    sub_product = get_sub_product_by_name(sub_product_name, db)

    return org, product, sub_product


def get_search_filter_vals_by_id(org_id, product_id, sub_product_id, db: Session):
    orgs = get_orgs(db)
    products = get_products_for_given_org_id(org_id, db)
    sub_products = get_sub_products_for_given_product_id(org_id, product_id, db)
    environments = get_environments(db)
    test_types = get_test_types(db)

    return orgs, products, sub_products, environments, test_types


def get_search_filter_vals_by_name(org_name, product_name, sub_product_name, db: Session):
    org, product, sub_product = get_ops_by_name(org_name, product_name,
                                                sub_product_name, db)

    return get_search_filter_vals_by_id(org.id, product.id, sub_product.id, db)


def get_suite_execution(org_id, product_id, sub_product_id,
                        environment_name, test_type_name, db: Session):

    suite_results = get_suite_execution_for_given_search_filters(
        org_id, product_id, sub_product_id, environment_name, test_type_name, db)

    if suite_results:
        header = [column.capitalize() for column in suite_results[0].keys()]
    else:
        header = SUITE_HEADER

    return header, suite_results


def get_suite_testcase_execution_by_suite_id(suite_id, db: Session):
    suite_result = get_suite_execution_by_id(suite_id, db)
    testcase_results = get_testcase_execution_by_suite_id(suite_id, db)

    if suite_result:
        suite_header = [column.capitalize() for column in suite_result.keys()]
    else:
        suite_header = SUITE_HEADER

    if testcase_results:
        testcase_header = [column.capitalize() for column in testcase_results[0].keys()]
    else:
        testcase_header = TESTCASE_HEADER

    return suite_header, suite_result, testcase_header, testcase_results









# Data Methods
def get_orgs(db: Session):
    orgs = get_orgs_query(db).all()
    orgs = [ {"id": org.id, "name": org.name} for org in orgs]
    orgs.insert(0, {"id": 0, "name": "ALL"})
    print(orgs)
    return orgs

def get_org_by_name(org_name, db: Session):
    if org_name == "ALL":
         return Org(id=0, name="ALL")
    return get_org_by_name_query(org_name, db).first()

def get_product_by_name(product_name, db: Session):
    if product_name == "ALL":
        return Product(id=0, name="ALL")

    return get_product_by_name_query(product_name, db).first()

def get_sub_product_by_name(sub_product_name, db: Session):
    if sub_product_name == "ALL":
        return SubProduct(id=0, name="ALL")
    return get_sub_product_by_name_query(sub_product_name, db).first()

def get_products_for_given_org_id(org_id, db: Session):
    products = get_products_for_given_org_id_query(org_id, db).distinct().all()
    products = [{"id": product.id, "name": product.name} for product in products]
    products.insert(0, {"id": 0, "name": "ALL"})
    print(products)
    return products

def get_sub_products_for_given_product_id(org_id, product_id, db: Session):

    sub_products = get_sub_products_for_given_product_id_query(org_id, product_id, db).distinct().all()
    sub_products = [{"id": sub_product.id, "name": sub_product.name} for sub_product in sub_products]
    sub_products.insert(0, {"id": 0, "name": "ALL"})
    print(sub_products)
    return sub_products

def get_environments(db: Session):
    envirs = get_environments_query(db).all()
    environments = [ {"id": env.id, "name": env.name} for env in envirs]
    environments.insert(0, {"id": 0, "name": "ALL"})
    print(environments)
    return environments

def get_test_types(db: Session):
    test_types = get_test_types_query(db).all()
    test_types = [ {"id": test_type.id, "name": test_type.name} for test_type in test_types]
    test_types.insert(0, {"id": 0, "name": "ALL"})
    print(test_types)
    return test_types



def get_suite_execution_for_given_search_filters(org_id, product_id,
                                                 sub_product_id,
                                                 environment_name,
                                                 test_type_name, db: Session):

    suite_data = get_suite_data_by_all_filters_query(org_id, product_id,
                                                     sub_product_id,
                                                     environment_name,
                                                     test_type_name, db).all()

    table = []
    for suite, suite_mapping, org, product, sub_product in suite_data:
        #"Id", "Date", "Org", "Product", "SubProduct", "Status", "Total",
        # "Passed", "Failed", "Environment", "Type", "Logs"

        logs = {
            "report": suite.report_url,
            "console": suite.console_url,
            "log": suite.log_url
        }

        stats = {
            "total": suite.total,
            "passed": suite.passed,
            "failed": suite.failed,
            "skipped": suite.skipped,
        }

        row = {
            "id" : suite.id,
            #"date": datetime.strptime(str(suite.created),
            # "%Y-%d-%m %H:%M:%S"),
            "date": str(suite.created).split(" ")[0],
            "org": org.name,
            "product": product.name,
            "subproduct": sub_product.name,
            "suite": suite_mapping.suite,
            "status": suite.status,
            "stats": stats,
            "environment": suite_mapping.environment,
            "type": suite_mapping.test_type,
            "logs": logs,
            "duration": time_format(suite.duration)
            #release/branch/infra
        }
        table.append(row)

    return table



def get_suite_execution_by_id(suite_id, db: Session):
    suite, suite_mapping, org, product, sub_product = \
        get_suite_data_by_suite_id_query(suite_id, db).first()

    logs = {
        "report": suite.report_url,
        "console": suite.console_url,
        "log": suite.log_url
    }

    stats = {
        "total": suite.total,
        "passed": suite.passed,
        "failed": suite.failed,
        "skipped": suite.skipped,
    }

    suite_result = {
        "id" : suite.id,
        "date": datetime.strftime(suite.created, "%Y-%d-%m %H:%M:%S"),
        "org": org.name,
        "product": product.name,
        "subproduct": sub_product.name,
        "release": suite_mapping.release,
        "branch": suite.branch,
        "build": suite.build,
        "suite": suite_mapping.suite,
        "status": suite.status,
        "stats": stats,
        "environment": suite_mapping.environment,
        "type": suite_mapping.test_type,
        "logs": logs,
        "duration": time_format(suite.duration),
        "infra": suite.infra
    }

    return suite_result


def get_testcase_execution_by_suite_id(suite_id, db: Session):
    testcases = get_testcases_by_suite_id_query(suite_id, db)\
        .order_by(TestCase.testno).all()

    testcase_results = []
    for testcase in testcases:
        test = {
            "testno" : testcase.testno,
            "testname": testcase.testname,
            "status": testcase.status,
            "duration": time_format(testcase.duration),
            "message": testcase.message,
        }

        #print(test)
        testcase_results.append(test)
    return testcase_results


def time_format(time: float):
    td = timedelta(seconds=time)
    seconds = td.seconds
    ms = int(str(td.microseconds)[:3])

    d = seconds // (3600 * 24)
    h = seconds // 3600 % 24
    m = seconds % 3600 // 60
    s = seconds % 3600 % 60
    if d > 0:
        return '{}D {}H {}m {}s {}ms'.format(d, h, m, s, ms)
    elif h > 0:
        return '{}H {}m {}s {}ms'.format(h, m, s, ms)
    elif m > 0:
        return '{}m {}s {}ms'.format(m, s, ms)
    elif s > 0:
        return '{}s {}ms'.format(s, ms)
    elif ms > 0:
        return '{}ms'.format(ms)
    else:
        return '-'

