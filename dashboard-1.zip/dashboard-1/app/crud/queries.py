from sqlalchemy import func
from sqlalchemy.orm import Session
from app.common.exceptions import NotFound, DuplicateEntity
from app.db_models import models
from app.schemas import req_schemas


# Org Query
def create_org_query(payload: req_schemas.Org, db: Session):
    org = models.Org(**payload.dict())
    db.add(org)
    db.commit()
    db.refresh(org)

    return org


def get_orgs_query(db: Session):
    return db.query(models.Org)


def get_org_by_id_query(org_id: int, db: Session, raise_exception=True):
    org = db.query(models.Org).filter(models.Org.id == org_id)

    if raise_exception and not org.first():
        raise NotFound(f"Org with the id {org_id} not found")
    return org


def get_org_by_name_query(org_name: str, db: Session, raise_exception=True,
                          case_sensitive=True):
    if case_sensitive:
        name = func.binary(org_name)
    else:
        name = org_name
    org = db.query(models.Org).filter(models.Org.name == name)

    if raise_exception and not org.first():
        raise NotFound(f"Org with the name {org_name} not found")
    return org


# Product Query
def create_product_query(payload: req_schemas.Product, db: Session):
    product = models.Product(**payload.dict())
    db.add(product)
    db.commit()
    db.refresh(product)

    return product


def get_products_query(db: Session):
    return db.query(models.Product)


def get_product_by_id_query(product_id: int, db: Session,
                            raise_exception=True):
    product = db.query(models.Product).filter(models.Product.id == product_id)
    if raise_exception and not product.first():
        raise NotFound(f"Product with the id {product_id} not found")
    return product


def get_product_by_name_query(product_name: str, db: Session,
                              raise_exception=True, case_sensitive=True):
    if case_sensitive:
        name = func.binary(product_name)
    else:
        name = product_name
    product = db.query(models.Product).\
        filter(models.Product.name == name)
    if raise_exception and not product.first():
        raise NotFound(f"Product with the name {product_name} not found")
    return product


# Sub-Product Query
def create_sub_product_query(payload: req_schemas.SubProduct, db: Session):
    sub_product = models.SubProduct(**payload.dict())
    db.add(sub_product)
    db.commit()
    db.refresh(sub_product)

    return sub_product


def get_sub_products_query(db: Session):
    return db.query(models.SubProduct)


def get_sub_product_by_id_query(sub_product_id: int, db: Session,
                                raise_exception=True):
    sub_product = db.query(models.SubProduct).\
        filter(models.SubProduct.id == sub_product_id)
    if raise_exception and not sub_product.first():
        raise NotFound(f"Sub-Product with the id {sub_product_id} not found")
    return sub_product


def get_sub_product_by_name_query(sub_product_name: str, db: Session,
                                  raise_exception=True, case_sensitive=True):
    if case_sensitive:
        name = func.binary(sub_product_name)
    else:
        name = sub_product_name
    sub_product = db.query(models.SubProduct).\
        filter(models.SubProduct.name == name)
    if raise_exception and not sub_product.first():
        raise NotFound(f"Sub-Product with the name "
                       f"{sub_product_name} not found")
    return sub_product


# Environment Query
def create_environment_query(payload: req_schemas.Environment, db: Session):
    environment = models.Environment(**payload.dict())
    db.add(environment)
    db.commit()
    db.refresh(environment)

    return environment


def get_environments_query(db: Session):
    return db.query(models.Environment)


def get_environment_by_id_query(environment_id: int, db: Session,
                                raise_exception=True):
    environment = db.query(models.Environment).\
        filter(models.Environment.id == environment_id)
    if raise_exception and not environment.first():
        raise NotFound(f"Environment with the id {environment_id} not found")
    return environment


def get_environment_by_name_query(environment_name: str, db: Session,
                                  raise_exception=True, case_sensitive=True):
    if case_sensitive:
        name = func.binary(environment_name)
    else:
        name = environment_name
    environment = db.query(models.Environment).\
        filter(models.Environment.name == name)
    if raise_exception and not environment.first():
        raise NotFound(f"Environment with the name {environment_name}"
                       " not found")
    return environment


# Test-Type Query
def create_test_type_query(payload: req_schemas.TestType, db: Session):
    test_type = models.TestType(**payload.dict())
    db.add(test_type)
    db.commit()
    db.refresh(test_type)

    return test_type


def get_test_types_query(db: Session):
    return db.query(models.TestType)


def get_test_type_by_id_query(test_type_id: int, db: Session,
                              raise_exception=True):
    test_type = db.query(models.TestType).\
        filter(models.TestType.id == test_type_id)
    if raise_exception and not test_type.first():
        raise NotFound(f"Test-Type with the id {test_type_id} not found")
    return test_type


def get_test_type_by_name_query(test_type_name: str, db: Session,
                                raise_exception=True, case_sensitive=True):
    if case_sensitive:
        name = func.binary(test_type_name)
    else:
        name = test_type_name
    test_type = db.query(models.TestType).\
        filter(models.TestType.name == name)
    if raise_exception and not test_type.first():
        raise NotFound(f"Test-Type with the name {test_type_name} not found")
    return test_type


# Release Query
def get_release_by_id_query(release_id: int, db: Session,
                            raise_exception=True):
    release = db.query(models.Release).filter(models.Release.id == release_id)
    if raise_exception and not release.first():
        raise NotFound(f"Release with the id {release_id} not found")
    return release


def get_release_by_name_query(release_name: str, db: Session,
                              raise_exception=True):
    release = db.query(models.Release).\
        filter(models.Release.name == func.binary(release_name))
    if raise_exception and not release.first():
        raise NotFound(f"Release with the name {release_name} not found")
    return release


# Branch Query
def get_branch_by_id_query(branch_id: int, db: Session, raise_exception=True):
    branch = db.query(models.Branch).filter(models.Branch.id == branch_id)
    if raise_exception and not branch.first():
        raise NotFound(f"Branch with the id {branch_id} not found")
    return branch


# Mapping Query
def create_mapping_query(payload: req_schemas.MappingID, db: Session):
    mapping = models.Mapping(**payload.dict())
    db.add(mapping)
    db.commit()
    db.refresh(mapping)

    return mapping


def get_mapping_by_id_query(mapping_id: int, db: Session,
                            raise_exception=True):
    mapping = db.query(models.Mapping).filter(models.Mapping.id == mapping_id)
    if raise_exception and not mapping.first():
        raise NotFound(f"Mapping with the id {mapping_id} not found")
    return mapping


def get_mapping_by_all_ids_query(payload: req_schemas.MappingID, db: Session):

    mapping = db.query(models.Mapping).filter(
        models.Mapping.org_id == payload.org_id,
        models.Mapping.product_id == payload.product_id,
        models.Mapping.sub_product_id == payload.sub_product_id
    )

    return mapping


def get_mappings_data_query(db: Session):
    mappings_join = db.query(
        models.Mapping,
        models.Org,
        models.Product,
        models.SubProduct)\
        .select_from(models.Mapping).\
        join(models.Org).\
        join(models.Product).\
        join(models.SubProduct)

    return mappings_join


def get_mapping_data_by_id_query(mapping_id: int, db: Session,
                                 raise_exception=True):

    mapping = get_mappings_data_query(db)\
        .filter(models.Mapping.id == mapping_id)

    if raise_exception and not mapping.first():
        raise NotFound(f"Mapping with the id {mapping_id} not found")

    return mapping


def get_mapping_by_col_query(filter_key, filter_value: str,
                             db: Session, raise_exception=True):
    mapping = db.query(models.Mapping)\
        .filter(filter_key == filter_value)
    if raise_exception and not mapping.first():
        raise NotFound(f"Mapping with the {filter_key} "
                       f"id {filter_value} not found")
    return mapping


def get_mapping_by_org_id_query(org_id: int, db: Session,
                                raise_exception=True):
    return get_mapping_by_col_query(models.Mapping.org_id, org_id,
                                    db, raise_exception)


def get_mapping_by_product_id_query(product_id: int, db: Session,
                                    raise_exception=True):
    return get_mapping_by_col_query(models.Mapping.product_id, product_id,
                                    db, raise_exception)


def get_mapping_by_sub_product_id_query(sub_product_id: int, db: Session,
                                        raise_exception=True):
    return get_mapping_by_col_query(models.Mapping.sub_product_id,
                                    sub_product_id, db, raise_exception)


# Suite Mapping Query
def create_suite_mapping_query(payload, db: Session):
    suite_mapping = models.SuiteMapping(**payload)
    db.add(suite_mapping)
    db.commit()
    db.refresh(suite_mapping)

    return suite_mapping


def get_suite_mappings_query(db: Session):
    return db.query(models.SuiteMapping)


def get_suite_mapping_by_id_query(suite_mapping_id: int, db: Session,
                                  raise_exception=True):
    suite_mapping = db.query(models.SuiteMapping)\
        .filter(models.SuiteMapping.id == suite_mapping_id)
    if raise_exception and not suite_mapping.first():
        raise NotFound(f"Suite Mapping with the id {suite_mapping_id}"
                       f" not found")
    return suite_mapping


def get_suite_mapping_by_col_query(filter_key, filter_value: str,
                                   db: Session, raise_exception=True):
    suite_mapping = db.query(models.SuiteMapping)\
        .filter(filter_key == filter_value)
    if raise_exception and not suite_mapping.first():
        raise NotFound(f"Suite Mapping with the {filter_key} "
                       f"id {filter_value} not found")
    return suite_mapping


def get_suite_mapping_by_mapping_id_query(mapping_id: int, db: Session,
                                          raise_exception=True):
    return get_suite_mapping_by_col_query(models.SuiteMapping.mapping_id,
                                          mapping_id, db, raise_exception)


def get_suite_mapping_by_test_type_query(test_type: str, db: Session,
                                         raise_exception=True):
    return get_suite_mapping_by_col_query(models.SuiteMapping.test_type,
                                          func.binary(test_type),
                                          db, raise_exception)


def get_suite_mapping_by_environment_query(environment: str, db: Session,
                                           raise_exception=True):
    return get_suite_mapping_by_col_query(models.SuiteMapping.environment,
                                          func.binary(environment),
                                          db, raise_exception)


def get_suite_mapping_by_all_cols_query(payload: req_schemas.Suite,
                                        mapping_id: int, db: Session):

    suite_mapping = db.query(models.SuiteMapping).filter(
        models.SuiteMapping.mapping_id == mapping_id,
        models.SuiteMapping.environment == func.binary(payload.environment),
        models.SuiteMapping.test_type == func.binary(payload.test_type),
        models.SuiteMapping.release == func.binary(payload.release),
        models.SuiteMapping.branch == func.binary("main"),
        models.SuiteMapping.suite == func.binary(payload.suite),
    )

    return suite_mapping


# Suite Query
def create_suite_query(payload, db: Session):
    suite = models.Suite(**payload)
    db.add(suite)
    db.commit()
    db.refresh(suite)

    return suite


def get_suite_data_query(db: Session):
    execution = db.query(
        models.Suite,
        models.SuiteMapping,
        models.Mapping,
        models.Org,
        models.Product,
        models.SubProduct)\
        .select_from(models.Suite).\
        join(models.SuiteMapping). \
        join(models.Mapping).\
        join(models.Org).\
        join(models.Product).\
        join(models.SubProduct)

    return execution


def get_suite_data_by_id_query(suite_id: int, db: Session,
                               raise_exception=True):

    suite_run = get_suite_data_query(db)\
        .filter(models.Suite.id == suite_id)

    if raise_exception and not suite_run.first():
        raise NotFound(f"Suite with the id {suite_id} not found")

    return suite_run


def get_suite_by_id_query(suite_id: int, db: Session, raise_exception=True):

    suite_run = db.query(models.Suite).\
        filter(models.Suite.id == suite_id)
    if raise_exception and not suite_run.first():
        raise NotFound(f"Suite with the id {suite_id} not found")

    return suite_run


# TestCase Query
def create_testcase_query(payload: req_schemas.TestCase, db: Session):
    testcase = models.TestCase(**payload)
    db.add(testcase)
    db.commit()
    db.refresh(testcase)

    return testcase


def get_testcase_by_id_query(suite_id: int, testcase_id: int, db: Session,
                             raise_exception=True):
    get_suite_by_id_query(suite_id, db)

    test = db.query(models.TestCase).\
        filter(models.TestCase.suite_id == suite_id,
               models.TestCase.id == testcase_id)
    if raise_exception and not test.first():
        raise NotFound(f"Test with the id {testcase_id} not found"
                       f" under suite id {suite_id}")
    return test


def get_testcases_by_suite_id_query(suite_id: int, db: Session,
                                    raise_exception=True):
    get_suite_by_id_query(suite_id, db)

    test = db.query(models.TestCase).\
        filter(models.TestCase.suite_id == suite_id)
    if raise_exception and not test.first():
        raise NotFound(f"Suite with the id {suite_id} does not have"
                       f" any test cases")
    return test


def find_duplicate_test_under_suite(suite_id: int,
                                    payload: req_schemas.TestCase,
                                    db: Session, raise_exception=True):

    test = db.query(models.TestCase).\
        filter(models.TestCase.suite_id == suite_id,
               models.TestCase.testno == payload.testno)
    if raise_exception and test.first():
        raise DuplicateEntity(f"Test with no {payload.testno} already exists"
                              f" under suite id {suite_id}")

    test = db.query(models.TestCase).\
        filter(models.TestCase.suite_id == suite_id,
               models.TestCase.testname == func.binary(payload.testname))
    if raise_exception and test.first():
        raise DuplicateEntity(f"Test with name {payload.testname} already"
                              f" exists under suite id {suite_id}")

    return test


# UI Related Queries
def get_products_for_given_org_id_query(org_id: int, db: Session):
    products = db.query(models.Product.id, models.Product.name) \
        .join(models.Mapping, models.Mapping.product_id==models.Product.id) \
        .filter(models.Mapping.org_id == org_id)

    return products


def get_sub_products_for_given_product_id_query(org_id: int, product_id, db: Session):

    sub_products = db.query(models.SubProduct.id, models.SubProduct.name) \
        .join(models.Mapping, models.Mapping.sub_product_id==models.SubProduct.id) \
        .filter(models.Mapping.org_id == org_id, models.Mapping.product_id==product_id)

    return sub_products


# Suite Execution Data Queries
def get_suite_data_query(db: Session):
    suite_join =  db.query(models.Suite, models.SuiteMapping, models.Org, models.Product, models.SubProduct)\
        .join(models.Suite, models.Suite.suite_mapping_id == models.SuiteMapping.id) \
        .join(models.Mapping, models.SuiteMapping.mapping_id == models.Mapping.id) \
        .join(models.Org, models.Mapping.org_id == models.Org.id) \
        .join(models.Product, models.Mapping.product_id == models.Product.id) \
        .join(models.SubProduct, models.Mapping.sub_product_id == models.SubProduct.id)

    return suite_join


def get_suite_data_by_all_filters_query(org_id: int, product_id: int, sub_product_id: int,
                                        environment_name: str, test_type_name: str, db: Session):

    where = []
    if org_id != 0:
        where.append(models.Mapping.org_id == org_id)
        if product_id != 0:
            where.append(models.Mapping.product_id == product_id)
            if sub_product_id != 0:
                where.append(models.Mapping.sub_product_id == sub_product_id)

    if environment_name != "ALL":
        where.append(models.SuiteMapping.environment == environment_name)

    if test_type_name != "ALL":
        where.append(models.SuiteMapping.test_type == test_type_name)

    suite_results =  get_suite_data_query(db).filter(*where)
    return suite_results


def get_suite_data_by_suite_id_query(suite_id: int, db: Session):
    suite_result =  get_suite_data_query(db).filter(models.Suite.id == suite_id)

    return suite_result


# Test Cases Data Queries
def get_testcases_by_suite_id_query(suite_id: int, db: Session):
    test_cases =  db.query(models.TestCase) \
        .filter(models.TestCase.suite_id == suite_id)\

    return test_cases
