import copy

from sqlalchemy.orm import Session

from app.crud.queries import get_suite_by_id_query, \
    find_duplicate_test_under_suite, create_testcase_query, \
    get_testcases_by_suite_id_query, get_testcase_by_id_query
from app.db_models import models
from app.schemas import req_schemas


def create_testcase(suite_id: int, payload: req_schemas.TestCase, db: Session):
    get_suite_by_id_query(suite_id, db)
    find_duplicate_test_under_suite(suite_id, payload, db)

    testcase_payload = {"suite_id": suite_id, **payload.dict()}
    return create_testcase_query(testcase_payload, db)


def create_testcases(suite_id: int, payload: req_schemas.TestCases,
                     db: Session):
    get_suite_by_id_query(suite_id, db)
    testcases = []
    for test in payload.testcases:
        find_duplicate_test_under_suite(suite_id, test, db)
        test_payload = {"suite_id": suite_id, **test.dict()}
        testcase = create_testcase_query(test_payload, db)
        entry = copy.deepcopy(testcase)
        testcases.append(entry)

    return {"count": len(testcases), "testcases": testcases}


def get_testcases(suite_id: int, db: Session):
    get_suite_by_id_query(suite_id, db)
    testcases = get_testcases_by_suite_id_query(suite_id, db).all()
    return {"count": len(testcases), "testcases": testcases}


def get_testcase(suite_id: int, testcase_id: int, db: Session):
    get_suite_by_id_query(suite_id, db)
    return get_testcase_by_id_query(suite_id, testcase_id, db).first()


def delete_testcases(suite_id: int, db: Session):
    get_suite_by_id_query(suite_id, db)
    testcases = get_testcases_by_suite_id_query(suite_id, db)

    testcases.delete(synchronize_session=False)
    db.commit()

    return


def delete_testcase(suite_id: int, testcase_id: int, db: Session):
    get_suite_by_id_query(suite_id, db)
    testcase = get_testcase_by_id_query(suite_id, testcase_id, db)

    testcase.delete(synchronize_session=False)
    db.commit()

    return


def update_testcase(suite_id: int, testcase_id: int,
                    payload: req_schemas.TestCases, db: Session):
    get_suite_by_id_query(suite_id, db)
    testcase = get_testcase_by_id_query(suite_id, testcase_id, db)
    testcase.update(payload.dict())
    db.commit()

    return testcase.first()


# def construct_response(suite_id: int, payload: req_schemas.TestCases):
#
#     if "duration" in
#
#     testcase = {"suite_id": suite_id, **payload.dict()}