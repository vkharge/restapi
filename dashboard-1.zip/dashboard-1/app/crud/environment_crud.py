from sqlalchemy.orm import Session

from app.crud.queries import get_environment_by_name_query, \
    create_environment_query, get_environments_query, \
    get_environment_by_id_query, get_suite_mapping_by_environment_query
from app.common.exceptions import DuplicateEntity, CannotDelete
from app.schemas import req_schemas


def create_environment(payload: req_schemas.Environment, db: Session):
    environment = get_environment_by_name_query(payload.name, db,
                                                raise_exception=False)
    if environment.first():
        raise DuplicateEntity(f"Duplicate Environment name {payload.name}")

    return create_environment_query(payload, db)


def get_environments(db: Session):
    environments = get_environments_query(db).all()
    return {"count": len(environments), "environments": environments}


def get_environment_by_id(environment_id: int, db: Session):
    return get_environment_by_id_query(environment_id, db).first()


def get_environment_by_name(environment_name: str, db: Session):
    return get_environment_by_name_query(environment_name, db).first()


def delete_environment(environment_id: int, db: Session):
    environment = get_environment_by_id_query(environment_id, db)
    environment_in_mapping = get_suite_mapping_by_environment_query(
        environment.first().name, db, raise_exception=False)

    if environment_in_mapping.first():
        raise CannotDelete(f"Environment with id {environment_id} "
                           f"cannot be deleted")
    environment.delete(synchronize_session=False)
    db.commit()

    return


def update_environment(environment_id: int, payload: req_schemas.Environment,
                       db: Session):
    environment = get_environment_by_id_query(environment_id, db)
    environment.update(payload.dict())
    db.commit()

    return environment.first()
