from sqlalchemy.orm import Session

from app.crud.queries import create_product_query, get_products_query, \
    get_mapping_by_product_id_query, get_product_by_name_query, \
    get_product_by_id_query
from app.common.exceptions import DuplicateEntity, CannotDelete
from app.schemas import req_schemas


def create_product(payload: req_schemas.Product, db: Session):
    product = get_product_by_name_query(payload.name, db,
                                        raise_exception=False)
    if product.first():
        raise DuplicateEntity(f"Duplicate Product name {payload.name}")

    return create_product_query(payload, db)


def get_products(db: Session):
    products = get_products_query(db).all()
    return {"count": len(products), "products": products}


def get_product_by_id(product_id: int, db: Session):
    return get_product_by_id_query(product_id, db).first()


def get_product_by_name(product_name: str, db: Session):
    return get_product_by_name_query(product_name, db).first()


def delete_product(product_id: int, db: Session):
    product = get_product_by_id_query(product_id, db)
    product_in_mapping = get_mapping_by_product_id_query(
        product.first().name, db, raise_exception=False)

    if product_in_mapping.first():
        raise CannotDelete(f"Product with id {product_id} cannot be deleted")
    product.delete(synchronize_session=False)
    db.commit()

    return


def update_product(product_id: int, payload: req_schemas.Product, db: Session):
    product = get_product_by_id_query(product_id, db)
    product.update(payload.dict())
    db.commit()

    return product.first()
