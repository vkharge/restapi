from typing import Optional, List
from pydantic import BaseModel, validator
from pydantic.datetime_parse import datetime

from app.db_models.models import StatusType, TCStatusType


class Org(BaseModel):
    name: str

    @validator('name')
    def validate_empty_name(cls, v):
        return validate_empty("Organization name", v)


class Product(BaseModel):
    name: str

    @validator('name')
    def validate_empty_name(cls, v):
        return validate_empty("Product name", v)


class SubProduct(BaseModel):
    name: str

    @validator('name')
    def validate_empty_name(cls, v):
        return validate_empty("SubProduct name", v)


class Environment(BaseModel):
    name: str

    @validator('name')
    def validate_empty_name(cls, v):
        return validate_empty("Environment name", v)


class TestType(BaseModel):
    name: str

    @validator('name')
    def validate_empty_name(cls, v):
        return validate_empty("TestType name", v)


class Mapping(BaseModel):
    org: str
    product: str
    sub_product: str

    @validator('org')
    def validate_empty_org(cls, v):
        return validate_empty("Org name", v)

    @validator('product')
    def validate_empty_product(cls, v):
        return validate_empty("Product name", v)

    @validator('sub_product')
    def validate_empty_sub_product(cls, v):
        return validate_empty("Sub-Product name", v)


class MappingID(BaseModel):
    org_id: int
    product_id: int
    sub_product_id: int


class SuiteMapping(BaseModel):
    org: str
    product: str
    sub_product: str
    environment: str
    test_type: str
    release: str
    branch: str
    suite: str

    @validator('org')
    def validate_empty_org(cls, v):
        return validate_empty("Org name", v)

    @validator('product')
    def validate_empty_product(cls, v):
        return validate_empty("Product name", v)

    @validator('sub_product')
    def validate_empty_sub_product(cls, v):
        return validate_empty("Sub-Product name", v)

    @validator('environment')
    def validate_empty_environment(cls, v):
        return validate_empty("Environment name", v)

    @validator('test_type')
    def validate_empty_test_type(cls, v):
        return validate_empty("TestType name", v)

    @validator('release')
    def validate_empty_release(cls, v):
        return validate_empty("Release name", v)

    @validator('branch')
    def validate_empty_branch(cls, v):
        return validate_empty("Branch name", v)

    @validator('suite')
    def validate_empty_suite(cls, v):
        return validate_empty("Suite name", v)


class Suite(BaseModel):
    org: str = "DOLBY.IO"
    product: str = "DOLBYON"
    sub_product: str = "IOS"
    test_type: str = "UNIT"
    environment: str = "DEV"
    release: str
    branch: str
    suite: str
    build: str
    total: int
    passed: int
    failed: int
    skipped: int
    status: StatusType
    report_url: Optional[str]
    console_url: Optional[str]
    log_url: Optional[str]
    duration: Optional[float]
    infra: Optional[str]
    created: Optional[datetime] = datetime.now()

    @validator('org')
    def validate_empty_org(cls, v):
        return validate_empty("Org name", v)

    @validator('product')
    def validate_empty_product(cls, v):
        return validate_empty("Product name", v)

    @validator('sub_product')
    def validate_empty_sub_product(cls, v):
        return validate_empty("Sub-Product name", v)

    @validator('environment')
    def validate_empty_environment(cls, v):
        return validate_empty("Environment name", v)

    @validator('test_type')
    def validate_empty_test_type(cls, v):
        return validate_empty("TestType name", v)

    @validator('release')
    def validate_empty_release(cls, v):
        return validate_empty("Release name", v)

    @validator('branch')
    def validate_empty_branch(cls, v):
        return validate_empty("Branch name", v)

    @validator('suite')
    def validate_empty_suite(cls, v):
        return validate_empty("Suite name", v)


class TestCase(BaseModel):
    testno: int
    testname: str
    status: TCStatusType
    duration: Optional[float] = 0
    message: Optional[str] = ""

    @validator('testname')
    def validate_empty_testname(cls, v):
        return validate_empty("Test name", v)

    @validator('status')
    def validate_empty_status(cls, v):
        return validate_empty("Status", v)


class TestCases(BaseModel):
    testcases: List[TestCase]


def validate_empty(parameter_name, parameter_value):
    if '' == parameter_value.strip():
        raise ValueError(f'{parameter_name} cannot be empty')
    return parameter_value
