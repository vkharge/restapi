from fastapi import APIRouter, Depends, status
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from app.crud import sub_product_crud
from app.common.db_connection import get_db
from app.api_routers.apikey_auth import get_admin_api_key, get_user_api_key
from app.schemas import req_schemas


router = APIRouter(
    prefix="/sub-products",
    tags=["Sub-Product"],
    include_in_schema=True
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_sub_product(payload: req_schemas.SubProduct,
                             db: Session = Depends(get_db),
                             api_key: APIKey = Depends(get_admin_api_key)):
    return sub_product_crud.create_sub_product(payload, db)


@router.get("/")
async def read_sub_products(db: Session = Depends(get_db),
                            api_key: APIKey = Depends(get_user_api_key)):
    return sub_product_crud.get_sub_products(db)


@router.get("/{sub_product_id}")
async def read_sub_product_by_id(sub_product_id: int,
                                 db: Session = Depends(get_db),
                                 api_key: APIKey = Depends(get_user_api_key)):
    return sub_product_crud.get_sub_product_by_id(sub_product_id, db)


@router.get("/name/{sub_product_name}")
async def read_sub_product_by_name(sub_product_name: str,
                                   db: Session = Depends(get_db),
                                   api_key: APIKey =
                                   Depends(get_user_api_key)):
    return sub_product_crud.get_sub_product_by_name(sub_product_name, db)


@router.delete("/{sub_product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_sub_product(sub_product_id: int,
                             db: Session = Depends(get_db),
                             api_key: APIKey = Depends(get_admin_api_key)):
    return sub_product_crud.delete_sub_product(sub_product_id, db)


@router.put("/{sub_product_id}", status_code=status.HTTP_202_ACCEPTED)
async def update_sub_product(sub_product_id: int,
                             payload: req_schemas.Product,
                             db: Session = Depends(get_db),
                             api_key: APIKey = Depends(get_admin_api_key)):
    return sub_product_crud.update_sub_product(sub_product_id, payload, db)
