from fastapi import APIRouter, Depends, status
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from app.crud import suite_crud
from app.common.db_connection import get_db
from app.api_routers.apikey_auth import get_user_api_key, get_admin_api_key
from app.schemas import req_schemas


router = APIRouter(
    prefix="/suites",
    tags=["Suite"]
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_suite(payload: req_schemas.Suite,
                       db: Session = Depends(get_db),
                       api_key: APIKey = Depends(get_user_api_key)):
    return suite_crud.create_suite(payload, db)


@router.get("/")
async def read_suites(db: Session = Depends(get_db),
                      api_key: APIKey = Depends(get_user_api_key)):
    return suite_crud.get_suites(db)


@router.get("/{suite_id}")
async def read_suite(suite_id: int, db: Session = Depends(get_db),
                     api_key: APIKey = Depends(get_user_api_key)):
    return suite_crud.get_suite(suite_id, db)


@router.delete("/{suite_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_suite(suite_id: int, db: Session = Depends(get_db),
                       api_key: APIKey = Depends(get_admin_api_key)):
    return suite_crud.delete_suite(suite_id, db)


@router.put("/{suite_id}", status_code=status.HTTP_202_ACCEPTED)
async def update_suite(suite_id: int, payload: req_schemas.Suite,
                       db: Session = Depends(get_db),
                       api_key: APIKey = Depends(get_user_api_key)):
    return suite_crud.update_suite(suite_id, payload, db)
