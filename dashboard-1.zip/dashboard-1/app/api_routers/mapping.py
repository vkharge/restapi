from fastapi import APIRouter, Depends, status
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from app.crud import mapping_crud
from app.common.db_connection import get_db
from app.api_routers.apikey_auth import get_admin_api_key
from app.schemas import req_schemas, res_schemas


router = APIRouter(
    prefix="/mappings",
    tags=["Mappings"],
    include_in_schema=True
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_mapping(payload: req_schemas.Mapping,
                         db: Session = Depends(get_db),
                         api_key: APIKey = Depends(get_admin_api_key)):
    mapping = mapping_crud.create_mapping(payload, db)
    mapping_out = res_schemas.Mapping(id=mapping.id, **payload.dict())
    return mapping_out


@router.get("/")
async def read_mappings(db: Session = Depends(get_db),
                        api_key: APIKey = Depends(get_admin_api_key)):
    return mapping_crud.get_mappings(db)


@router.get("/{mapping_id}")
async def read_mapping(mapping_id: int, db: Session = Depends(get_db),
                       api_key: APIKey = Depends(get_admin_api_key)):
    return mapping_crud.get_mapping(mapping_id, db)


@router.delete("/{mapping_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_mapping(mapping_id: int, db: Session = Depends(get_db),
                         api_key: APIKey = Depends(get_admin_api_key)):
    return mapping_crud.delete_mapping(mapping_id, db)


@router.put("/{mapping_id}", status_code=status.HTTP_202_ACCEPTED)
async def update_mapping(mapping_id: int, payload: req_schemas.Mapping,
                         db: Session = Depends(get_db),
                         api_key: APIKey = Depends(get_admin_api_key)):
    mapping = mapping_crud.update_mapping(mapping_id, payload, db)
    mapping_out = res_schemas.Mapping(id=mapping_id, **payload.dict())
    return mapping_out
