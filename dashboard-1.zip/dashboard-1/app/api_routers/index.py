from fastapi import APIRouter
from app.common import config


router = APIRouter(include_in_schema=False)


@router.get("/")
async def index():
    url = f"{config.app.protocol}://{config.app.hostname}:{config.app.port}"

    return {
        "message": "Welcome to Rest QA Report Server Endpoint",
        "swagger_ui": f"{url}/docs",
        "redoc_ui": f"{url}/redocs",
    }
