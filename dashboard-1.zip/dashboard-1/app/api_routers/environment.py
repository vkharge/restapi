from fastapi import APIRouter, Depends, status
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from app.crud import environment_crud
from app.common.db_connection import get_db
from app.api_routers.apikey_auth import get_admin_api_key, get_user_api_key
from app.schemas import req_schemas


router = APIRouter(
    prefix="/environments",
    tags=["Environment"],
    include_in_schema=True
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_environment(payload: req_schemas.Environment,
                             db: Session = Depends(get_db),
                             api_key: APIKey = Depends(get_admin_api_key)):
    return environment_crud.create_environment(payload, db)


@router.get("/")
async def read_environments(db: Session = Depends(get_db),
                            api_key: APIKey = Depends(get_user_api_key)):
    return environment_crud.get_environments(db)


@router.get("/{environment_id}")
async def read_environment_by_id(environment_id: int,
                                 db: Session = Depends(get_db),
                                 api_key: APIKey = Depends(get_user_api_key)):
    return environment_crud.get_environment_by_id(environment_id, db)


@router.get("/name/{environment_name}")
async def read_environment_by_name(environment_name: str,
                                   db: Session = Depends(get_db),
                                   api_key: APIKey =
                                   Depends(get_user_api_key)):
    return environment_crud.get_environment_by_name(environment_name, db)


@router.delete("/{environment_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_environment(environment_id: int,
                             db: Session = Depends(get_db),
                             api_key: APIKey = Depends(get_admin_api_key)):
    return environment_crud.delete_environment(environment_id, db)


@router.put("/{environment_id}", status_code=status.HTTP_202_ACCEPTED)
async def update_environment(environment_id: int,
                             payload: req_schemas.Environment,
                             db: Session = Depends(get_db),
                             api_key: APIKey = Depends(get_admin_api_key)):
    return environment_crud.update_environment(environment_id, payload, db)
