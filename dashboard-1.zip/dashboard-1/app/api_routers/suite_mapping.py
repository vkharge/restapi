from fastapi import APIRouter, Depends
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from app.crud import suite_mapping_crud
from app.common.db_connection import get_db
from app.api_routers.apikey_auth import get_admin_api_key


router = APIRouter(
    prefix="/suite_mapping",
    tags=["SuiteMappings"],
    include_in_schema=True
)


@router.get("/")
async def read_suite_mappings(db: Session = Depends(get_db),
                              api_key: APIKey = Depends(get_admin_api_key)):
    return suite_mapping_crud.get_suite_mappings(db)


@router.get("/{suite_mapping_id}")
async def read_suite_mapping(suite_mapping_id: int,
                             db: Session = Depends(get_db),
                             api_key: APIKey = Depends(get_admin_api_key)):
    return suite_mapping_crud.get_suite_mapping(suite_mapping_id, db)
