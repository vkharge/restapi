from fastapi import APIRouter, Request, Depends, Form
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.common.db_connection import get_db
from app.crud.ui_common import get_products_for_given_org_id, \
    get_sub_products_for_given_product_id

router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")


@router.post('/get_products_for_given_org_id')
async def get_filters_products_for_given_org_id(request: Request, org_id: int = Form(...), db: Session = Depends(get_db)):
    # data = request.form()
    # print(data)
    # import pdb
    # pdb.set_trace()
    # org_id = int(request.form["org_id"])
    print(org_id)
    return get_products_for_given_org_id(org_id, db)


@router.post('/get_sproducts_for_given_prod_id')
async def get_filters_sub_products_for_given_prod_id(request: Request, org_id: int = Form(...), product_id: int = Form(...), db: Session = Depends(get_db)):
    # import pdb
    # pdb.set_trace()
    # org_id = int(request.form["org_id"])
    # product_id = int(request.form["product_id"])
    return get_sub_products_for_given_product_id(org_id, product_id, db)