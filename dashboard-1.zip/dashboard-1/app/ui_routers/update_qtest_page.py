from fastapi import APIRouter, Request, Depends, Form
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.common.data import *
from app.common.db_connection import get_db
from app.crud.ui_common import get_ops_by_name, get_search_filter_vals_by_id, \
    get_suite_execution, get_suite_testcase_execution_by_suite_id

router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")


@router.get('/get_qtest_folders')
async def get_qtest_folders(request: Request, id, db: Session = Depends(
    get_db)):

    if id == "#":
        selected = "true"
        opened = "true"

        # Based on project name
            # Fetch ID
            # Folder Details [name, id, type, parent]
        #        element = {'type': type_of_record, 'id': element_id, 'parentId': parentId, 'name': name,
        #           'testLabPath': testLabPath, 'status': status}



    return {"data": id}


