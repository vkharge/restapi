from fastapi import APIRouter, Request, Depends, Form
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.common.data import *
from app.common.db_connection import get_db
from app.crud.ui_common import get_ops_by_name, get_search_filter_vals_by_id, \
    get_suite_execution, get_suite_testcase_execution_by_suite_id

router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")

@router.get('/')
async def home_page(request: Request, db: Session = Depends(get_db)):
    org, product, sub_product = get_ops_by_name(DEFAULT_ORG, DEFAULT_PRODUCT,
                                                DEFAULT_SUB_PRODUCT, db)

    orgs, products, sub_products, envs, test_types =\
        get_search_filter_vals_by_id(org.id, product.id, sub_product.id, db)

    header, body = get_suite_execution(org.id, product.id, sub_product.id,
                                       "ALL", "ALL", db)

    return templates.TemplateResponse("home_page.html", {
        "request": request,
        "page_title": PAGE_TITLE,
        "page_header": PAGE_HEADER,
        "default_org": DEFAULT_ORG,
        "default_product":  DEFAULT_PRODUCT,
        "default_sub_product":  DEFAULT_SUB_PRODUCT,
        "default_env": DEFAULT_ENV,
        "default_test_type": DEFAULT_TEST_TYPE,
        "orgs": orgs,
        "products": products,
        "sub_products": sub_products,
        "environments": envs,
        "test_types": test_types,
        "table_header": header,
        "table_body": body
        }
    )


@router.post('/get_suite_execution')
async def get_suite_execution_results(request: Request, org_id: int = Form(...), product_id: int = Form(...), sub_product_id: int = Form(...), environment_name: str = Form(...), test_type_name: str = Form(...), db: Session = Depends(get_db)):
    # org_id = int(request.form["org_id"])
    # product_id = int(request.form["product_id"])
    # sub_product_id = int(request.form["sub_product_id"])
    # environment_name = request.form["environment_name"]
    # test_type_name = request.form["test_type_name"]

    #print(org_id, product_id, sub_product_id, environment_name,
    # test_type_name)
    header, body = get_suite_execution(org_id, product_id, sub_product_id,
                                       environment_name, test_type_name, db)

    return templates.TemplateResponse("suite_execution_table.html", {
        "request": request,
        "table_header": header,
        "table_body": body}
                                      )


@router.get('/get_testcase_execution')
async def get_testcase_execution_results(request: Request, suite_id: int,
                                         db: Session = Depends(get_db)):
    #suite_id = int(request.args['suite_id'])
    #print(suite_id)

    suite_header, suite_body, testcase_header, testcase_body = \
        get_suite_testcase_execution_by_suite_id(suite_id, db)

    #print(testcase_header)

    #print(testcase_body)

    return templates.TemplateResponse("testcase_page.html", {
        "request":  request,
        "page_title": PAGE_TITLE + " - TestCases",
        "page_header": PAGE_HEADER,
        "suite_body": suite_body,
        "testcase_header": testcase_header,
        "testcase_body": testcase_body
    }

    )

@router.get('/update_qtest')
async def get_update_qtest(request: Request, suite_id: int, db: Session =Depends(get_db)):
    #print(suite_id)

    suite_header, suite_body, testcase_header, testcase_body = \
        get_suite_testcase_execution_by_suite_id(suite_id, db)

    #print(testcase_header)

    #print(testcase_body)

    return templates.TemplateResponse("update_qtest_page.html", {
        "request":  request,
        "page_title": PAGE_TITLE + " - Update qTest",
        "page_header": PAGE_HEADER,
        "suite_body": suite_body,
        "testcase_header": testcase_header,
        "testcase_body": testcase_body
    })




