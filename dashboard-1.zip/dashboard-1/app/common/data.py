
PAGE_TITLE = "QA Dashboard"
PAGE_HEADER = "Dolby QA Dashboard"
DEFAULT_ORG = "DOLBY.IO"
DEFAULT_PRODUCT = "DOLBYON"
DEFAULT_SUB_PRODUCT = "ALL"
DEFAULT_ENV = "ALL"
DEFAULT_TEST_TYPE = "ALL"


SUITE_HEADER = ["Id", "Date", "Org", "Product", "SubProduct", "Suite",
                "Status", "Total", "Passed", "Failed", "Skipped",
                "Environment", "Type", "Logs", "Duration"]

TESTCASE_HEADER = ["TestNo", "TestName", "Status", "Duration", "Message"]



QTEST_PROJECTS = ["AP3"]