import json


class Config:
    _instance = None
    _initialize = False

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(Config, cls).__new__(
                                cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        if not Config._initialize:
            Config._initialize = True
            self.config = read_json_config(config_file="config.json")


def read_json_config(config_file):
    with open(config_file) as file:
        config_content = json.load(file)
    return Dict2Obj(config_content)


class Dict2Obj:
    def __init__(self, d):
        for a, b in d.items():
            if isinstance(b, (list, tuple)):
                setattr(self, a, [
                    Dict2Obj(x) if isinstance(x, dict) else x for x in b
                ])
            else:
                setattr(self, a, Dict2Obj(b) if isinstance(b, dict) else b)

    def __str__(self):
        return f"{self.__dict__}"
