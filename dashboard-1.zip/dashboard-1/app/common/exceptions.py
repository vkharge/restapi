from fastapi import status, HTTPException


class DuplicateEntity(HTTPException):
    def __init__(self, message):
        self.status_code = status.HTTP_409_CONFLICT
        self.detail = message


class NotFound(HTTPException):
    def __init__(self, message):
        self.status_code = status.HTTP_404_NOT_FOUND
        self.detail = message


class CannotDelete(HTTPException):
    def __init__(self, message):
        self.status_code = status.HTTP_409_CONFLICT
        self.detail = message
