from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from urllib.parse import quote
from app.common import config

db_user = config.db.username
db_pass = config.db.password
db_hostname = config.db.hostname
db_port = config.db.port
db_name = config.db.name
driver = config.db.driver

SQLALCHEMY_DATABASE_URL = f"mysql+{driver}://{db_user}:{quote(db_pass)}@" \
                          f"{db_hostname}:{db_port}/{db_name}"

engine = create_engine(SQLALCHEMY_DATABASE_URL)

SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)

Base = declarative_base()


def get_db():
    db = None
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()
