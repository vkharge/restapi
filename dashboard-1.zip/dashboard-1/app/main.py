from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.common import doc
from app.common.db_connection import engine
from app.common.doc import prefix
from app.db_models import models
from app.api_routers import testcase, suite, index, product, org, \
    sub_product, test_type, environment, validate_token, suite_mapping, \
    mapping
from app.ui_routers import common, home_page, update_qtest_page

models.Base.metadata.create_all(engine)

app = FastAPI(
    title=doc.title,
    description=doc.description,
    version=doc.version,
    contact=doc.contact,
    openapi_tags=doc.tags_metadata,
    debug=True
)


app.mount("/static", StaticFiles(directory="app/static"), name="static")


#app.include_router(index.router, prefix=prefix)
app.include_router(common.router)
app.include_router(home_page.router)
app.include_router(update_qtest_page.router)


app.include_router(validate_token.router, prefix=prefix)
app.include_router(org.router, prefix=prefix)
app.include_router(product.router, prefix=prefix)
app.include_router(sub_product.router, prefix=prefix)
app.include_router(test_type.router, prefix=prefix)
app.include_router(environment.router, prefix=prefix)
app.include_router(mapping.router, prefix=prefix)
app.include_router(suite_mapping.router, prefix=prefix)
app.include_router(suite.router, prefix=prefix)
app.include_router(testcase.router, prefix=prefix)
