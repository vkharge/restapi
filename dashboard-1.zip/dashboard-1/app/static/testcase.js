$(document).ready(function () {

    $('#testcase-table').DataTable({
        lengthMenu: [[25, 50, 100, -1], [25, 50, 100, "All"]],
        pagingType: "full_numbers"
    });

});


