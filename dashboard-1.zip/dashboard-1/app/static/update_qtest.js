$(document).ready(function () {

    $('#testcase-table').DataTable({
        lengthMenu: [[25, 50, 100, -1], ["All", 25, 50, 100]],
        pagingType: "full_numbers"
    });

    $('#qtest-tree').jstree({
    'core':{
        'multiple': false,

        'data' : {
            'url' : '/get_qtest_folders',
            'data' : function (node) {
                return { 'id' : node.id };
            }
        }
    }
});


    $('.selection-btn').click(function (e) {
        e.preventDefault();
        $(this).addClass('active').siblings().removeClass('active');
        var selectedButtonName = $(this).attr('name');
        //console.log(selectedButtonName);
        //allRows = $('#testcase-table tbody tr');
        //console.log(allRows);
        allRows = $('#testcase-table tbody tr').filter(function( index ) {
             col = $(this).children('.col-qteststatus').text();
             return col != '';
        });
        console.log(allRows);
        if(selectedButtonName === "all"){
            allRows.addClass('selected');
        }else if(selectedButtonName === "none"){
            allRows.removeClass('selected');
        }else if(selectedButtonName === "passed"){
            allRows.removeClass('selected');
            allRows.each(function (index, value) {
                status = $(this).children('.status').text();
                // console.log(index + ":" + status);
                // console.log($(this));
                if(status === "PASSED"){
                    $(this).addClass('selected')
                }
            });
        }else if(selectedButtonName === "failed"){
            allRows.removeClass('selected');
            allRows.each(function (index, value) {
                status = $(this).children('.status').text();
                if(status === "FAILED"){
                    $(this).addClass('selected')
                }
            });
        }

    });

    $('#testcase-table tbody').on('click', 'tr', function () {
        console.log("Clicked")
        $(this).toggleClass('selected');
    });

});


