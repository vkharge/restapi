$(document).ready(function () {

    $('#suite-execution').DataTable({
        order: [[0, "desc"]],
        lengthMenu: [[25, 50, 100, -1], [25, 50, 100, "All"]],
        pagingType: "full_numbers"
    });

    $('#filter-form').submit(function (event) {

        event.preventDefault();
        data = {
				org_id : $("#org").val(),
				product_id : $("#product").val(),
				sub_product_id : $("#sub-product").val(),
				environment_name : $('#environment').find('option:selected').text(),
				test_type_name : $('#test-type').find('option:selected').text()
			};

        $('#dvLoading').fadeIn(300);
        $.ajax({
            url: "/get_suite_execution",
            method: "POST",
            data: data,
            success: function (response) {
                $('.suite-execution-content').html(response);
                $('#dvLoading').fadeOut(500);
                $('#suite-execution').DataTable({
                    order: [[0, "desc"]],
                    "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
                    "pagingType": "full_numbers",
                    "destroy": true,
                });
            },
            error: function(response) {
                console.log("Error" + response['responseText']);
                $('#dvLoading').fadeOut(500);
            },
        });
     });

    $("#suite-execution").on("click",".view-testcases", function(){
        var myWindow = window.open();
        id = $(this).attr('id');
        var url = location.protocol + '//' + location.host + '/get_testcase_execution?suite_id='+ id;
        myWindow.location.href = url;
    });

    $("#suite-execution").on("click",".update-qtest", function(){
        var myWindow = window.open();
        id = $(this).attr('id');
        var url = location.protocol + '//' + location.host +
        '/update_qtest?suite_id='+ id;
        myWindow.location.href = url;
    });

});


