$(document).ready(function () {

    $("#org").selectpicker();
    $("#product").selectpicker();
    $("#sub-product").selectpicker();
    $("#environment").selectpicker();
    $("#test-type").selectpicker();

    $('.plain-table').DataTable({
        "paging":   false,
        "ordering": false,
        "info":     false,
        "searching": false
    });

    function load_products(id) {
        $.ajax({
            url: "/get_products_for_given_org_id",
            method: "POST",
            data: { org_id: id },
            dataType: "json",
            success: function (data) {
                var html = "";
                $.each(data, function(index, product) {
                    if (product.id == 0) {
                        html += '<option value="' + product.id + '" selected="selected">' + product.name + "</option>";
                    } else {
                        html += '<option value="' + product.id + '">' + product.name + "</option>";
                    }
                });

                $("#product").html(html);
                $("#product").selectpicker("refresh");
            },
        });
    }

    function load_sub_products(org_id, product_id) {
        $.ajax({
            url: "/get_sproducts_for_given_prod_id",
            method: "POST",
            data: { org_id: org_id,  product_id: product_id},
            dataType: "json",
            success: function (data) { //alert(category_id)
                var html = "";
                $.each(data, function(index, sub_product) {
                    if (sub_product.id == 0) {
                        html += '<option value="' + sub_product.id + '" selected="selected">' + sub_product.name + "</option>";
                    } else {
                        html += '<option value="' + sub_product.id + '">' + sub_product.name + "</option>";
                    }
                });
                $("#sub-product").html(html);
                $("#sub-product").selectpicker("refresh");

            },
        });
    }

    $(document).on("change", "#org", function () {
        var org_id = $("#org").val();
        load_products(org_id);
        load_sub_products(0, 0);

    });

    $(document).on("change", "#product", function () {
        var org_id = $("#org").val();
        var product_id = $("#product").val();
        load_sub_products(org_id, product_id);
    });
});


