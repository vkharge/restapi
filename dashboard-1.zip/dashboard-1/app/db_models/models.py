import enum

from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, \
    func, Enum, Float

from app.common.db_connection import Base


class StatusType(str, enum.Enum):
    passed = "PASSED"
    failed = "FAILED"
    skipped = "SKIPPED"

    def __str__(self):
        return '%s' % self.value

class TCStatusType(str, enum.Enum):
    passed = "PASSED"
    failed = "FAILED"
    skipped = "SKIPPED"
    error = "ERROR"

    def __str__(self):
        return '%s' % self.value

class Org(Base):
    __tablename__ = "orgs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), unique=True, index=True, nullable=False)


class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), unique=True, index=True, nullable=False)


class SubProduct(Base):
    __tablename__ = "sub_products"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), unique=True, index=True, nullable=False)


class Mapping(Base):
    __tablename__ = "mappings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    org_id = Column('org_id', Integer(), ForeignKey('orgs.id'),
                    nullable=False)
    product_id = Column('product_id', Integer(), ForeignKey('products.id'),
                        nullable=False)
    sub_product_id = Column('sub_product_id', Integer(),
                            ForeignKey('sub_products.id'), nullable=False)


class Environment(Base):
    __tablename__ = "environments"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), unique=True, index=True, nullable=False)


class TestType(Base):
    __tablename__ = "test_types"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), unique=True, index=True, nullable=False)

    def __str__(self):
        return '%s' % self.value


class SuiteMapping(Base):
    __tablename__ = "suite_mappings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    mapping_id = Column('mapping_id', Integer(),
                        ForeignKey('mappings.id'), nullable=False)
    environment = Column(String(255), nullable=False)
    test_type = Column(String(255), nullable=False)
    release = Column(String(255), nullable=False)
    branch = Column(String(255), nullable=False)
    suite = Column(String(255), nullable=False)


class Suite(Base):
    __tablename__ = "suites"
    id = Column(Integer, primary_key=True, autoincrement=True)
    suite_mapping_id = Column('suite_mapping_id', Integer(),
                              ForeignKey('suite_mappings.id'),
                             nullable=False)
    branch = Column(String(255), default="")
    build = Column(String(255), default="")
    total = Column(Integer, nullable=False)
    passed = Column(Integer, nullable=False)
    failed = Column(Integer, nullable=False)
    skipped = Column(Integer, nullable=False)
    status = Column(Enum(StatusType), nullable=False)
    report_url = Column(String(1000), default="")
    console_url = Column(String(1000), default="")
    log_url = Column(String(1000), default="")
    duration = Column(Float, default=0)
    infra = Column(String(1000), default="")
    created = Column(DateTime(timezone=True), nullable=False,
                     server_default=func.now())

    class Config():
        orm_mode = True


class TestCase(Base):
    __tablename__ = "testcases"
    id = Column(Integer, primary_key=True, autoincrement=True)
    suite_id = Column('suite_id', Integer(), ForeignKey('suites.id'),
                      nullable=False)
    testno = Column(Integer, nullable=False)
    testname = Column(String(2000), nullable=False)
    status = Column(Enum(TCStatusType), nullable=False)
    duration = Column(Float, default=0)
    message = Column(String(10000), default="")

    class Config():
        orm_mode = True
