import pytest
import requests
from .config import *

endpoint = f"{base_path}/orgs"

def test_create_org():
    payload = {
        "name": "DOLBY.IO"
    }
    response = requests.get(endpoint, headers=user_header)
    json = response.json()
    if json["count"] != 0:
        pytest.fail(f"Org Gets is not empty: \n {json}")


    #requests.post()

