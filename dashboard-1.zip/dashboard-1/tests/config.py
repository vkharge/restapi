
base_path = "http://127.0.0.1:8001/api/v1"

USER_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJyZWFkb25se" \
               "XVzZXIifQ.v_6EWKcDWe6k40HxjGG6tN-69Ruw5BrYUcl_nvjRSEo"
ADMIN_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbnVz" \
                "ZXJhY2Nlc3MifQ.JmramKoSle2GeMQpox0AZURj_9_4fIJkgvOxZVQ7SU0"

API_KEY_NAME = "access_token"


admin_header = {
    API_KEY_NAME : ADMIN_API_KEY
}

user_header = {
    API_KEY_NAME : USER_API_KEY
}