

class Dashboard():

    def __init__(self, token):
        self.token = token
        self.org = None
        self.product = None
        self.sub_product = None
        self.environment = None
        self.test_type = None
        self.release = None
        self.branch = None
        self.build = None
        self.suite = None
        self.debug = False

    def validate_token(self):
        "/validate-token"
        pass

    def validate_attributes(self):
        pass

    def push_execution_details_using_junit(self, junit_xml):
        pass

    def push_suite_details(self):
        pass

    def push_test_details(self):
        pass

    def push_tests_details(self):
        pass