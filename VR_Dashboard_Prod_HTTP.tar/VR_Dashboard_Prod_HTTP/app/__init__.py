# Import flask and template operators
# importing BackgroundScheduler
from apscheduler.schedulers.background import BackgroundScheduler
from flask import Flask, render_template
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import OperationalError

# local imports
from config import app_config

# db variable initialization
db = SQLAlchemy()


def job_scheduler(myapp):
    with myapp.app_context():
        from app.main.jenkins_handler import jenkins_job_scheduler
        jenkins_job_scheduler()


def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(app_config[config_name])

    print('FLASK_ENV =', app.config['FLASK_ENV'])
    print('SQLALCHEMY_DATABASE_URI = ', app.config['SQLALCHEMY_DATABASE_URI'])

    Bootstrap(app)
    db.init_app(app)

    from .main import main as main_blueprint
    # Register Blueprint
    app.register_blueprint(main_blueprint, url_prefix='/')

    # Sample HTTP error handling
    @app.errorhandler(404)
    def not_found(error):
        msg_1 = "Dashboard doesn't have this URL"
        msg_2 = "We couldn't find what you were looking for."
        return render_template('error.html', msg_1=msg_1, msg_2=msg_2), 404

    @app.errorhandler(500)
    def internal_server_error(error):
        print('ERROR >>>>>>> ')
        print(error)
        if isinstance(error, OperationalError):
            msg_1 = 'Cannot connect to MySQL DB'
            msg_2 = 'The Application encountered an Error while connecting to MySQL DB'
        else:
            msg_1 = 'Internal Server Error Occurred'
            msg_2 = 'There is an exception in the server'
        return render_template('error.html', msg_1=msg_1, msg_2=msg_2), 500

    app.register_error_handler(OperationalError, internal_server_error)
    app.register_error_handler(Exception, internal_server_error)

    # init BackgroundScheduler job
    scheduler = BackgroundScheduler()
    # in your case you could change seconds to hours
    scheduler.add_job(lambda: job_scheduler(app), trigger='interval', minutes=1)
    scheduler.start()

    try:
        # To keep the main thread alive
        return app
    except:
        # shutdown if app occurs except
        scheduler.shutdown()





