from . import db


class Suites(db.Model):
    __tablename__ = 'suites'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    suiteid = db.Column(db.String, db.ForeignKey('testcases.suiteid'))
    time = db.Column(db.TIMESTAMP)
    date = db.Column(db.Date)
    product = db.Column(db.String)
    feature = db.Column(db.String)
    nsxbuild = db.Column(db.Integer)
    nsxbranch = db.Column(db.String)
    nsxbuildtype = db.Column(db.String)
    nsxreleasetype = db.Column(db.String)
    nsxbuildkind = db.Column(db.String)
    nsxversion = db.Column(db.String)
    esxbuild = db.Column(db.Integer)
    esxbranch = db.Column(db.String)
    esxbuildtype = db.Column(db.String)
    esxversion = db.Column(db.String)
    esxreleasetype = db.Column(db.String)
    esxbuildkind = db.Column(db.String)
    vcbuild = db.Column(db.String)
    vcbranch = db.Column(db.String)
    vcbuildtype = db.Column(db.String)
    vcversion = db.Column(db.String)
    vcreleasetype = db.Column(db.String)
    vcbuildkind = db.Column(db.String)
    status = db.Column(db.String)
    totalcases = db.Column(db.Integer)
    executed = db.Column(db.Integer)
    passed = db.Column(db.Integer)
    failed = db.Column(db.Integer)
    pending = db.Column(db.Integer)
    core = db.Column(db.String)
    suitereport = db.Column(db.String)
    jenkinslog = db.Column(db.String)
    duration = db.Column(db.String)
    racetrack = db.Column(db.String)

    def __repr__(self):
        return '<Suites> {0}, {1}, {2}, {3}'.format(self.id, self.feature, self.date, self.nsxbranch)


class TestCases(db.Model):
    __tablename__ = 'testcases'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    suiteid = db.Column(db.String)
    testno = db.Column(db.Integer)
    testcasename = db.Column(db.String)
    status = db.Column(db.String)
    core = db.Column(db.String)
    time = db.Column(db.String)
    failedworkload = db.Column(db.String)
    testcasepath = db.Column(db.String)
    suites_relation = db.relationship('Suites', backref='testcases',
                                lazy='dynamic')

    def __repr__(self):
        return '<TestCases> {0}, {1}, {2}, {3}'.format(self.id, self.suiteid, self.testcasename, self.status)


class JenkinsBranches(db.Model):
    __tablename__ = 'jenkins_branches'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    branch = db.Column(db.String)

    def __init__(self, branch_name):
        self.branch = branch_name

    def __repr__(self):
        return '<JenkinsBranches> {0} {1}'.format(self.id, self.branch)


class ScheduledJobs(db.Model):
    __tablename__ = 'scheduled_jobs'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    jobs = db.Column(db.String)
    nsxbuild = db.Column(db.String)
    esxbuild = db.Column(db.String)
    wait = db.Column(db.String)
    kill_queued = db.Column(db.Boolean)
    kill_running = db.Column(db.Boolean)
    nsxbranch = db.Column(db.String)
    schedule_for_future = db.Column(db.Boolean)
    future_datetime = db.Column(db.String)
    status = db.Column(db.String)

    def __repr__(self):
        return '<ScheduledJobs> {0} {1}'.format(self.id, self.jobs)