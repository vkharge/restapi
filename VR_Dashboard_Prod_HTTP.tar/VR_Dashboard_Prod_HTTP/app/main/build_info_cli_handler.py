import paramiko
import traceback
from app.config_reader import get_buildweb_config

build_web_config = get_buildweb_config()

SSH_HOST_IP = build_web_config.get("SSH_HOST_IP")
SSH_HOST_USERNAME = build_web_config.get("SSH_HOST_USERNAME")
SSH_HOST_PASSWORD = build_web_config.get("SSH_HOST_PASSWORD")


def get_build_status(buildno):
    try:
        command = '/build/apps/bin/bld info ' + str(buildno) + ' | grep Status'
        stdin, stdout, stderr = ssh.exec_command(command)
        err = ''.join(stderr.readlines())
        out = ''.join(stdout.readlines())
        final_output = str(out)
        final_output = final_output.split(':')[1].strip()
        return final_output
    except IndexError as ie:
        print(ie)
        return 'Wrong Build Number'
    except Exception as e:
        print(e)
        traceback.print_exc()
        return 'Error Getting Build Info'


try:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(SSH_HOST_IP, username=SSH_HOST_USERNAME, password=SSH_HOST_PASSWORD)
    print("Connected to %s for firing Buildweb CLI" % SSH_HOST_IP)
except paramiko.AuthenticationException:
    traceback.print_exc()
    print('Failed to connect to {} due to wrong username/password'.format(SSH_HOST_IP))
    exit(1)
except:
    traceback.print_exc()
    print('Failed to connect to %s' % SSH_HOST_IP)
    exit(2)


# if __name__ == '__main__':
#     status = get_build_status('ob-10528128')
#     print(status)
