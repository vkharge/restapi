import jenkins
import datetime
from dateutil.relativedelta import relativedelta
import requests
from requests.auth import HTTPBasicAuth
import re
import traceback
import subprocess
import platform
from pyquery import PyQuery
from app import db
from app.models import ScheduledJobs
from .build_info_cli_handler import get_build_status
import dateutil.parser
from pytz import timezone
from app.config_reader import get_jenkins_config


def kill_queued_job(queued_job_id):
    # print('inside kill_queued_job with id', queued_job_id)
    server.cancel_queue(int(queued_job_id))


def kill_running_job(name, number):
    # print('inside kill_running_job with name {} and id {}'.format(name, number))
    server.stop_build(name, int(number))


def kill_scheduled_job(scheduled_job_id):
    record = ScheduledJobs.query.filter(ScheduledJobs.id == scheduled_job_id).first()
    if record:
        db.session.delete(record)
        db.session.commit()


def get_queued_jobs():
    data = []
    queued_jobs = server.get_queue_info()
    for job in queued_jobs:
        data.append(
            {
                'taskname': job['task']['name'],
                'queuedsince': get_time_interval(job['inQueueSince']),
                'id': job['id']
            })
    # print(queued_jobs, len(queued_jobs))
    return data


def get_time_interval(start_time):
    start_time = int(start_time)
    st = datetime.datetime.utcfromtimestamp(start_time / 1000)
    et = datetime.datetime.utcnow()
    # print('Start-Time :', st)
    # print('End-Time :', et)
    diff = relativedelta(et, st)
    s = "%dd %dh %dm %ds" % (diff.days, diff.hours, diff.minutes, diff.seconds)
    # print(s)
    return s


def get_suite_log(url):
    # print(url)
    url = url + 'Text'
    pattern = r"(Result URL[^:]*\: )(.*?http.*?)(\\n)"
    resp = requests.get(url, auth=HTTPBasicAuth(JENKINS_UN, JENKINS_PW))
    content = str(resp.content)
    # print(content)
    match = re.search(pattern, content, re.MULTILINE)
    # print('Match :', match)
    if match:
        suite_log_url = match.group(2).strip()
    else:
        suite_log_url = ''

    return suite_log_url


def get_jobs():
    jobs = server.get_jobs()
    return jobs


def start_job(nsxbuild, esxbuild, kill_queued, kill_running, job_name, nsxbranch):
    print('Inside Start Job with jobname :', job_name)
    print(nsxbuild, ':', esxbuild, ':', kill_queued, ':',  kill_running, ':',  job_name, ':',  nsxbranch)
    if kill_queued:
        qjobs = get_queued_jobs()
        for job in qjobs:
            if job['taskname'] == job_name:
                print('Found in Queued')
                kill_queued_job(job['id'])
    if kill_running:
        rjobs = get_running_jobs()
        for job in rjobs:
            rjobname = job[0].split(',')[0]
            if rjobname == job_name:
                print('Found in Running')
                kill_running_job(*job[0].split(','))

    parameters = {'nsxBuild': nsxbuild, 'esxBuild': esxbuild, 'nsxBranch': nsxbranch, 'token': JENKINS_TOKEN}
    print(parameters)
    if nsxbuild == '' and esxbuild == '':
        print('Starting Jobs Without Parameters')
        server.build_job(job_name, parameters={'token': JENKINS_TOKEN})

    else:
        print('Started Jobs With Parameters')
        server.build_job(job_name, parameters=parameters)


def start_jobs(jsonData):
    jobs = jsonData['jobs']
    nsxbuild = jsonData['nsxbuild']
    esxbuild = jsonData['esxbuild']
    wait = jsonData['wait']
    kill_queued = jsonData['kill_queued']
    kill_running = jsonData['kill_running']
    nsxbranch = jsonData['nsxbranch']

    for job in jobs:
        job_name = job.strip()
        print(job_name)
        start_job(nsxbuild, esxbuild, kill_queued, kill_running, job_name, nsxbranch)


def get_passed_failed_pending(url):
    try:
        if url == '':
            return [''] * 5
        ip = url.split('/')[2]
        if ping(ip):
            print("Pinging pass for IP :", ip)
            resp = requests.get(url)
            if resp.status_code != 200:
                return [''] * 5
            else:
                html = str(resp.content)
                pq = PyQuery(html)
                total = pq('td#total').text()
                passed = pq('td#passed').text()
                failed = pq('td#failed').text()
                executed = pq('td#executed').text()
                pending = pq('td#pending').text()
                return total, executed, passed, failed, pending
        else:
            print("Pinging fail for IP :", ip)
            return [''] * 5
    except Exception:
        # traceback.print_exc()
        return [''] * 5


def get_no_of_running_jobs():
    running_jobs = server.get_running_builds()
    return len(running_jobs)


def ping(ip):
    print("Pinging IP :", ip)
    operating_sys = platform.system()
    ping_command = ['ping', ip, '-n', '1'] if operating_sys == 'Windows' else ['ping', ip, '-c 1']
    shell_needed = True if operating_sys == 'Windows' else False

    ping_output = subprocess.run(ping_command,shell=shell_needed,stdout=subprocess.PIPE)
    success = ping_output.returncode
    return True if success == 0 else False


def get_running_jobs():
    job_data = []
    running_jobs = server.get_running_builds()

    # print(running_jobs)
    for job in running_jobs:
        data = []

        job_details = get_job_details(job['name'], job['number'])
        running_since = get_time_interval(job_details['timestamp'])

        # print("Running Since - ", running_since)
        # if running_since != '':
        #     days = int(running_since.strip().split(' ')[0][:-1])
        #     hours = int(running_since.strip().split(' ')[1][:-1])
        #     print('Days:', days, 'Hours:', hours)
        #     if days > 1 or (days == 1 and hours > 5):
        #         ''' Suite was running for more than 30 hours '''
        #         pass

        console_url = job['url'] + 'console'
        suite_log_url = get_suite_log(console_url)
        suite_report_url = suite_log_url + 'SuiteReport.html' if suite_log_url != '' else ''
        total, executed, passed, failed, pending = get_passed_failed_pending(suite_report_url)

        data.append(job['name'] + ',' + str(job['number']))  # Feature Name
        data.append(job['node'])  # Launcher
        data.append(console_url)  # Console Log
        data.append(suite_log_url)  # Suite Log
        data.append(suite_report_url)  # Suite Report
        data.append(passed)  # Passed
        data.append(failed)  # Failed
        data.append(pending)  # Pending
        data.append(total)
        data.append(running_since)  # Running Since
        if job_details['result'] == "ABORTED":
            data.append('')  # Already Killed Job
        else:
            data.append('X')  # Kill Job

        job_data.append(data)
    return job_data


def get_job_details(name, number):
    job = server.get_build_info(name, number)
    # print(job)
    return job


def schedule_jobs(jsonData):
    jobs = jsonData['jobs']
    nsxbuild = jsonData['nsxbuild']
    esxbuild = jsonData['esxbuild']
    wait = jsonData['wait']
    kill_queued = jsonData['kill_queued']
    kill_running = jsonData['kill_running']
    nsxbranch = jsonData['nsxbranch']
    schedule_for_future = jsonData['schedule_for_future']
    future_datetime = dateutil.parser.parse(jsonData['future_datetime'])
    timeZone = jsonData['timeZone']
    tz = timezone(timeZone)
    future_datetime = future_datetime.replace(tzinfo=None)
    future_datetime = tz.localize(future_datetime)

    print(future_datetime, ':', schedule_for_future, ':', nsxbranch)

    for job in jobs:
        record = ScheduledJobs()
        record.jobs = job
        record.nsxbuild = nsxbuild
        record.esxbuild = esxbuild
        record.wait = wait
        record.kill_queued = kill_queued
        record.kill_running = kill_running
        record.nsxbranch = nsxbranch
        record.schedule_for_future = schedule_for_future

        if schedule_for_future:
            record.future_datetime = str(future_datetime)
            record.status = job_status_dict['future']
        else:
            waiting_hrs = int(wait.split(' ')[0])
            future_wait_time = datetime.datetime.now(timezone('UTC')) + datetime.timedelta(hours=waiting_hrs)
            record.future_datetime = str(future_wait_time)
            record.status = job_status_dict['waiting']

        db.session.add(record)
        db.session.commit()


def get_scheduled_jobs():
    scheduled_headers = [ScheduledJobs.id, ScheduledJobs.jobs, ScheduledJobs.nsxbuild, ScheduledJobs.nsxbranch,
                         ScheduledJobs.esxbuild, ScheduledJobs.wait, ScheduledJobs.schedule_for_future,
                         ScheduledJobs.future_datetime, ScheduledJobs.kill_queued, ScheduledJobs.kill_running,
                         ScheduledJobs.status]
    data = ScheduledJobs.query.with_entities(*scheduled_headers).order_by(ScheduledJobs.id).all()

    scheduled_headers = [str(column).split('.')[1].capitalize() for column in scheduled_headers]
    return scheduled_headers, data


def jenkins_job_scheduler():
    print('Executing jenkins_job_scheduler at ', datetime.datetime.now())
    data = ScheduledJobs.query.order_by(ScheduledJobs.id).all()
    for record in data:
        status = record.status

        if status in [job_status_dict['started'], job_status_dict['wrong_build'], job_status_dict['failed'],
                      job_status_dict['error_getting_build_info'], job_status_dict['expired'],
                      job_status_dict['error_in_start']]:
            print('Should Delete the Record from the DB', record)
            kill_scheduled_job(record.id)

        else:
            now = datetime.datetime.now(timezone('UTC'))
            future_datetime = dateutil.parser.parse(record.future_datetime)
            future_datetime = future_datetime.astimezone(timezone('UTC'))
            print('Now:', now, 'future_datetime:', future_datetime)

            if record.schedule_for_future:
                print(record, 'This is scheduled for future')
                if now > future_datetime:
                    if record.wait != '0 hr':
                        waiting_hrs = int(record.wait.split(' ')[0])
                        future_wait_time = future_datetime + datetime.timedelta(hours=waiting_hrs)
                        check_for_build_and_start_the_job(now, record, future_wait_time)
                    else:
                        try:
                            start_job(record.nsxbuild, record.esxbuild, record.kill_queued, record.kill_running,
                                  record.jobs, record.nsxbranch)
                            print('Set Status to ', job_status_dict['started'])
                            set_record_status(record.id, job_status_dict['started'])
                        except:
                            print('Set Status to ', job_status_dict['error_in_start'])
                            set_record_status(record.id, job_status_dict['error_in_start'])

            else:
                print(record, 'This is a wait for build job')
                check_for_build_and_start_the_job(now, record, future_datetime)


def check_for_build_and_start_the_job(now, record, future_time):
    status_changed = False

    current_status = get_build_status(record.nsxbuild)

    if current_status in [job_status_dict['wrong_build'], job_status_dict['error_getting_build_info']]:
        print('Set Build Status to', current_status)
        set_record_status(record.id, current_status)
        status_changed = True
    elif current_status in ['sync-error', 'compile-error', 'dependency-error', 'not-needed', 'failed']:
        print('Set Build Status to ', job_status_dict['failed'])
        set_record_status(record.id, job_status_dict['failed'])
        status_changed = True
    elif current_status == 'succeeded':
        try:
            start_job(record.nsxbuild, record.esxbuild, record.kill_queued, record.kill_running,
                      record.jobs, record.nsxbranch)
            print('Set Status to ', job_status_dict['started'])
            set_record_status(record.id, job_status_dict['started'])
            status_changed = True
        except:
            print('Set Status to ', job_status_dict['error_in_start'])
            set_record_status(record.id, job_status_dict['error_in_start'])

    if now > future_time:
        if not status_changed:
            print('Set Status', job_status_dict['expired'])
            set_record_status(record.id, job_status_dict['expired'])


def set_record_status(job_id, status):
    rows_affected = ScheduledJobs.query.filter(ScheduledJobs.id == job_id).update(dict(status=status))
    print('Rows Affected by status changed :', rows_affected)
    db.session.commit()


jenkins_config = get_jenkins_config()
JENKINS_URL = jenkins_config.get("JENKINS_URL")
JENKINS_UN = jenkins_config.get("JENKINS_UN")
JENKINS_PW = jenkins_config.get("JENKINS_PW")
JENKINS_TOKEN = jenkins_config.get("JENKINS_TOKEN")

server = jenkins.Jenkins(JENKINS_URL, username=JENKINS_UN, password=JENKINS_PW)
job_status_dict = {'waiting': 'Waiting for Build to be available',
                   'started': 'Started the Job Successfully',
                   'failed': 'Build has Failed',
                   'future': 'It is scheduled for Future',
                   'wrong_build': 'Wrong Build Number',
                   'error_getting_build_info': 'Error Getting Build Info',
                   'expired': 'Time Lapsed ! Job Expired',
                   'error_in_start': 'Error Occured While Starting the Job'
                   }

if __name__ == "__main__":
    get_queued_jobs()

