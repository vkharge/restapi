from datetime import date, timedelta

from ..models import Suites, TestCases

date_format = '%m/%d/%Y'
date_format_for_input = '%Y-%m-%d'


class SearchValues:
    branch = 'All'
    feature = 'All'
    difference_between_dates = 14
    start_date = (date.today() - timedelta(days=difference_between_dates)).strftime(date_format_for_input)
    end_date = date.today().strftime(date_format_for_input)
    columns_to_select = [Suites.id, Suites.feature, Suites.nsxbranch, Suites.nsxbuild, Suites.date, Suites.status,
                         Suites.totalcases, Suites.executed, Suites.passed, Suites.failed, Suites.core,
                         Suites.duration, Suites.suitereport]
    status_column_no = columns_to_select.index(Suites.status)
    failed_column_no = columns_to_select.index(Suites.failed)
    feature_column_no = columns_to_select.index(Suites.feature)
    no_of_suites = 5
    no_of_runs = 10
    testcases_columns = [TestCases.id, TestCases.suiteid, TestCases.testcasename, TestCases.status, TestCases.core]

    def __init__(self):
        self.start_date = (date.today() - timedelta(days=self.difference_between_dates)).strftime(date_format_for_input)
        self.end_date = date.today()


# select_columns_dict = {
#     'Suites.id': Suites.id,
#     'Suites.suiteid': Suites.suiteid,
#     'Suites.time': Suites.time,
#     'Suites.date': Suites.date,
#     'Suites.product': Suites.product,
#     'Suites.feature': Suites.feature,
#     'Suites.nsxbuild': Suites.nsxbuild,
#     'Suites.nsxbranch': Suites.nsxbranch,
#     'Suites.nsxbuildtype': Suites.nsxbuildtype,
#     'Suites.nsxbuildkind': Suites.nsxbuildkind,
#     'Suites.nsxversion': Suites.nsxversion,
#     'Suites.nsxreleasetype': Suites.nsxreleasetype,
#     'Suites.esxbuild': Suites.esxbuild,
#     'Suites.esxbranch': Suites.esxbranch,
#     'Suites.esxbuildtype': Suites.esxbuildtype,
#     'Suites.esxversion': Suites.esxversion,
#     'Suites.esxreleasetype': Suites.esxreleasetype,
#     'Suites.esxbuildkind': Suites.esxbuildkind,
#     'Suites.vcbuild': Suites.vcbuild,
#     'Suites.vcbranch': Suites.vcbranch,
#     'Suites.vcbuildtype': Suites.vcbuildtype,
#     'Suites.vcversion': Suites.vcversion,
#     'Suites.vcreleasetype': Suites.vcreleasetype,
#     'Suites.vcbuildkind': Suites.vcbuildkind,
#     'Suites.status': Suites.status,
#     'Suites.totalcases': Suites.totalcases,
#     'Suites.executed': Suites.executed,
#     'Suites.passed': Suites.passed,
#     'Suites.failed': Suites.failed,
#     'Suites.pending': Suites.pending,
#     'Suites.core': Suites.core,
#     'Suites.suitereport': Suites.suitereport,
#     'Suites.jenkinslog': Suites.jenkinslog,
#     'Suites.duration': Suites.duration,
#     'Suites.racetrack': Suites.racetrack
# }
