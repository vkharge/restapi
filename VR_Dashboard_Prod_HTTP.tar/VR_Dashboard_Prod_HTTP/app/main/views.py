from flask import render_template, redirect, url_for, request, jsonify, Response, make_response
import traceback
import time
from collections import OrderedDict
from app.models import Suites, TestCases
from . import main
from .home_page_search_values import SearchValues
from .hpqc_handler import root_names, root_id, get_hpqc_folder_data_using_name, get_hpqc_folder_data_using_id, \
    get_test_cases_using_testset_id, get_test_cases_count, update_failed_testcase, update_passed_testcases, \
    get_hpqc_folders, get_hpqc_testsets
from app.main.jenkins_handler import get_running_jobs, get_queued_jobs, kill_queued_job, kill_running_job, get_jobs, \
    start_jobs, schedule_jobs, get_scheduled_jobs, kill_scheduled_job, get_no_of_running_jobs
from .jenkins_default_filters import get_branch_names_list, add_branch, delete_branch
from app.config_reader import get_dashboard_config


SearchValuesObj = SearchValues()
is_scheduler_running = False
dashboard_config = get_dashboard_config()

page_title = dashboard_config.get("page_title")
heading = dashboard_config.get("heading")
heading_image = dashboard_config.get("heading_image")
favicon = dashboard_config.get("favicon_image")
max_jobs_allowed_for_scheduling = int(dashboard_config.get('max_jobs_allowed_for_scheduling'))

ADMIN_PASSWORD_TO_CHANGE_DEFAULT_VALUES = dashboard_config.get('change_defaults_password')


@main.before_request
def before_request():
    if request.url.startswith('http://'):
        url = request.url.replace('http://', 'https://', 1)
        code = 301
        return redirect(url, code=code)


@main.route('/')
def home_page():
    global SearchValuesObj

    SearchValuesObj = SearchValues()
    print('\n\n\nIn Home_Page SearchValues are :', SearchValues.branch, SearchValues.feature,
          SearchValues.difference_between_dates, SearchValues.start_date,
          SearchValues.end_date, [str(i) for i in SearchValues.columns_to_select], '\n\n\n\n')
    columns, table_data = get_hometable_data()
    branch = get_distinct_branch()
    feature = get_distinct_feature()

    response = make_response(render_template('base.html', table_data=table_data, column_names=columns, str=str,
                           search_values=SearchValuesObj, branch=branch, feature=feature, enumerate=enumerate,
                           page_title=page_title, heading=heading, heading_image=heading_image, favicon=favicon))

    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"  # HTTP 1.1.
    response.headers["Pragma"] = "no-cache"  # HTTP 1.0.
    response.headers["Expires"] = "0"  # Proxies.

    return response


@main.route('/home')
def home():
    return redirect(url_for('main.home_page'))


# @main.route('/runfailedtestcases', methods=['POST'])
# def run_failed_testcases():
#     id = request.form.get('id')
#     data, headers, suitedata = get_test_case_data(id)


@main.route('/getbuilds')
def get_builds():
    id = request.args['id']
    data = get_build_data(id)
    headers = ("feature", "nsxbuild", "esxbuild", "vcbuild")
    data = dict(zip(headers, data))
    print(data)
    resp = jsonify(data)
    resp.status_code = 200
    return resp


@main.route('/check_password', methods=['POST'])
def check_password():
    print('Inside check password')
    admin_password = request.form.get('admin_password')
    print('Admin Password :', admin_password)
    if admin_password == ADMIN_PASSWORD_TO_CHANGE_DEFAULT_VALUES:
        return 'OK', 200
    else:
        return 'Failed Authentication', 401


@main.route('/gettestcases', methods=['GET'])
def gettestcases():
    print('Inside gettestcases')
    id = request.args['id']
    data, headers, suitedata = get_test_case_data(id)
    return render_template('testcase.html', data=data, headers=headers, len=len, suitedata=suitedata,
                           enumerate=enumerate, page_title=page_title, heading=heading,
                           heading_image=heading_image, favicon=favicon), 200


@main.route('/updatehpqc', methods=['GET', 'POST'])
def updatehpqc():
    if request.method == 'GET':
        testsuite_id = request.args['id']

        try:
            data, headers, suitedata = get_test_case_data(testsuite_id)
            return render_template('updatehpqc.html', data=data, headers=headers, len=len, range=range,
                                   suitedata=suitedata, enumerate=enumerate, url_for=url_for,
                                   page_title=page_title, heading=heading, heading_image=heading_image,
                                   favicon=favicon), 200
        except:
            traceback.print_exc()
            return 'Error While Getting TestCase Data from HPQC', 500

    if request.method == 'POST':
        jsonData = request.get_json()
        update_hpqc_data = jsonData['formData']
        print(update_hpqc_data)

        print(jsonData['testSetDbId'], jsonData['featureName'], jsonData['testerName'], jsonData['buildNumber'])

        testSetDbId = jsonData['testSetDbId']
        featureName = jsonData['featureName']
        testerName = jsonData['testerName']
        buildNumber = jsonData['buildNumber']

        passedCaseIds = []
        passedTestCaseNames = []

        for testCaseData in update_hpqc_data:
            print(testCaseData)
            testName = testCaseData['testName']
            testStatus = testCaseData['testStatus']
            testCaseId = testCaseData['testCaseId']

            if testStatus.lower() == 'failed':
                bugIds = testCaseData['bugId']
                try:
                    update_failed_testcase(testSetDbId, testerName, buildNumber, testCaseId, bugIds)
                except Exception as e:
                    print('Exception: ', e)
                    traceback.print_exc()
                    return 'Error While Updating Failed Test Case Data (' + testName + ') to HPQC', 500
            elif testStatus.lower() == 'passed':
                passedCaseIds.append(testCaseId)
                passedTestCaseNames.append(testName)

        if len(passedCaseIds) > 0:
            try:
                update_passed_testcases(testSetDbId, testerName, buildNumber, passedCaseIds)
            except Exception as e:
                print('Exception: ', e)
                traceback.print_exc()
                return 'Error While Updating Passed Test Cases Data (' + ' , '.join(passedTestCaseNames) + ') to HPQC', 500

        resp = Response(status=200)
        return resp


@main.route('/gethpqctestfoldersdata', methods=['GET'])
def gethpqctestfoldersdata():
    hpqc_id = request.args['id']
    print('HPQC id =', hpqc_id)
    if hpqc_id == '#':
        selected = "true"
        opened = "true"

        root_folder, number_of_elements = get_hpqc_folder_data_using_name(root_names[0])
        root_folder = root_folder[0]
        entities, noOfEntities = get_hpqc_folder_data_using_id(root_id)
        # print(entities)
        return render_template('hpqc_root_folder_for_update.html', len=len, root_folder=root_folder,
                           entities=entities, url_for=url_for, opened=opened, selected=selected), 200
    else:
        entities, noOfEntities = get_hpqc_folder_data_using_id(hpqc_id)
        # print(entities)
        return render_template('hpqc_folders_and_test_sets.html', entities=entities), 200


@main.route('/gethpqctestfoldersdataforreport', methods=['GET'])
def gethpqctestfoldersdataforreport():
    hpqc_id = request.args['id']
    templates = []
    print('HPQC id =', hpqc_id)
    if hpqc_id == '#':
        selected = "true"
        opened = "true"
        for root_name in root_names:
            root_folder, number_of_elements = get_hpqc_folder_data_using_name(root_name)
            root_folder = root_folder[0]
            # print(root_folder)
            # print('getting data with root_id :', root_folder['id'])
            entities, noOfEntities = get_hpqc_folder_data_using_id(root_folder['id'])
            # print(entities)
            templates.append(render_template('hpqc_root_folder_for_update.html', len=len, root_folder=root_folder,
                           entities=entities, url_for=url_for, opened=opened, selected=selected))
            selected = "false"
            opened = "false"
        # print(templates)
        return ' '.join(templates), 200

    else:
        entities, noOfEntities = get_hpqc_folder_data_using_id(hpqc_id)
        # print(entities)
        return render_template('hpqc_folders_and_test_sets.html', entities=entities), 200


@main.route('/gethpqctestcasedata')
def gethpqctestcasedata():
    testset_id = request.args['id']
    try:
        data = get_test_cases_using_testset_id(testset_id)
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Fetching Test Case Data from HPQC', 500

    resp = jsonify(data)
    resp.status_code = 200

    return resp


@main.route('/getfolderwisecountfortestfolder')
def getfolderwisecountfortestfolder():
    try:
        sTime = time.time()

        testfolder_id = request.args['id']
        testfolder_name = request.args['name']
        tableData = []
        folders_data, folders_count = get_hpqc_folders(testfolder_id)
        print(folders_count)
        [print(i) for i in folders_data]
        for test_folder in folders_data:
            test_folder_total_col, X = get_testcasewise_report_for_test_folders(test_folder['id'])
            tableData.append({'testset_name': test_folder['name'], 'testset_id': test_folder['id'],
                              'count_data': test_folder_total_col})
        totalColumn = calculate_total_column(tableData)

        return render_template('hpqc_report_table.html', tableData=tableData, totalColumn=totalColumn,
                               name=testfolder_name), 200
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Fetching Test Folder Counts from HPQC', 500


@main.route('/getcustomhpqcreportformitesh')
def getcustomhpqcreportformitesh():
    try:
        sTime = time.time()

        testfolder_id = request.args['id']
        folders_data, folders_count = get_hpqc_folders(testfolder_id)
        # print(folders_count)
        data = {"New Features": [], "Regression": []}

        # [print(i) for i in folders_data]
        for test_folder in folders_data:
            test_folder_data, test_folder_count = get_hpqc_folders(test_folder['id'])
            # print("\nFolders Inside {} are a follows :- ".format(test_folder['name']))
            # [print(i) for i in test_folder_data]
            for target in test_folder_data:
                if target['name'] in ["NewFeature", "New Feature", "New Features", "NewFeatures"]:
                    test_folder_total_col, X = get_testcasewise_report_for_test_folders(target['id'])
                    data["New Features"].append({'testset_name': test_folder['name'], 'testset_id': target['id'],
                                                 'count_data': test_folder_total_col})
                elif target['name'] in ["Regression", "Regressions"]:
                    test_folder_total_col, X = get_testcasewise_report_for_test_folders(target['id'])
                    data["Regression"].append({'testset_name': test_folder['name'], 'testset_id': target['id'],
                                                 'count_data': test_folder_total_col})

            # print("**************** Regression Data *******************")
            # for i in data["Regression"]:
            #     print(i)
            # print("*****************************************************")
            #
            # print("**************** New Features Data *******************")
            # for i in data["New Features"]:
            #     print(i)
            # print("*****************************************************")
            # break

        totalColumn1 = calculate_total_column(data["New Features"])
        totalColumn2 = calculate_total_column(data["Regression"])

        print("Time Taken by getcustomhpqcreportformitesh is :", time.time() - sTime)
        return render_template('hpqc_regression_new_feture_report_mitesh.html', tableData=data,
                               totalColumn1=totalColumn1, totalColumn2=totalColumn2, page_title=page_title,
                               heading=heading, heading_image=heading_image, favicon=favicon), 200
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Fetching Test Folder Counts from HPQC', 500


@main.route('/getcountfortestfolder')
def getcountfortestfolder():
    sTime = time.time()

    testfolder_id = request.args['id']
    testfolder_name = request.args['name']

    try:
        totalColumn, tableData = get_testcasewise_report_for_test_folders(testfolder_id)
        print("Time Taken by getcountfortestfolder for Test Folder - ", testfolder_name, 'is', time.time() - sTime)
        return render_template('hpqc_report_table.html', tableData=tableData, totalColumn=totalColumn,
                               name=testfolder_name), 200

    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Fetching Test Case Counts from HPQC', 500


@main.route('/getcountfortestset')
def getcountfortestset():
    sTime = time.time()
    testset_id = request.args['id']
    testset_name = request.args['name']

    tableData = [{'testset_name': testset_name, 'testset_id': testset_id, 'count_data': {}}]

    try:
        totalColumn = populate_testcase_count_table_data(tableData)
        # print(tableData)
        print("Time Taken by getcountfortestset for Test Set - ", testset_name, 'is', time.time() - sTime)
        return render_template('hpqc_report_table.html', tableData=tableData, totalColumn=totalColumn,
                               name=testset_name), 200

    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Fetching Test Case Counts from HPQC', 500


@main.route('/startjenkinsjob', methods=['POST'])
def startjenkinsjob():
    try:
        jsonData = request.get_json()
        start_jobs(jsonData)
        resp = Response(status=200)
        return resp
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Starting jenkins job', 500


@main.route('/schedulejenkinsjob', methods=['POST'])
def schedulejenkinsjob():
    try:
        jsonData = request.get_json()
        schedule_jobs(jsonData)
        resp = Response(status=200)
        return resp
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Scheduling jenkins job', 500


@main.route('/getjenkinstable')
def getjenkinstable():
    print("Getting Jenkins Jobs")
    st = time.time()
    queued_jobs = get_queued_jobs()
    running_jobs = get_running_jobs()
    scheduled_headers, scheduled_jobs = get_scheduled_jobs()

    print('scheduled_headers :', scheduled_headers)

    queued_headers = ['Feature Name', 'Queued Since', 'Kill Job']
    running_headers = ['Feature Name', 'Launcher', 'Console Log', 'Suite Log', 'Suite Report',
                       'Passed', 'Failed', 'Pending', 'Total', 'Running Since', 'Kill Job']

    print('getjenkinstable Took ', time.time() - st)
    return render_template('jenkins_table.html', queued_jobs=queued_jobs, running_jobs=running_jobs,
                           queued_headers=queued_headers, running_headers=running_headers, len=len,
                           scheduled_jobs=scheduled_jobs, scheduled_headers=scheduled_headers
                           , getattr=getattr), 200


@main.route('/killqueuedjobs', methods=['POST'])
def killqueuedjobs():
    id = request.form.get('id')
    print('Killing Queued Job Id :', id)

    try:
        kill_queued_job(id)
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Killing Queued Job :' + str(id), 500

    resp = Response(status=200)
    return resp


@main.route('/killscheduledjobs', methods=['POST'])
def killscheduledjobs():
    id = request.form.get('id')
    print('Killing Scheduled Job Id :', id)

    try:
        kill_scheduled_job(id)
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Killing Scheduled Job :' + str(id), 500

    resp = Response(status=200)
    return resp


@main.route('/killrunningjobs', methods=['POST'])
def killrunningjobs():
    try:
        running_job_id = request.form.get('id')
        name, number = running_job_id.split(',')
        number = int(number)

        print('Killing Running Job Name {} and Number {}'.format(name, number))
        kill_running_job(name, number)
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Killing Running Job :' + str(id), 500

    resp = Response(status=200)
    return resp


@main.route('/getalljenkinsjobs')
def getalljenkinsjobs():
    try:
        all_jenkins_jobs = get_jobs()
        schedule_headers = ['Job Name']
        jenkins_branches = get_branch_names_list()

        return render_template('schedule_table.html', all_jenkins_jobs=all_jenkins_jobs, len=len,
                               schedule_headers=schedule_headers, jenkins_branches=jenkins_branches), 200
    except Exception as e:
        print('Exception: ', e)
        traceback.print_exc()
        return 'Error While Getting All Jenkins Jobs', 500


@main.route('/change_defaults', methods=['GET', 'POST'])
def change_defaults():
    print('Inside Change Defaults')
    if request.method == 'GET':
        # print('\n\n\nIn change_defaults GET SearchValues are :', SearchValues.branch, SearchValues.feature,
        #       SearchValues.difference_between_dates, SearchValues.start_date,
        #       SearchValues.end_date, [str(i) for i in SearchValues.columns_to_select], '\n\n\n\n')
        branch = get_distinct_branch()
        feature = get_distinct_feature()
        default_search_values = SearchValues()

        # print('\n\n\nIn change_defaults GET default_search_values are :', default_search_values.branch,
        #       default_search_values.feature,
        #       default_search_values.difference_between_dates, default_search_values.start_date,
        #       default_search_values.end_date, [str(i) for i in default_search_values.columns_to_select], '\n\n\n\n')

        all_columns = [str(i).capitalize() for i in Suites.__table__.columns]
        columns_to_select = [str(i) for i in default_search_values.columns_to_select]
        mandatory_columns = ['Suites.id', 'Suites.status', 'Suites.date', 'Suites.nsxbranch', 'Suites.nsxbuild',
                             'Suites.feature',
                             'Suites.totalcases', 'Suites.passed', 'Suites.failed']
        return render_template('change_defaults.html', search_values=default_search_values, branch=branch,
                               feature=feature, all_columns=all_columns, str=str,
                               columns_to_select=columns_to_select, mandatory_columns=mandatory_columns, len=len,
                               page_title=page_title, heading=heading, heading_image=heading_image,
                               favicon=favicon), 200
    elif request.method == 'POST':
        branch_default = request.form.get('branch_default')
        feature_default = request.form.get('feature_default')
        difference_between_dates = request.form.get('difference_between_dates')
        selected_columns = request.form.getlist('selected_columns[]')
        default_suites = request.form.get('default_suites')
        default_runs = request.form.get('default_runs')

        default_add_branch = request.form.get('default_add_branch')
        default_delete_branch = request.form.get('default_delete_branch')

        if default_add_branch != "":
            add_branch(default_add_branch)

        if default_delete_branch != "":
            delete_branch(default_delete_branch)

        # print(branch_default, feature_default, difference_between_dates, selected_columns, default_suites)
        # print('\n\n****************', select_columns_dict)
        # selected_columns = [select_columns_dict[i] for i in selected_columns]
        selected_columns = [eval(i) for i in selected_columns]
        print(selected_columns)
        SearchValues.branch = branch_default
        SearchValues.feature = feature_default
        SearchValues.difference_between_dates = int(difference_between_dates)
        SearchValues.columns_to_select = selected_columns
        # SearchValues.start_date = (date.today() - timedelta(days=int(difference_between_dates))).strftime(
        #     date_format_for_input)
        SearchValues.status_column_no = selected_columns.index(Suites.status)
        SearchValues.failed_column_no = selected_columns.index(Suites.failed)
        SearchValues.feature_column_no = selected_columns.index(Suites.feature)
        SearchValues.no_of_suites = int(default_suites)
        SearchValues.no_of_runs = int(default_runs)

        return 'OK', 200


@main.route('/gethomecontent', methods=['POST'])
def gethomecontent():
    print('Inside gethomecontent')

    branch = request.form.get('branch')
    feature = request.form.get('feature')
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')

    set_search_values(branch, feature, start_date, end_date)

    column_names, table_data = get_hometable_data()

    return render_template('home_table_data.html', table_data=table_data, column_names=column_names, str=str,
                           search_values=SearchValuesObj, enumerate=enumerate), 200


@main.route('/getsummarycontent', methods=['POST'])
def getsummarycontent():
    print('Inside getsummarycontent')

    branch = request.form.get('branch')
    feature = request.form.get('feature')
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')

    set_search_values(branch, feature, start_date, end_date)
    summary_table_data, headings = get_summary_table_data()
    return render_template('featurewise_table_data.html',
                           summary_table_data=summary_table_data, headings=headings, str=str,
                           search_values=SearchValuesObj, range=range, len=len, round=round), 200


@main.route('/getbuildwisecontent', methods=['POST'])
def getbuildwisecontent():
    print('Inside getbuildwisecontent')

    branch = request.form.get('branch')
    feature = request.form.get('feature')
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')

    set_search_values(branch, feature, start_date, end_date)
    buildwise_table_data, headings = get_buildwise_table_data()

    return render_template('buildwise_table_data.html',
                           buildwise_table_data=buildwise_table_data, headings=headings, str=str,
                           search_values=SearchValuesObj, range=range, len=len, round=round), 200


@main.route('/getsuitecomparisoncontent', methods=['POST'])
def getsuitecomparisoncontent():
    print('Inside getsuitecomparisoncontent')

    branch = request.form.get('branch')
    feature = request.form.get('feature')
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')

    set_search_values(branch, feature, start_date, end_date)
    heading_columns, suite_comparison_table_data, headers = get_suitecomparison_table_data()
    return render_template('suitecomparison_table_data.html',
                           suite_comparison_table_data=suite_comparison_table_data, heading_columns=heading_columns,
                           headers=headers, zip=zip,
                           str=str, search_values=SearchValuesObj, len=len), 200


@main.route('/getnoofrunningjobs')
def getnoofrunningjobs():
    n = get_no_of_running_jobs()
    print("Number of Running Jobs are -", n)
    result = {
        "no_of_jobs_running": n,
        "max_jobs_allowed_for_scheduling": max_jobs_allowed_for_scheduling
    }
    resp = jsonify(result)
    resp.status_code = 200
    return resp


def get_build_data(id):
    suite_headers = [Suites.feature, Suites.nsxbuild, Suites.esxbuild, Suites.vcbuild]
    suite_data = Suites.query.with_entities(*suite_headers) \
        .filter(Suites.id == id).first()
    return suite_data


def get_test_case_data(id):
    suite_headers = [Suites.product, Suites.nsxbranch, Suites.nsxbuild, Suites.feature, Suites.totalcases,
                     Suites.executed,
                     Suites.passed, Suites.failed, Suites.pending, Suites.core]
    suite_data = Suites.query.with_entities(*suite_headers) \
        .filter(Suites.id == id).first()

    suite_headers = [str(column).split('.')[1].capitalize() for column in suite_headers]

    # print(suite_headers, '\n', suite_data)

    suite_data = [suite_headers] + [list(suite_data)]

    # print(suite_data)

    headers = [TestCases.testno,
               TestCases.testcasename, TestCases.status, TestCases.core]
    data = Suites.query.with_entities(*headers) \
        .filter(Suites.id == id, Suites.suiteid == TestCases.suiteid) \
        .order_by(TestCases.testno) \
        .all()
    headers = [str(column).split('.')[1].capitalize() for column in headers]
    # data = OrderedDict()
    # print(data, '\n', headers)
    return data, headers, suite_data


def get_hometable_data():
    if SearchValuesObj.branch == "All" and SearchValuesObj.feature == "All":
        data = Suites.query.with_entities(*SearchValuesObj.columns_to_select) \
            .filter(Suites.date >= SearchValuesObj.start_date, Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()) \
            .all()
    elif SearchValuesObj.branch == "All" and SearchValuesObj.feature != "All":
        data = Suites.query.with_entities(*SearchValuesObj.columns_to_select) \
            .filter(Suites.date >= SearchValuesObj.start_date, Suites.date <= SearchValuesObj.end_date,
                    Suites.feature == SearchValuesObj.feature) \
            .order_by(Suites.time.desc()) \
            .all()
    elif SearchValuesObj.branch != "All" and SearchValuesObj.feature == "All":
        data = Suites.query.with_entities(*SearchValuesObj.columns_to_select) \
            .filter(Suites.date >= SearchValuesObj.start_date, Suites.date <= SearchValuesObj.end_date,
                    Suites.nsxbranch == SearchValuesObj.branch) \
            .order_by(Suites.time.desc()) \
            .all()
    else:
        data = Suites.query.with_entities(*SearchValuesObj.columns_to_select) \
            .filter(Suites.date >= SearchValuesObj.start_date, Suites.date <= SearchValuesObj.end_date,
                    Suites.feature == SearchValuesObj.feature, Suites.nsxbranch == SearchValuesObj.branch) \
            .order_by(Suites.time.desc()) \
            .all()

    # for i in data:
    #     print(i)
    column_names = [str(column).split('.')[1] for column in SearchValuesObj.columns_to_select]
    # print("Keys", column_names)
    return column_names, data


def get_buildwise_table_data():
    distinct_builds = get_distinct_builds()
    buildwise_table_data = OrderedDict()
    buildwise_columns_to_select = [Suites.feature, Suites.date, Suites.status, Suites.totalcases, Suites.passed,
                                   Suites.failed, Suites.suitereport, Suites.id]

    if SearchValuesObj.branch == "All" and SearchValuesObj.feature == "All":
        for selected_build in distinct_builds:
            buildwise_table_data[selected_build] = Suites.query.with_entities(*buildwise_columns_to_select) \
                .filter(Suites.nsxbuild == selected_build, Suites.date >= SearchValuesObj.start_date,
                        Suites.date <= SearchValuesObj.end_date) \
                .order_by(Suites.time.desc()) \
                .limit(SearchValuesObj.no_of_runs) \
                .all()
    elif SearchValuesObj.branch == "All" and SearchValuesObj.feature != "All":
        for selected_build in distinct_builds:
            buildwise_table_data[selected_build] = Suites.query.with_entities(*buildwise_columns_to_select) \
                .filter(Suites.nsxbuild == selected_build, Suites.feature == SearchValuesObj.feature,
                        Suites.date >= SearchValuesObj.start_date,
                        Suites.date <= SearchValuesObj.end_date) \
                .order_by(Suites.time.desc()) \
                .limit(SearchValuesObj.no_of_runs) \
                .all()

    elif SearchValuesObj.branch != "All" and SearchValuesObj.feature == "All":
        for selected_build in distinct_builds:
            buildwise_table_data[selected_build] = Suites.query.with_entities(*buildwise_columns_to_select) \
                .filter(Suites.nsxbuild == selected_build, Suites.nsxbranch == SearchValuesObj.branch,
                        Suites.date >= SearchValuesObj.start_date,
                        Suites.date <= SearchValuesObj.end_date) \
                .order_by(Suites.time.desc()) \
                .limit(SearchValuesObj.no_of_runs) \
                .all()

    else:
        for selected_build in distinct_builds:
            buildwise_table_data[selected_build] = Suites.query.with_entities(*buildwise_columns_to_select) \
                .filter(Suites.nsxbuild == selected_build, Suites.nsxbranch == SearchValuesObj.branch,
                        Suites.feature == SearchValuesObj.feature,
                        Suites.date >= SearchValuesObj.start_date,
                        Suites.date <= SearchValuesObj.end_date) \
                .order_by(Suites.time.desc()) \
                .limit(SearchValuesObj.no_of_runs) \
                .all()

    headers = ['Builds']
    for i in range(SearchValuesObj.no_of_runs):
        if i == 0:
            headers.append('Latest Run')
        else:
            headers.append('Prev Run ' + str(i))

    return buildwise_table_data, headers


def get_summary_table_data():
    distinct_features = get_distinct_feature()[1:]
    summary_table_data = OrderedDict()

    summary_columns_to_select = [Suites.date, Suites.nsxbuild, Suites.status, Suites.totalcases, Suites.passed,
                                 Suites.failed,
                                 Suites.suitereport, Suites.id]

    if SearchValuesObj.branch == "All" and SearchValuesObj.feature == "All":
        for selected_feature in distinct_features:
            summary_table_data[selected_feature] = Suites.query.with_entities(*summary_columns_to_select) \
                .filter(Suites.feature == selected_feature, Suites.date >= SearchValuesObj.start_date,
                        Suites.date <= SearchValuesObj.end_date) \
                .order_by(Suites.time.desc()) \
                .limit(SearchValuesObj.no_of_suites) \
                .all()

    elif SearchValuesObj.branch == "All" and SearchValuesObj.feature != "All":
        summary_table_data[SearchValuesObj.feature] = Suites.query.with_entities(*summary_columns_to_select) \
            .filter(Suites.feature == SearchValuesObj.feature, Suites.date >= SearchValuesObj.start_date,
                    Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()) \
            .limit(SearchValuesObj.no_of_suites) \
            .all()

    elif SearchValuesObj.branch != "All" and SearchValuesObj.feature == "All":
        for selected_feature in distinct_features:
            summary_table_data[selected_feature] = Suites.query.with_entities(*summary_columns_to_select) \
                .filter(Suites.nsxbranch == SearchValuesObj.branch, Suites.feature == selected_feature,
                        Suites.date >= SearchValuesObj.start_date,
                        Suites.date <= SearchValuesObj.end_date) \
                .order_by(Suites.time.desc()) \
                .limit(SearchValuesObj.no_of_suites) \
                .all()

    else:
        summary_table_data[SearchValuesObj.feature] = Suites.query.with_entities(*summary_columns_to_select) \
            .filter(Suites.nsxbranch == SearchValuesObj.branch, Suites.feature == SearchValuesObj.feature,
                    Suites.date >= SearchValuesObj.start_date,
                    Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()) \
            .limit(SearchValuesObj.no_of_suites) \
            .all()

    # print('Summary Table Data ==> \n')
    # for k, v in summary_table_data.items():
    #     print(k, v)

    headers = ['Feature']
    for i in range(SearchValuesObj.no_of_suites):
        if i == 0:
            headers.append('Latest Build')
        else:
            headers.append('Prev Build ' + str(i))

    return summary_table_data, headers


def get_suitecomparison_table_data():
    suitecomparison_table_data = OrderedDict()
    testcase_table_data = OrderedDict()
    unique_testcases = set()
    suiteid_build_mapping = OrderedDict()
    if SearchValuesObj.branch == "All":
        suites_data = Suites.query.with_entities(Suites.id, Suites.suiteid, Suites.nsxbuild, Suites.date) \
            .filter(Suites.feature == SearchValuesObj.feature, Suites.date >= SearchValuesObj.start_date,
                    Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()) \
            .limit(SearchValuesObj.no_of_suites) \
            .all()
    else:
        suites_data = Suites.query.with_entities(Suites.id, Suites.suiteid, Suites.nsxbuild, Suites.date) \
            .filter(Suites.nsxbranch == SearchValuesObj.branch, Suites.feature == SearchValuesObj.feature,
                    Suites.date >= SearchValuesObj.start_date,
                    Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()) \
            .limit(SearchValuesObj.no_of_suites) \
            .all()

    for row in suites_data:
        # print(row)
        id, suiteid, buildno, suite_date = row
        suiteid_build_mapping[suiteid] = '\n'.join([str(buildno), '(' + str(suite_date) + ')'])
        # print('*****', suiteid_build_mapping[suiteid])

        testcase_data = TestCases.query.with_entities(*SearchValuesObj.testcases_columns) \
            .filter(TestCases.suiteid == suiteid) \
            .order_by(TestCases.id) \
            .all()
        # print('TestCase Data for Build ', buildno, 'is :\n', testcase_data)
        for testcase in testcase_data:
            unique_testcases.add(testcase[2])

        testcase_table_data[suiteid] = testcase_data

    for testcase in unique_testcases:
        suitecomparison_table_data[testcase] = [''] * min(SearchValuesObj.no_of_suites, len(suiteid_build_mapping))

    count = 0
    for sid, testcases in testcase_table_data.items():
        for testcase in testcases:
            tid, tsid, tname, tstatus, tcore = testcase
            suitecomparison_table_data[tname][count] = tstatus if tstatus != '' else 'NORUN'
        count += 1

    # for i, j in suitecomparison_table_data.items():
    #     print(i, j)

    column_names = ['TestCases : ' + str(len(suitecomparison_table_data))] \
                   + list(suiteid_build_mapping.values())

    headers = []
    for i in range(SearchValuesObj.no_of_suites):
        if i == 0:
            headers.append('Latest Build')
        else:
            headers.append('Prev Build ' + str(i))

    return column_names, suitecomparison_table_data, headers


def get_distinct_branch():
    data = Suites.query.with_entities(Suites.nsxbranch).distinct().all()
    result = ['All']
    for row in data:
        result.append(row[0])
    result.sort()
    return result


def get_distinct_feature():
    data = Suites.query.with_entities(Suites.feature).distinct().all()
    result = ['All']
    for row in data:
        result.append(row[0])
    result.sort()
    return result


def get_distinct_builds():

    if SearchValuesObj.branch == "All" and SearchValuesObj.feature == "All":
        data = Suites.query.with_entities(Suites.nsxbuild) \
            .filter(Suites.date >= SearchValuesObj.start_date, Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()).distinct().all()

    elif SearchValuesObj.branch == "All" and SearchValuesObj.feature != "All":
        data = Suites.query.with_entities(Suites.nsxbuild) \
            .filter(Suites.feature == SearchValuesObj.feature,
                    Suites.date >= SearchValuesObj.start_date, Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()).distinct().all()

    elif SearchValuesObj.branch != "All" and SearchValuesObj.feature == "All":
        data = Suites.query.with_entities(Suites.nsxbuild) \
            .filter(Suites.nsxbranch == SearchValuesObj.branch,
                    Suites.date >= SearchValuesObj.start_date, Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()).distinct().all()

    else:
        data = Suites.query.with_entities(Suites.nsxbuild) \
            .filter(Suites.nsxbranch == SearchValuesObj.branch, Suites.feature == SearchValuesObj.feature,
                    Suites.date >= SearchValuesObj.start_date, Suites.date <= SearchValuesObj.end_date) \
            .order_by(Suites.time.desc()).distinct().all()

    result = []
    for row in data:
        result.append(row[0])
    return result


def set_search_values(branch, feature, start_date, end_date):
    SearchValuesObj.branch = branch
    SearchValuesObj.feature = feature
    SearchValuesObj.start_date = start_date
    SearchValuesObj.end_date = end_date


def populate_testcase_count_table_data(tableData):
    total = OrderedDict({"Passed": 0, "Failed": 0, "No Run": 0, "Blocked": 0,  "N/A": 0, "Not Completed": 0,
     "Running": 0, "Total": 0, "Execution %": 0, "Pass %": 0})

    for row in tableData:
        testset_id = row['testset_id']
        data = get_test_cases_count(testset_id)
        row['count_data'] = data
        for status in total:
            total[status] += data[status]
        executed = total['Passed']+total['Failed']+total['Blocked']
        total['Pass %'] = round((total['Passed'] / executed)*100, 2) if executed != 0 else 0
        total['Execution %'] = round((executed / total['Total']) * 100, 2) if \
            total['Total'] != 0 else 0
    return total


def calculate_total_column(tableData):
    total = OrderedDict({"Passed": 0, "Failed": 0, "No Run": 0, "Blocked": 0, "N/A": 0, "Not Completed": 0,
                         "Running": 0, "Total": 0, "Execution %": 0, "Pass %": 0})

    for row in tableData:
        for status in total:
            total[status] += row['count_data'][status]
        executed = total['Passed'] + total['Failed'] + total['Blocked']
        total['Pass %'] = round((total['Passed'] / executed) * 100, 2) if executed != 0 else 0
        total['Execution %'] = round((executed / total['Total']) * 100, 2) if \
            total['Total'] != 0 else 0
    return total


def get_testcasewise_report_for_test_folders(testfolder_id):
    test_folders_list = [testfolder_id]
    tableData = []

    while len(test_folders_list) > 0:
        temp_id = test_folders_list.pop(0)
        folders_data, folders_count = get_hpqc_folders(temp_id)
        for record in folders_data:
            test_folders_list.append(record['id'])

        testsets_data, testsets_count = get_hpqc_testsets(temp_id)

        for test_set in testsets_data:
            # print(test_set)
            tableData.append({'testset_name': test_set['name'], 'testset_id': test_set['id'], 'count_data': {}})

    totalColumn = populate_testcase_count_table_data(tableData)
    # print(totalColumn)
    # print(tableData)
    return totalColumn, tableData
