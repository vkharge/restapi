# Define the application directory
import os


class Config(object):
    """
    Common configurations
    """

    # Put any configurations here that are common across all environments
    # Application threads. A common general assumption is
    # using 2 per available processor cores - to handle
    # incoming requests using one and performing background
    # operations using the other.
    THREADS_PER_PAGE = 2

    # Enable protection agains *Cross-site Request Forgery (CSRF)*
    CSRF_ENABLED = True

    # Use a secure, unique and absolutely secret key for
    # signing the data.
    CSRF_SESSION_KEY = "secret"

    # Secret key for signing cookies
    SECRET_KEY = "secret"
    TRAP_HTTP_EXCEPTIONS = True


class DevelopmentConfig(Config):
    """
    Development configurations
    """
    ENV = 'development'
    FLASK_ENV = 'development'
    SQLALCHEMY_ECHO = True
    # Statement for enabling the development environment
    DEBUG = True

    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    os.environ.setdefault('BASE_DIR', BASE_DIR)

    from app.config_reader import get_db_config
    db_config = get_db_config()

    # Define the database
    SQL_USERNAME = db_config.get("SQL_USERNAME")
    SQL_PASSWORD = db_config.get("SQL_PASSWORD")
    SQL_DATABASE = db_config.get("SQL_DATABASE")
    SQL_SERVER_IP = db_config.get("SQL_SERVER_IP")
    SQLALCHEMY_DATABASE_URI = 'mysql://' + SQL_USERNAME + ':' + SQL_PASSWORD + '@' + SQL_SERVER_IP + '/' + SQL_DATABASE
    DATABASE_CONNECT_OPTIONS = {}
    SQLALCHEMY_TRACK_MODIFICATIONS = True


class ProductionConfig(Config):
    """
    Production configurations
    """
    ENV = 'production'
    FLASK_ENV = 'production'

    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    os.environ.setdefault('BASE_DIR', BASE_DIR)

    from app.config_reader import get_db_config
    db_config = get_db_config()

    # Define the database
    SQL_USERNAME = db_config.get("SQL_USERNAME")
    SQL_PASSWORD = db_config.get("SQL_PASSWORD")
    SQL_DATABASE = db_config.get("SQL_DATABASE")
    SQL_SERVER_IP = db_config.get("SQL_SERVER_IP")
    SQLALCHEMY_DATABASE_URI = 'mysql://' + SQL_USERNAME + ':' + SQL_PASSWORD + '@' + SQL_SERVER_IP + '/' + SQL_DATABASE
    DATABASE_CONNECT_OPTIONS = {}

    DEBUG = False
    SQLALCHEMY_TRACK_MODIFICATIONS = False


app_config = {
    'dev': 'config.DevelopmentConfig',
    'prod': 'config.ProductionConfig'
}
