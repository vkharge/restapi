from dashboard import ReportAPI


from junit_xml import TestSuite, TestCase



base = "http://127.0.0.1:8080"
ADMIN_API_KEY = "12345"

orgs = {
    "mappings": [
        {
            "org": "DOLBY.IO",
            "products": [
                {
                   "product":  "DOLBYON",
                   "sproducts": ["ANDROID", "IOS", "ARTEMIS", "APOLLO", "ODIN", "THOR", "LOKI"]
                },
                {
                    "product": "MAPI",
                    "sproducts": ["TRANSCODE"]
                }
            ]
        }
    ]
}

environments = ["DEV", "QA", "STG"]
tests = ["Unit", "Integration", "System", "Comparison", "Performance", "UI"]
api = ReportAPI(base, ADMIN_API_KEY)

for org in orgs["mappings"]:
    org_name = org["org"]
    for product in org["products"]:
        product_name = product["product"]
        for sproduct in product["sproducts"]:
            sproduct_name = sproduct
            response = api.create_mapping(data={
                "org": org_name,
                "product": product_name,
                "sub_product": sproduct_name

            })
            print(response.status_code)

for environment in environments:
    response = api.create_environment(data={"name": environment})
    print(response.status_code)

for test in tests:
    response = api.create_test_type(data={"name": test})
    print(response.status_code)