from datetime import datetime, timedelta, timezone
from gti_scutils.tms.tms import TMS
from junitparser import Failure, Skipped, Error
from junitparser import JUnitXml


class QTestExecution:
    _PARENT_TYPE_RELEASE = "release"

    def __init__(self, server, token, project_name, debug=False):
        self._server = server
        self._token = token
        self._project_name = project_name
        self._debug = debug
        self._tms = TMS()
        self._tms.debug = debug
        self._tms._token = token

        self.__validate_token()
        self.__validate_project()

    def push_results_junit(self, release_name, build_number, build_url,
                           junit_xml_file, qtest_dir_path=None):

        release = self.__create_release(release_name)
        build = self.__create_build(release.id, build_number)
        test_cycle = self.__create_test_cycle(release.id, build_number)

        testcases = self.__parse_junit_xml_for_qTest(junit_xml_file, qtest_dir_path)

        if not testcases:
            raise ValueError(f"Junit XML '{junit_xml_file}' does not have "
                             f"test cases")

        testcases = [
            dict(test, build_number=build_number, build_url=build_url)
            for test in testcases
        ]
        print(testcases)

        testsuite = {
            "test_cycle": test_cycle.id,
            "test_logs": testcases,
        }

        self._tms.run_batch(self._project.id, testsuite)
        self._tms.poll_batch()

    def push_results(self, release_name, build_number, build_url, testcases, qtest_dir_path=None):

        release = self.__create_release(release_name)
        build = self.__create_build(release.id, build_number)
        test_cycle = self.__create_test_cycle(release.id, build_number)

        self.__validate_testcases_type(testcases)
        testcases = [
            self.__validate_testcase_content(
                test, build_number=build_number, build_url=build_url)
            for test in testcases
        ]
        #print(testcases)

        testsuite = {
            "test_cycle": test_cycle.id,
            "test_logs": testcases,
        }

        self._tms.run_batch(self._project.id, testsuite)
        self._tms.poll_batch()

    def __parse_junit_xml_for_qTest(self, junit_xml, qtest_dir_path):

        testcases = []
        xml = JUnitXml.fromfile(junit_xml)
        tz = datetime.now(timezone.utc).astimezone().tzinfo

        for index, suite in enumerate(xml):
            try:
                suite_timestamp = datetime.strptime(suite.timestamp,
                                                    "%Y-%m-%dT%H:%M:%S")
            except:
                suite_timestamp = datetime.strptime(suite.timestamp,
                                                    "%Y-%m-%dT%H:%M:%S.%f")

            time_delta = timedelta(seconds=0)

            for case in suite:
                start_time = (suite_timestamp + time_delta).astimezone(tz) \
                    .strftime("%Y-%m-%dT%H:%M:%S%z")
                time_delta += timedelta(seconds=float(case.time))
                end_time = (suite_timestamp + time_delta).astimezone(tz) \
                    .strftime("%Y-%m-%dT%H:%M:%S%z")

                dir_path = self.__construct_directory(index, xml.name,
                                                      suite.name,
                                                      case.classname,
                                                      qtest_dir_path)

                print(dir_path)
                test_status, note_info = self.__get_status_info(case)
                test = {
                    "name": case.name,
                    "status": test_status,
                    "module_names": dir_path,
                    "exe_start_date": start_time,
                    "exe_end_date": end_time,
                    "automation_content": case.classname + "." + case.name,
                    "note": "note: " + note_info,
                }

                testcases.append(test)

        return testcases

    def __validate_token(self):
        print("Validate the authorization token")
        if self._tms.tms_get("", None) is None:
            raise KeyError("QTest Token is not authorised")
        else:
            print("QTest Token is valid")

    def __validate_project(self):
        print(f"Validate the {self._project_name} project")
        if self.__validate_blank(self._project_name):
            raise ValueError(f"Project name cannot be None or blank")

        try:
            self._project = self._tms.get_project_by_name(self._token,
                                                          self._project_name)
        except:
            raise ValueError(f"Project {self._project_name} not found")

    @staticmethod
    def __validate_blank(value):
        if value is None:
            return True
        elif value.strip() == "":
            return True

        return False

    def __create_release(self, release_name):
        if self.__validate_blank(release_name):
            raise ValueError(f"Release name cannot be None or blank")

        release = self._tms.get_release_by_attribute(self._token,
                                                     str(self._project.id),
                                                     "name", release_name)

        if release is None:
            release = self._tms.create_release(self._token,
                                               str(self._project.id),
                                               release_name)
        return release

    def __create_build(self, release_id, build_number):
        if self.__validate_blank(build_number):
            raise ValueError(f"Build number cannot be None or blank")

        build = self._tms.get_build_by_name(self._token, str(self._project.id),
                                            build_number, release_id)

        if build is None:
            build = self._tms.create_build(self._token, str(self._project.id),
                                           build_number, False, release_id,
                                           self._PARENT_TYPE_RELEASE)
        return build

    def __create_test_cycle(self, release_id, test_cycle_name):
        if self.__validate_blank(test_cycle_name):
            raise ValueError(f"Test cycle name cannot be None or blank")

        test_cycle = self._tms.get_build_cycle_by_name(
            self._token, str(self._project.id), test_cycle_name,
            str(release_id), self._PARENT_TYPE_RELEASE)

        if test_cycle is None:
            test_cycle = self._tms.create_build_cycle(
                self._token, str(self._project.id), test_cycle_name,
                str(release_id), self._PARENT_TYPE_RELEASE)

        return test_cycle

    @staticmethod
    def __get_status_info(case):

        test_status = "PASS"
        test_message = None
        test_text = None

        if case.result:
            result = case.result[0]
            if isinstance(result, Failure):
                test_status = "FAIL"
            elif isinstance(result, Skipped):
                test_status = "SKIP"
            elif isinstance(result, Error):
                test_status = "ERROR"

            test_message = result.message
            test_text = result.text
            test_type = result.type

        note_info = ""
        if test_message is not None:
            note_info += test_message if test_type is None else \
                f"{test_type}: {test_message}"
        if test_text is not None:
            note_info += "---- text ----\n" + test_text
        if case.system_out is not None:
            note_info += "---- standard output ----\n" + case.system_out
        if case.system_err is not None:
            note_info += "---- standard error ----\n" + case.system_err

        return test_status, note_info

    @staticmethod
    def __construct_directory(number, suites_name=None, suite_name=None,
                              class_name=None, qtest_dir_path=None):

        if qtest_dir_path:
            suites_dir = qtest_dir_path.split("/")
        else:
            suites_dir = ["Automation" if suites_name is None else suites_name]

        if suite_name:
            if "/" in suite_name:
                suite_dir = suite_name.split("/")[1:]
            else:
                suite_dir = [suite_name]
        else:
            suite_dir = [f"/Suite{number}"]

        class_dir = [] if class_name in suite_name else [class_name]
        print(suites_dir, suite_dir, class_dir)
        return suites_dir + suite_dir + class_dir

    @staticmethod
    def __validate_testcases_type(testcases):

        if not testcases:
            raise ValueError(f"Testcases object cannot be empty or None")

        if isinstance(testcases, list):
            pass
        else:
            raise ValueError(f"Testcases results should be passed as list "
                             f"of dict")

    @staticmethod
    def __validate_testcase_content(testcase, build_number, build_url):

        testcase_keys = {"name", "status", "module_names", "exe_start_date",
                         "exe_end_date", "automation_content", "note"}

        testcase_status = ["PASS", "FAIL", "SKIP", "ERROR"]

        if set(testcase_keys) != set(testcase.keys()):
            raise ValueError("Testcase dict has missing matching keys")

        if testcase["name"] is None or testcase["name"] == "":
            raise ValueError("Testcase name cannot be empty or blank")

        if testcase["status"] not in testcase_status:
            raise ValueError(f"Testcase status should be {testcase_status}")

        if not testcase["module_names"] or \
                not isinstance(testcase["module_names"], list):
            raise ValueError(f"Module Names should be non empty list")

        if testcase["exe_start_date"] is None or\
                testcase["exe_start_date"] == "":
            raise ValueError(f"exe_start_date should be in "
                             f"'2021-10-06T19:02:00+1100' format")

        try:
            datetime.strptime(testcase["exe_start_date"],
                              "%Y-%m-%dT%H:%M:%S%z")
        except ValueError:
            raise ValueError("Incorrect exe_start_date format, should be "
                             "'2021-10-06T19:02:00+1100' format")

        if testcase["exe_end_date"] is None or\
                testcase["exe_end_date"] == "":
            raise ValueError(f"exe_end_date should be in "
                             f"'2021-10-06T19:02:00+1100' format")

        try:
            datetime.strptime(testcase["exe_end_date"],
                              "%Y-%m-%dT%H:%M:%S%z")
        except ValueError:
            raise ValueError("Incorrect exe_end_date format, should be "
                             "'2021-10-06T19:02:00+1100' format")

        if testcase["automation_content"] is None or \
                not isinstance(testcase["automation_content"], str):
            raise ValueError(f"automation_content should be string")

        if testcase["note"] is None or \
                not isinstance(testcase["note"], str):
            raise ValueError(f"note should be string")

        dict(testcase, build_number=build_number, build_url=build_url)

        return testcase
