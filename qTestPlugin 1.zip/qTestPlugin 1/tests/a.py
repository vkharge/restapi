def test_good():
    assert 1 == 1


def test_bad():
    assert 2 == 3