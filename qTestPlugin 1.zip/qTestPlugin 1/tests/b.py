def test_happy():
    assert 4 == 4