import argparse
import os

from qTest import QTestExecution

QTEST_SERVER = "dolby.qtestnet.com"
QTEST_TOKEN = "ZG9sYnl8VmlzaGFsLktoYXJnZUBkb2xieS5jb206MTY2NTEwMDg" \
              "4NjU1MTo4OWVlZjY2M2UxOTA3NWYxMDU5NWM1ODc0MWNlYmViNA"
QTEST_PROJECT_NAME = "AP3"

try:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-url",
                        default=os.environ.get("CI_PIPELINE_URL"),
                        dest="build_url")
    parser.add_argument("--build-number",
                        default=os.environ.get("CI_COMMIT_SHORT_SHA"),
                        dest="build_number")
    parser.add_argument("--release-name",
                        default=os.environ.get("CI_COMMIT_BRANCH"),
                        dest="release_name")
    parser.add_argument("--junit-xml",
                        default=None,
                        dest="junit_xml")
    parser.add_argument("--file",
                        default=None,
                        dest="file")
    parser.add_argument("--qtest-path",
                        default=None,
                        dest="qtest_path")
    args = parser.parse_args()

    print(args)

    # Restrict script usage to release and master/main/develop branches only
    if "release/" in args.release_name \
            or args.release_name in ["develop", "master", "main",
                                     "test/AP3-14047-integrate-comparison-tests-with-ci"]:
        if args.release_name in ["develop", "master", "main", "test/AP3-14047-integrate-comparison-tests-with-ci"]:
            args.release_name = f"Artemis_{args.release_name}"

        if args.junit_xml:
            qTest = QTestExecution(QTEST_SERVER, QTEST_TOKEN,
                                   QTEST_PROJECT_NAME)
            qTest.push_results_junit(release_name=args.release_name,
                                     build_number=args.build_number,
                                     build_url=args.build_url,
                                     junit_xml_file=args.junit_xml,
                                     qtest_dir_path=args.qtest_path)

        else:
            print("TODO")

    else:
        raise RuntimeError('Cannot automatically push to qTest on a '
                           'non-release or non-develop branch.')


except Exception as e:
    print("ERROR: " + str(e))
    exit(1)
exit(0)
