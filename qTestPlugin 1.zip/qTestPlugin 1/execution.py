from dashboard import ReportServer

base = "http://127.0.0.1:8080"
ADMIN_API_KEY = "12345"

execution = {
  "org": "DOLBY.IO",
  "product": "DOLBYON",
  "sub_product": "ARTEMIS",
  "test_type": "Integration",
  "environment": "DEV",
  "release": "v1.0",
  "branch": "master",
  "suite": "Functional",
  "build": "1111",
  "report_url": "http://s3.com",
  "console_url": "http://gitlab.com",
  "log_url": "http://s3.com",
  "infra": "firebase"
}


obj = ReportServer(base, ADMIN_API_KEY)
obj.push_results_using_junit(execution, "junit_unit_mapi.xml", "suites")
obj.push_results_using_junit(execution, "report.xml", "suite")