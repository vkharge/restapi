import json
import requests
from junitparser import JUnitXml, Failure, Skipped, Error
import xml.etree.ElementTree as ET
import copy

class JUnitParser:

    def __init__(self, file, option="suite"):
        if option not in ["suites", "suite"]:
            raise ValueError("Invalid option passed, valid options are ["
                             "'suites', 'suite']")

        self.file = file
        self.option = option
        self.root = None

    def parse(self):
        self.root = ET.parse(self.file).getroot()
        self._check_root_element()
        suite_info = self._get_suites_info()
        results = self._get_test_suites_details(suite_info)

        return results

    def _check_root_element(self):
        if not self.root.tag.startswith("testsuites"):
            raise TypeError("Top level element is not a 'testsuite(s)'"
                            " but '{0}'".format(self.root.tag))

    def _get_suites_info(self):
        suites = {
            "name": self.root.attrib.get("name", ""),
            "tests": int(self.root.attrib.get("tests", 0)),
            "failures": int(self.root.attrib.get("failures", 0)),
            "errors": int(self.root.attrib.get("errors", 0)),
            "skipped": int(self.root.attrib.get("skipped", 0)),
            "time": float(self.root.attrib.get("time", 0)),
        }

        return suites

    def _get_test_suites_details(self, suite_info):

        results = copy.deepcopy(suite_info)
        testsuites = self.root.findall("testsuite")
        if not testsuites:
            raise TypeError("'suites' element must contain at least "
                            "one 'suite'.")

        testno = 1
        timestamp = None
        testcases_all = []
        suites = []

        total_tests = 0
        total_errors = 0
        total_failures = 0
        total_skipped = 0
        total_duration = 0.0
        final_status = []

        for testsuite in testsuites:
            suite = self._get_suite_info(testsuite)
            total_tests += suite["tests"]
            total_errors += suite["errors"]
            total_failures += suite["failures"]
            total_skipped += suite["skipped"]
            total_duration += suite["time"]
            final_status.append(suite["status"])

            if timestamp is None:
                timestamp = suite["timestamp"]

            if self.option == "suite":
                testno = 1

            testcases = []
            for test in testsuite.findall(".//testcase"):
                testcase = self._get_testcase_info(test)
                testcase["testno"] = testno
                testno += 1

                testcases.append(testcase)

            if self.option == "suites":
                testcases_all.extend(testcases)
            else:
                suite["testcases"] = testcases
                suites.append(suite)

        if self.option == "suites":
            results["testcases"] = testcases_all
        else:
            results["suites"] = suites

        results["timestamp"] = timestamp

        if results["tests"] == 0:
            results["tests"] = total_tests
        if results["errors"] == 0:
            results["errors"] = total_errors
        if results["failures"] == 0:
            results["failures"] = total_failures
        if results["skipped"] == 0:
            results["skipped"] = total_skipped
        if results["time"] == 0:
            results["time"] = total_duration

        results["failed"] = results["failures"] + results["errors"]
        results["passed"] = results["tests"] - results["failed"] - results[
            "skipped"]

        if "FAILED" in final_status:
            results["status"] = "FAILED"
        elif "SKIPPED" in final_status:
            results["status"] = "SKIPPED"
        else:
            results["status"] = "PASSED"

        return results

    @staticmethod
    def _get_suite_info(testsuite):
        suite = {
            "name": testsuite.attrib.get("name", ""),
            "tests": int(testsuite.attrib.get("tests", 0)),
            "errors": int(testsuite.attrib.get("errors", 0)),
            "failures": int(testsuite.attrib.get("failures", 0)),
            "skipped": int(testsuite.attrib.get("skipped", 0)),
            "time": round(float(testsuite.attrib.get("time", 0.0)), 3),
            "timestamp": testsuite.attrib.get("timestamp", ""),
        }

        suite["failed"] = suite["failures"] + suite["errors"]
        suite["passed"] = suite["tests"] - suite["failed"] - suite["skipped"]

        if suite["skipped"] > 0:
            suite["status"] = "SKIPPED"
        elif suite["failed"] > 0:
            suite["status"] = "FAILED"
        else:
            suite["status"] = "PASSED"

        return suite

    def _get_testcase_info(self, case):
        status, message = self._get_test_status_info(case)

        test = {
            "testname": case.attrib.get("name", ""),
            #"classname": case.attrib.get("classname", ""),
            "status": status,
            "duration": round(float(case.attrib.get("time", 0.0)), 3),
            "message": message
        }

        return test

    @staticmethod
    def _get_test_status_info(case):
        test_status = "PASSED"
        test_message = ""

        if list(case):
            if case[0].tag == "failure":
                test_status = "FAILED"
            elif case[0].tag == "error":
                test_status = "SKIPPED"
            elif case[0].tag == "skipped":
                test_status = "SKIPPED"
            test_message = case[0].text

        return test_status, test_message


class RestClient:
    API_KEY_NAME = "access_token"

    def __init__(self, server, token):
        self.server = server
        self.token = token

    def get(self, endpoint, headers):
        url = f"{self.server}{endpoint}"
        headers[self.API_KEY_NAME] = self.token
        response = requests.get(url, headers=headers, verify=False)

        return response

    def post(self, endpoint, data, headers):
        url = f"{self.server}{endpoint}"
        headers[self.API_KEY_NAME] = self.token
        response = requests.post(url, data=json.dumps(data), headers=headers,
                                 verify=False)

        return response

    def delete(self, endpoint, headers):
        url = f"{self.server}{endpoint}"
        headers[self.API_KEY_NAME] = self.token
        response = requests.delete(url, headers=headers, verify=False)

        return response

    def put(self, endpoint, data, headers):
        url = f"{self.server}{endpoint}"
        headers[self.API_KEY_NAME] = self.token
        response = requests.put(url, data=json.dumps(data), headers=headers,
                                verify=False)

        return response


class ReportAPI(RestClient):
    _version = "/api/v1"
    _suites = f"/suites"
    _testcases = f"/testcases"
    _mappings = f"/mappings"
    _environments = f"/environments"
    _test_types = f"/test-types"
    _headers = {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache'
    }

    def __init__(self, server, token):
        self.server = server
        self.token = token
        super().__init__(server, token)

    @property
    def server(self):
        return self.__server

    @server.setter
    def server(self, value):
        if value is None or value.strip() == "":
            raise ValueError("Server name cannot be empty")
        self.__server = value

    @property
    def token(self):
        return self.__token

    @token.setter
    def token(self, value):
        if value is None or value.strip() == "":
            raise ValueError("Token cannot be empty")
        self.__token = value

    def get_suites(self):
        endpoint = f"{self._version}{self._suites}"
        return self.get(endpoint=endpoint, headers=self._headers)

    def get_suite(self, suite_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}"
        return self.get(endpoint=endpoint, headers=self._headers)

    def create_suite(self, data):
        endpoint = f"{self._version}{self._suites}"
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers)

    def delete_suite(self, suite_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}"
        return self.delete(endpoint=endpoint, headers=self._headers)

    def update_suite(self, suite_id, data):
        endpoint = f"{self._version}{self._suites}/{suite_id}"
        return self.put(endpoint=endpoint, data=data,
                        headers=self._headers)

    def get_testcases(self, suite_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}{self._testcases}"
        #endpoint = f"{self._suites}/{suite_id}/{self._testcases}"
        print(endpoint)
        return self.get(endpoint=endpoint, headers=self._headers)

    def get_testcase(self, suite_id, testcase_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}/{testcase_id}"
        #endpoint = f"{self._suites}/{suite_id}/{self._testcases}"
        print(endpoint)
        return self.get(endpoint=endpoint, headers=self._headers)

    def create_testcase(self, suite_id, data):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}"
        print(endpoint)
        return self.post(endpoint=endpoint, data=data, headers=self._headers)

    def create_testcases(self, suite_id, data):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}/bulk"
        return self.post(endpoint=endpoint, data=data, headers=self._headers)

    def delete_testcases(self, suite_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}"
        #endpoint = f"{self._suites}/{suite_id}/{self._testcases}"
        print(endpoint)
        return self.delete(endpoint=endpoint,  headers=self._headers)

    def delete_testcase(self, suite_id, testcase_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}/{testcase_id}"
        print(endpoint)
        return self.delete(endpoint=endpoint,  headers=self._headers)

    def update_testcase(self, suite_id, testcase_id, data):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}/{testcase_id}"
        print(endpoint)
        return self.put(endpoint=endpoint, data=data, headers=self._headers)

    def create_mapping(self, data):
        endpoint = f"{self._version}{self._mappings}"
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers)

    def create_environment(self, data):
        endpoint = f"{self._version}{self._environments}"
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers)

    def create_test_type(self, data):
        endpoint = f"{self._version}{self._test_types}"
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers)


class ReportServer:
    def __init__(self, server, token):
        self.server = server
        self.token = token
        self._client = ReportAPI(server, token)

    def push_results_using_junit(self, suite, junit_xml, option="suites"):
        parser = JUnitParser(file=junit_xml, option=option)
        junit_json = parser.parse()

        if option == "suites":
            suite = self.__populate_suite_data(suite, junit_json)
            print(suite)
            suite_res = self.push_suite(suite)

            suite_id = suite_res.json()["id"]
            testcases = {"testcases": junit_json["testcases"]}
            print(testcases)
            testcases_res = self.push_testcases(suite_id, testcases)
        else:
            for item in junit_json["suites"]:
                suite = self.__populate_suite_data(suite, item)
                suite["suite"] = item["name"]
                print(suite)
                suite_res = self.push_suite(suite)

                suite_id = suite_res.json()["id"]
                testcases = {"testcases": item["testcases"]}
                print(testcases)
                testcases_res = self.push_testcases(suite_id, testcases)

    def push_suite(self, suite):
        response = self._client.create_suite(suite)
        if response.status_code != 201:
            raise Exception(f"Response Code: {response.status_code} {response.reason}\n"
                            f"Response Body:\n{response.json()}")
        return response

    def push_testcases(self, suite_id, testcases):
        response = self._client.create_testcases(suite_id, testcases)

        if response.status_code != 201:
            raise Exception(f"Response Code: {response.status_code} {response.reason}\n"
                            f"Response Body:\n{response.json()}")
            return response

    def push_testcase(self, suite_id, testcase):
        response = self._client.create_testcase(suite_id, testcase)

        raise Exception(f"Response Code: {response.status_code} {response.reason}\n"
                        f"Response Body:\n{response.json()}")
        return response

    def parse_junit_xml(self, junit_xml):
        parser = JUnitParser(file=junit_xml, option="suite")
        return parser.parse()

    @staticmethod
    def __populate_suite_data(suite, data):
        suite["total"] = data["tests"]
        suite["passed"] = data["passed"]
        suite["failed"] = data["failed"]
        suite["skipped"] = data["skipped"]
        suite["status"] = data["status"]
        suite["duration"] = data["time"]
        suite["created"] = data["timestamp"]

        return suite


class ReportServerOLD:
    def __init__(self, server, token):
        self.server = server
        self.token = token
        self._client = ReportAPI(server, token)

    def push_results_using_junit_old(self, suite, junit_xml, option="suites"):
        junit_json = self.__parse_junit_xml(junit_xml, option)

        if option not in ["suites", "suite"]:
            raise ValueError("Invalid option passed, valid options are ["
                             "'suites', 'suite']")

        if option == "suites":
            suite = self.__populate_suite_data(suite, junit_json)
            print(suite)
            suite_res = self.push_suite(suite)

            suite_id = suite_res.json()["id"]
            testcases = {"testcases": junit_json["testcases"]}
            testcases_res = self.push_testcases(suite_id, testcases)
        else:
            for item in junit_json["suites"]:
                suite = self.__populate_suite_data(suite, item)
                suite["suite"] = item["name"]

                suite_res = self.push_suite(suite)

                suite_id = suite_res.json()["id"]
                testcases = {"testcases": item["testcases"]}
                testcases_res = self.push_testcases(suite_id, testcases)

    def push_results_using_junit(self, suite, junit_xml, option="suites"):
        parser = JUnitParser(file=junit_xml, option=option)
        junit_json = parser.parse()

        if option == "suites":
            suite = self.__populate_suite_data(suite, junit_json)
            print(suite)
            suite_res = self.push_suite(suite)

            suite_id = suite_res.json()["id"]
            testcases = {"testcases": junit_json["testcases"]}
            print(testcases)
            testcases_res = self.push_testcases(suite_id, testcases)
        else:
            for item in junit_json["suites"]:
                suite = self.__populate_suite_data(suite, item)
                suite["suite"] = item["name"]
                print(suite)
                suite_res = self.push_suite(suite)

                suite_id = suite_res.json()["id"]
                testcases = {"testcases": item["testcases"]}
                print(testcases)
                testcases_res = self.push_testcases(suite_id, testcases)


    def push_suite(self, suite):
        response = self._client.create_suite(suite)
        if response.status_code != 201:
            raise Exception(f"Response Code: {response.status_code} {response.reason}\n"
                            f"Response Body:\n{response.json()}")
        return response

    def push_testcases(self, suite_id, testcases):
        response = self._client.create_testcases(suite_id, testcases)

        if response.status_code != 201:
            raise Exception(f"Response Code: {response.status_code} {response.reason}\n"
                            f"Response Body:\n{response.json()}")
            return response

    def push_testcase(self, suite_id, testcase):
        response = self._client.create_testcase(suite_id, testcase)

        raise Exception(f"Response Code: {response.status_code} {response.reason}\n"
                        f"Response Body:\n{response.json()}")
        return response

    def __parse_junit_xml(self, junit_xml, option):

        if option not in ["suites", "suite"]:
            raise ValueError("Invalid option passed, valid options are ["
                             "'suites', 'suite']")

        xml = JUnitXml.fromfile(junit_xml)

        suites = []
        testcases_all = []
        results = self.__get_suites_info(xml)
        timestamp = None

        testno = 1
        for suite in xml:
            suite_data = self.__get_suite_info(suite)

            if timestamp is None:
                timestamp = suite_data["timestamp"]

            testcases = []
            if option != "suites":
                testno = 1

            for case in suite:
                test = self.__get_testcase_info(case, testno)
                testcases.append(test)
                testno += 1

            if option == "suites":
                testcases_all.extend(testcases)
            else:
                suite_data["testcases"] = testcases
                suites.append(suite_data)

        if option == "suites":
            results["testcases"] = testcases_all
        else:
            results["suites"] = suites

        results["timestamp"] = timestamp
        return results

    def parse_junit_xml(self, junit_xml):
        return self.__parse_junit_xml(junit_xml, "suite")


    @staticmethod
    def __get_suites_info(xml):
        results = {}
        results["name"] = xml.name
        results["tests"] = xml.tests
        results["failures"] = xml.failures
        results["errors"] = xml.errors
        results["skipped"] = xml.skipped
        results["passed"] = xml.tests - xml.failures - xml.errors - xml.skipped
        results["failed"] = xml.failures + xml.errors
        results["time"] = round(xml.time, 3)

        if xml.skipped > 0:
            results["status"] = "SKIPPED"
        elif xml.failures + xml.errors > 0:
            results["status"] = "FAILED"
        else:
            results["status"] = "PASSED"

        import pdb
        pdb.set_trace()

        return results

    @staticmethod
    def __get_suite_info(suite):
        suite_data = {}
        suite_data["name"] = suite.name
        suite_data["tests"] = suite.tests
        suite_data["failures"] = suite.failures
        suite_data["errors"] = suite.errors
        suite_data["skipped"] = suite.skipped
        suite_data["passed"] = suite.tests - suite.failures - \
                               suite.errors - suite.skipped
        suite_data["failed"] = suite.failures + suite.errors
        suite_data["time"] = round(suite.time, 3)
        suite_data["timestamp"] = suite.timestamp

        import pdb
        pdb.set_trace()

        if suite.skipped > 0:
            suite_data["status"] = "SKIPPED"
        elif suite.failures + suite.errors > 0:
            suite_data["status"] = "FAILED"
        else:
            suite_data["status"] = "PASSED"

        return suite_data

    def __get_testcase_info(self, case, testno):
        status, message = self.__get_status_info(case)
        test = {
            "testno": testno,
            "testname": case.name,
            #"classname": case.classname,
            "status": status,
            "duration": round(case.time, 3),
            "message": message
        }

        import pdb
        pdb.set_trace()

        return test

    @staticmethod
    def __get_status_info(case):

        test_status = "PASSED"
        test_message = ""
        test_text = ""

        if case.result:
            result = case.result[0]
            if isinstance(result, Failure):
                test_status = "FAILED"
            elif isinstance(result, Skipped):
                test_status = "SKIPPED"
            elif isinstance(result, Error):
                test_status = "ERROR"

            test_message = result.message
            test_text = result.text
            test_type = result.type

        return test_status, test_message

    @staticmethod  
    def __populate_suite_data(suite, data):
        suite["total"] = data["tests"]
        suite["passed"] = data["passed"]
        suite["failed"] = data["failed"]
        suite["skipped"] = data["skipped"]
        suite["status"] = data["status"]
        suite["duration"] = data["time"]
        suite["created"] = data["timestamp"]

        return suite









