import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
import copy

def parser(junit_xml, option="suite"):
    root = ET.parse(junit_xml).getroot()
    _check_root_element(root)
    results = _get_suites_info(root)
    results = _get_test_suites_details(root, results, option)

    print(results)


def _check_root_element(root):
    if not root.tag.startswith("testsuites"):
        raise TypeError("Top level element is not a 'testsuite(s)'"
                        " but '{0}'".format(root.tag))


def _get_suites_info(root):
    suites = {
        "name": root.attrib.get("name", ""),
        "tests": int(root.attrib.get("tests", 0)),
        "failures": int(root.attrib.get("failures", 0)),
        "errors": int(root.attrib.get("errors", 0)),
        "skipped": int(root.attrib.get("skipped", 0)),
        "duration": float(root.attrib.get("time", 0)),
    }
    print(suites)
    # tests="327" failures="0" errors="0" time="19.156"
    # suites["skipped"] = xml.skipped
    # suites["passed"] = xml.tests - xml.failures - xml.errors - xml.skipped
    # suites["failed"] = xml.failures + xml.errors
    # suites["status"]
    return suites


def _get_test_suites_details(root, results, option):
    testsuites = root.findall("testsuite")
    if not testsuites:
        raise TypeError("'suites' element must contain at least "
                        "one 'suite'.")

    testno = 1
    timestamp = None
    testcases_all = []
    suites = []

    total_tests = 0
    total_errors = 0
    total_failures = 0
    total_skipped = 0
    total_duration = 0.0
    final_status = []

    for testsuite in testsuites:
        suite = _get_suite_info(testsuite)
        total_tests += suite["tests"]
        total_errors += suite["errors"]
        total_failures += suite["failures"]
        total_skipped += suite["skipped"]
        total_duration += suite["time"]
        final_status.append(suite["status"])

        if timestamp is None:
            timestamp = suite["timestamp"]

        if option == "suite":
            testno = 1

        testcases = []
        for test in testsuite.findall(".//testcase"):
            testcase = _get_testcase_info(test)
            testcase["testno"] = testno
            testno += 1

            testcases.append(testcase)

        if option == "suites":
            testcases_all.extend(testcases)
        else:
            suite["testcases"] = testcases
            suites.append(suite)

    if option == "suites":
        results["testcases"] = testcases_all
    else:
        results["suites"] = suites

    results["timestamp"] = timestamp

    if results["tests"] == 0:
        results["tests"] = total_tests
    if results["errors"] == 0:
        results["errors"] = total_errors
    if results["failures"] == 0:
        results["failures"] = total_failures
    if results["skipped"] == 0:
        results["skipped"] = total_skipped
    if results["duration"] == 0:
        results["duration"] = total_duration

    results["failed"] = results["failures"] + results["errors"]
    results["passed"] = results["tests"] - results["failed"] - results[
        "skipped"]

    if "FAILED" in final_status:
        results["status"] = "FAILED"
    elif "SKIPPED" in final_status:
        results["status"] = "SKIPPED"
    else:
        results["status"] = "PASSED"

    return results


def _get_suite_info(testsuite):
    suite = {
        "name": testsuite.attrib.get("name", ""),
        "tests": int(testsuite.attrib.get("tests", 0)),
        "errors": int(testsuite.attrib.get("errors", 0)),
        "failures": int(testsuite.attrib.get("failures", 0)),
        "skipped": int(testsuite.attrib.get("skipped", 0)),
        "time": round(float(testsuite.attrib.get("time", 0.0)), 3),
        "timestamp": testsuite.attrib.get("timestamp", ""),
    }

    suite["failed"] = suite["failures"] + suite["errors"]
    suite["passed"] = suite["tests"] - suite["failed"] - suite["skipped"]

    if suite["skipped"] > 0:
        suite["status"] = "SKIPPED"
    elif suite["failed"] > 0:
        suite["status"] = "FAILED"
    else:
        suite["status"] = "PASSED"

    print(suite)
    return suite


def _get_testcase_info(case):
    status, message = _get_test_status_info(case)

    test = {
        "name": case.attrib.get("name", ""),
        "classname": case.attrib.get("classname", ""),
        "status": status,
        "duration": round(float(case.attrib.get("time", 0.0)), 3),
        "message": message
    }

    print(test)
    return test


def _get_test_status_info(case):
    test_status = "PASSED"
    test_message = ""

    if list(case):
        if case[0].tag == "failure":
            test_status = "FAILED"
        elif case[0].tag == "error":
            test_status = "SKIPPED"
        elif case[0].tag == "skipped":
            test_status = "SKIPPED"
        test_message = case[0].text

    return test_status, test_message


class JUnitParser:

    def __init__(self, file, option="suite"):
        if option not in ["suites", "suite"]:
            raise ValueError("Invalid option passed, valid options are ["
                             "'suites', 'suite']")

        self.file = file
        self.option = option
        self.root = None

    def parse(self):
        self.root = ET.parse(self.file).getroot()
        self._check_root_element()
        suite_info = self._get_suites_info()
        results = self._get_test_suites_details(suite_info)

        return results

    def _check_root_element(self):
        if not self.root.tag.startswith("testsuites"):
            raise TypeError("Top level element is not a 'testsuite(s)'"
                            " but '{0}'".format(self.root.tag))

    def _get_suites_info(self):
        suites = {
            "name": self.root.attrib.get("name", ""),
            "tests": int(self.root.attrib.get("tests", 0)),
            "failures": int(self.root.attrib.get("failures", 0)),
            "errors": int(self.root.attrib.get("errors", 0)),
            "skipped": int(self.root.attrib.get("skipped", 0)),
            "duration": float(self.root.attrib.get("time", 0)),
        }

        return suites

    def _get_test_suites_details(self, suite_info):

        results = copy.deepcopy(suite_info)
        testsuites = self.root.findall("testsuite")
        if not testsuites:
            raise TypeError("'suites' element must contain at least "
                            "one 'suite'.")

        testno = 1
        timestamp = None
        testcases_all = []
        suites = []

        total_tests = 0
        total_errors = 0
        total_failures = 0
        total_skipped = 0
        total_duration = 0.0
        final_status = []

        for testsuite in testsuites:
            suite = _get_suite_info(testsuite)
            total_tests += suite["tests"]
            total_errors += suite["errors"]
            total_failures += suite["failures"]
            total_skipped += suite["skipped"]
            total_duration += suite["time"]
            final_status.append(suite["status"])

            if timestamp is None:
                timestamp = suite["timestamp"]

            if self.option == "suite":
                testno = 1

            testcases = []
            for test in testsuite.findall(".//testcase"):
                testcase = _get_testcase_info(test)
                testcase["testno"] = testno
                testno += 1

                testcases.append(testcase)

            if self.option == "suites":
                testcases_all.extend(testcases)
            else:
                suite["testcases"] = testcases
                suites.append(suite)

        if self.option == "suites":
            results["testcases"] = testcases_all
        else:
            results["suites"] = suites

        results["timestamp"] = timestamp

        if results["tests"] == 0:
            results["tests"] = total_tests
        if results["errors"] == 0:
            results["errors"] = total_errors
        if results["failures"] == 0:
            results["failures"] = total_failures
        if results["skipped"] == 0:
            results["skipped"] = total_skipped
        if results["duration"] == 0:
            results["duration"] = total_duration

        results["failed"] = results["failures"] + results["errors"]
        results["passed"] = results["tests"] - results["failed"] - results[
            "skipped"]

        if "FAILED" in final_status:
            results["status"] = "FAILED"
        elif "SKIPPED" in final_status:
            results["status"] = "SKIPPED"
        else:
            results["status"] = "PASSED"

        return results

    @staticmethod
    def _get_suite_info(testsuite):
        suite = {
            "name": testsuite.attrib.get("name", ""),
            "tests": int(testsuite.attrib.get("tests", 0)),
            "errors": int(testsuite.attrib.get("errors", 0)),
            "failures": int(testsuite.attrib.get("failures", 0)),
            "skipped": int(testsuite.attrib.get("skipped", 0)),
            "time": round(float(testsuite.attrib.get("time", 0.0)), 3),
            "timestamp": testsuite.attrib.get("timestamp", ""),
        }

        suite["failed"] = suite["failures"] + suite["errors"]
        suite["passed"] = suite["tests"] - suite["failed"] - suite["skipped"]

        if suite["skipped"] > 0:
            suite["status"] = "SKIPPED"
        elif suite["failed"] > 0:
            suite["status"] = "FAILED"
        else:
            suite["status"] = "PASSED"

        print(suite)
        return suite

    @staticmethod
    def _get_testcase_info(case):
        status, message = _get_test_status_info(case)

        test = {
            "name": case.attrib.get("name", ""),
            "classname": case.attrib.get("classname", ""),
            "status": status,
            "duration": round(float(case.attrib.get("time", 0.0)), 3),
            "message": message
        }

        print(test)
        return test

    @staticmethod
    def _get_test_status_info(case):
        test_status = "PASSED"
        test_message = ""

        if list(case):
            if case[0].tag == "failure":
                test_status = "FAILED"
            elif case[0].tag == "error":
                test_status = "SKIPPED"
            elif case[0].tag == "skipped":
                test_status = "SKIPPED"
            test_message = case[0].text

        return test_status, test_message

filename = "junit_unit_mapi.xml"
# filename = "report.xml"
#parser(filename, option="suites")

obj = JUnitParser(filename, option="suites")
results = obj.parse()
print(results)
