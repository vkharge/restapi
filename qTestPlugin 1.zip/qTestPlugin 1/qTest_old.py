from datetime import datetime, timedelta, timezone
import xml.etree.ElementTree as ET

import jsons as jsons
from gti_scutils.tms.tms import TMS
from junitparser import Failure, Skipped, Error
from junitparser import JUnitXml


class QTestExecution:
    _PARENT_TYPE_RELEASE = "release"

    def __init__(self, server, token, project_name, debug=False):
        self._server = server
        self._token = token
        self._project_name = project_name
        self._debug = debug
        self._tms = TMS()
        self._tms.debug = debug
        self._tms._token = token

        self.__validate_token()
        self.__validate_project()

    def push_junit_results(self, release_name, build_number, build_url,
                           junit_xml_file):

        release = self.__create_release(release_name)
        build = self.__create_build(release.id, build_number)
        test_cycle = self.__create_test_cycle(release.id, build_number)

        testcases = self.__parse_junit_xml_for_qTest(junit_xml_file)

        if not testcases:
            raise ValueError(f"Junit XML '{junit_xml_file}' does not have "
                             f"test cases")

        testcases = [
            dict(test, build_number=build_number, build_url=build_url)
            for test in testcases
        ]
        print(testcases)

        testsuite = {
            "test_cycle": test_cycle.id,
            "test_logs": testcases,
        }

        self._tms.run_batch(self._project.id, testsuite)
        self._tms.poll_batch()

    def push_results(self, release_name, build_number, build_url, testcases):

        release = self.__create_release(release_name)
        build = self.__create_build(release.id, build_number)
        test_cycle = self.__create_test_cycle(release.id, build_number)

        self.__validate_testcases_type(testcases)
        testcases = [
            self.__validate_testcase_content(
                test, build_number=build_number, build_url=build_url)
            for test in testcases
        ]
        print(testcases)

        testsuite = {
            "test_cycle": test_cycle.id,
            "test_logs": testcases,
        }

        self._tms.run_batch(self._project.id, testsuite)
        self._tms.poll_batch()

    def __parse_junit_xml_for_qTest(self, junit_xml):

        testcases = []
        xml = JUnitXml.fromfile(junit_xml)
        tz = datetime.now(timezone.utc).astimezone().tzinfo

        for index, suite in enumerate(xml):
            try:
                suite_timestamp = datetime.strptime(suite.timestamp,
                                                    "%Y-%m-%dT%H:%M:%S")
            except:
                suite_timestamp = datetime.strptime(suite.timestamp,
                                                    "%Y-%m-%dT%H:%M:%S.%f")

            time_delta = timedelta(seconds=0)

            for case in suite:
                start_time = (suite_timestamp + time_delta).astimezone(tz) \
                    .strftime("%Y-%m-%dT%H:%M:%S%z")
                time_delta += timedelta(seconds=float(case.time))
                end_time = (suite_timestamp + time_delta).astimezone(tz) \
                    .strftime("%Y-%m-%dT%H:%M:%S%z")

                dir_path = self.__construct_directory(index, xml.name,
                                                      suite.name,
                                                      case.classname)

                test_status, note_info = self.__get_status_info(case)
                test = {
                    "name": case.name,
                    "status": test_status,
                    "module_names": dir_path,
                    "exe_start_date": start_time,
                    "exe_end_date": end_time,
                    "automation_content": case.classname + "." + case.name,
                    "note": "note: " + note_info,
                }

                testcases.append(test)

        return testcases

    def __parse_junit_xml(self, junit_xml):

        testcases = []

        # Parse junit xml report
        root = ET.parse(junit_xml).getroot()
        if not root.tag.startswith("testsuite"):
            raise TypeError(
                "Top level element is not a 'testsuite(s)' but '{0}'".format(
                    root.tag))

        if root.tag == "testsuites":

            testsuites = root.findall("testsuite")
            if not testsuites:
                raise TypeError(
                    "'Testsuites' element must contain at least one 'testsuite'.")

        root_name = root.attrib.get("name")
        tz = datetime.now(timezone.utc).astimezone().tzinfo
        # Gather test data for each testsuite listed in the junit test report
        for testsuite in testsuites:

            # Not currently used
            test_suite_name = testsuite.attrib.get("name", "?")
            # Not currently used
            test_suite_duration = testsuite.attrib.get("time", 0)
            test_suite_time = datetime.strptime(
                testsuite.attrib.get("timestamp",
                                     datetime.now().strftime(
                                         "%Y-%m-%dT%H:%M:%S")),
                "%Y-%m-%dT%H:%M:%S")
            # Not currently used
            test_suite_stats = {
                "skipped": testsuite.attrib.get("skipped",
                                                testsuite.attrib.get("skips",
                                                                     None)),
                "errors": testsuite.attrib.get("errors", None),
                "failures": testsuite.attrib.get("failures", None),
                "tests": testsuite.attrib.get("tests", None)
            }

            # Iterate through each test result in a test suite
            for elem in testsuite.findall(".//testcase"):

                tc_name = elem.attrib.get("name", "<missing name>")
                tc_time = timedelta(seconds=float(elem.attrib.get('time', 0)))
                tc_classname = elem.attrib.get("classname", None)

                tc_message = None
                tc_text = None
                tc_stderr = None
                tc_stdout = None
                tc_backtrace = None
                tc_outcome = "PASS"

                # Parse tags for non-passed tests
                for child in elem:
                    if child.tag == "system-err":
                        tc_stderr = child.text
                    elif child.tag == "system-out":
                        tc_stdout = child.text
                    elif child.tag == "skipped":
                        tc_outcome = "SKIP"
                        tc_msg = child.attrib.get("type",
                                                  "") + ": " + child.attrib.get(
                            "message", "")
                        tc_text = child.text
                    elif child.tag == "failure":
                        tc_outcome = "FAIL"
                        tc_msg = child.attrib.get("message", None)
                        tc_text = child.text
                    elif child.tag == "error":
                        tc_outcome = "ERROR"
                        tc_msg = child.attrib.get("message", None)
                        tc_text = child.text

                if self._debug:
                    print("name: " + tc_name)
                    print("time: " + str(tc_time))
                    print("classname: " + tc_classname)
                    print("outcome: " + tc_outcome)
                    if tc_message is not None:
                        print("message: " + tc_message)
                    if tc_text is not None:
                        print("text: " + tc_text)
                    if tc_stdout is not None:
                        print("stdout: " + tc_stdout)
                    if tc_stderr is not None:
                        print("stderr: " + tc_stderr)
                    if tc_backtrace is not None:
                        print("backtrace: " + tc_backtrace)

                if len(tc_classname) == 0:
                    print("test case \"{0}\" - skipping ({1}: {2})".format(
                        tc_name,
                        tc_outcome,
                        tc_msg))
                    continue

                note_info = tc_message if tc_message is not None else ""
                if tc_text is not None:
                    note_info += "---- text ----\n" + tc_text
                if tc_stdout is not None:
                    note_info += "---- standard output ----\n" + tc_stdout
                if tc_stderr is not None:
                    note_info += "---- standard error ----\n" + tc_stderr
                if tc_backtrace is not None:
                    note_info += "---- backtrace ----\n" + tc_backtrace

                exe_start_time = test_suite_time.astimezone(tz).strftime(
                    "%Y-%m-%dT%H:%M:%S%z")
                exe_end_time = (test_suite_time + tc_time).astimezone(
                    tz).strftime(
                    "%Y-%m-%dT%H:%M:%S%z")

                # Create entry for test case, including qTest object attributes
                log = {
                    "name": tc_name,
                    "status": tc_outcome,
                    "module_names": [root_name] + test_suite_name.split("/")[
                                                  1:],
                    "exe_start_date": exe_start_time,
                    "exe_end_date": exe_end_time,
                    "automation_content": tc_classname + "." + tc_name,
                    "note": "note: " + note_info,
                }
                testcases.append(log)

        return testcases

    def __validate_token(self):
        print("Validate the authorization token")
        if self._tms.tms_get("", None) is None:
            raise KeyError("QTest Token is not authorised")
        else:
            print("QTest Token is valid")

    def __validate_project(self):
        print(f"Validate the {self._project_name} project")
        if self.__validate_blank(self._project_name):
            raise ValueError(f"Project name cannot be None or blank")

        try:
            self._project = self._tms.get_project_by_name(self._token,
                                                          self._project_name)
        except:
            raise ValueError(f"Project {self._project_name} not found")

    @staticmethod
    def __validate_blank(value):
        if value is None:
            return True
        elif value.strip() == "":
            return True

        return False

    def __create_release(self, release_name):
        if self.__validate_blank(release_name):
            raise ValueError(f"Release name cannot be None or blank")

        release = self._tms.get_release_by_attribute(self._token,
                                                     str(self._project.id),
                                                     "name", release_name)

        if release is None:
            release = self._tms.create_release(self._token,
                                               str(self._project.id),
                                               release_name)
        return release

    def __create_build(self, release_id, build_number):
        if self.__validate_blank(build_number):
            raise ValueError(f"Build number cannot be None or blank")

        build = self._tms.get_build_by_name(self._token, str(self._project.id),
                                            build_number, release_id)

        if build is None:
            build = self._tms.create_build(self._token, str(self._project.id),
                                           build_number, False, release_id,
                                           self._PARENT_TYPE_RELEASE)
        return build

    def __create_test_cycle(self, release_id, test_cycle_name):
        if self.__validate_blank(test_cycle_name):
            raise ValueError(f"Test cycle name cannot be None or blank")

        test_cycle = self._tms.get_build_cycle_by_name(
            self._token, str(self._project.id), test_cycle_name,
            str(release_id), self._PARENT_TYPE_RELEASE)

        if test_cycle is None:
            test_cycle = self._tms.create_build_cycle(
                self._token, str(self._project.id), test_cycle_name,
                str(release_id), self._PARENT_TYPE_RELEASE)

        return test_cycle

    @staticmethod
    def __get_status_info(case):

        test_status = "PASS"
        test_message = None
        test_text = None

        if case.result:
            result = case.result[0]
            if isinstance(result, Failure):
                test_status = "FAIL"
            elif isinstance(result, Skipped):
                test_status = "SKIP"
            elif isinstance(result, Error):
                test_status = "ERROR"

            test_message = result.message
            test_text = result.text
            test_type = result.type

        note_info = ""
        if test_message is not None:
            note_info += test_message if test_type is None else \
                f"{test_type}: {test_message}"
        if test_text is not None:
            note_info += "---- text ----\n" + test_text
        if case.system_out is not None:
            note_info += "---- standard output ----\n" + case.system_out
        if case.system_err is not None:
            note_info += "---- standard error ----\n" + case.system_err

        return test_status, note_info

    @staticmethod
    def __construct_directory(number, suites_name=None, suite_name=None,
                              class_name=None):

        suites_dir = ["Automation" if suites_name is None else suites_name]

        if suite_name:
            if "/" in suite_name:
                suite_dir = suite_name.split("/")[1:]
            else:
                suite_dir = [suite_name]
        else:
            suite_dir = [f"/Suite{number}"]

        class_dir = [] if class_name in suite_name else [class_name]

        return suites_dir + suite_dir + class_dir

    @staticmethod
    def __validate_testcases_type(testcases):

        if not testcases:
            raise ValueError(f"Testcases object cannot be empty or None")

        if isinstance(testcases, list):
            pass
        else:
            raise ValueError(f"Testcases results should be passed as list "
                             f"of dict")

    @staticmethod
    def __validate_testcase_content(testcase, build_number, build_url):

        testcase_keys = {"name", "status", "module_names", "exe_start_date",
                         "exe_end_date", "automation_content", "note"}

        testcase_status = ["PASS", "FAIL", "SKIP", "ERROR"]

        if set(testcase_keys) != set(testcase.keys()):
            raise ValueError("Testcase dict has missing matching keys")

        if testcase["name"] is None or testcase["name"] == "":
            raise ValueError("Testcase name cannot be empty or blank")

        if testcase["status"] not in testcase_status:
            raise ValueError(f"Testcase status should be {testcase_status}")

        if not testcase["module_names"] or \
                not isinstance(testcase["module_names"], list):
            raise ValueError(f"Module Names should be non empty list")

        if testcase["exe_start_date"] is None or\
                testcase["exe_start_date"] == "":
            raise ValueError(f"exe_start_date should be in "
                             f"'2021-10-06T19:02:00+1100' format")

        try:
            datetime.strptime(testcase["exe_start_date"],
                              "%Y-%m-%dT%H:%M:%S%z")
        except ValueError:
            raise ValueError("Incorrect exe_start_date format, should be "
                             "'2021-10-06T19:02:00+1100' format")

        if testcase["exe_end_date"] is None or\
                testcase["exe_end_date"] == "":
            raise ValueError(f"exe_end_date should be in "
                             f"'2021-10-06T19:02:00+1100' format")

        try:
            datetime.strptime(testcase["exe_end_date"],
                              "%Y-%m-%dT%H:%M:%S%z")
        except ValueError:
            raise ValueError("Incorrect exe_end_date format, should be "
                             "'2021-10-06T19:02:00+1100' format")

        if testcase["automation_content"] is None or \
                not isinstance(testcase["automation_content"], str):
            raise ValueError(f"automation_content should be string")

        if testcase["note"] is None or \
                not isinstance(testcase["note"], str):
            raise ValueError(f"note should be string")

        dict(testcase, build_number=build_number, build_url=build_url)

        return testcase


if __name__ == "__main__":
    QTEST_SERVER = "dolby.qtestnet.com"
    QTEST_TOKEN = "ZG9sYnl8VmlzaGFsLktoYXJnZUBkb2xieS5jb206MTY2NTEwMDg" \
                  "4NjU1MTo4OWVlZjY2M2UxOTA3NWYxMDU5NWM1ODc0MWNlYmViNA"
    QTEST_PROJECT_NAME = "AP3"

    release_name = "Artemis-Test-Plan"  # CI_COMMIT_BRANCH
    parent_type_release = "release"
    build_number = "commit_sha_#4"  # CI_COMMIT_SHORT_SHA

    junit_xml_file = "junit.xml"
    build_url = "https://gitlab-sfo.dolby.net/ap3/loki/-/pipelines/265787"  # CI_PIPELINE_URL

    qTest = QTestExecution(QTEST_SERVER, QTEST_TOKEN, QTEST_PROJECT_NAME)
    qTest.push_junit_results(release_name, build_number, build_url,
                             junit_xml_file)

    testcase = {
        "name": "",
        "status": "PASS",
        "module_names": ["Automated Tests", "unit", "packaging_tasks.test.js"],
        "exe_start_date": "2021-10-06T19:02:00+1100",
        "exe_end_date": "2021-10-06T19:02:10+1100",
        "automation_content": "packaging_tasks.test.js.Test HLS task",
        "note": ""
    }
    testcases = [testcase]
    qTest.push_results(release_name, build_number, build_url,
                       testcases=testcases)




if __name__ == "__main__":
    QTEST_SERVER = "dolby.qtestnet.com"
    QTEST_TOKEN = "ZG9sYnl8VmlzaGFsLktoYXJnZUBkb2xieS5jb206MTY2NTEwMDg" \
                  "4NjU1MTo4OWVlZjY2M2UxOTA3NWYxMDU5NWM1ODc0MWNlYmViNA"
    QTEST_PROJECT_NAME = "AP3"

    qtest_dir_path = "Test Cases/Artemis/Automation"
    release_name = "Artemis-Test-Plan"  # CI_COMMIT_BRANCH
    parent_type_release = "release"
    build_number = "commit_sha_#4"  # CI_COMMIT_SHORT_SHA

    junit_xml_file = "report.xml"
    build_url = "https://gitlab-sfo.dolby.net/ap3/loki/-/pipelines/265787"  # CI_PIPELINE_URL

    qTest = QTestExecution(QTEST_SERVER, QTEST_TOKEN, QTEST_PROJECT_NAME)
    qTest.push_results_junit(release_name, build_number, build_url,
                             junit_xml_file, qtest_dir_path)

    # testcase = {
    #     "name": "TC1",
    #     "status": "PASS",
    #     "module_names": ["Automated Tests", "unit", "packaging_tasks.test.js"],
    #     "exe_start_date": "2021-10-06T19:02:00+1100",
    #     "exe_end_date": "2021-10-06T19:02:10+1100",
    #     "automation_content": "packaging_tasks.test.js.Test HLS task",
    #     "note": ""
    # }
    # testcases = [testcase]
    # qTest.push_results(release_name, build_number, build_url,
    #                    testcases=testcases)
