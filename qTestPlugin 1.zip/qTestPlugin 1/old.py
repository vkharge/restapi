import sys
import os
import argparse
from datetime import datetime, timedelta, timezone
import xml.etree.ElementTree as ET
from gti_scutils.tms.tms import TMS

class TestExecutionSetup:
    """
    """

    def __init__(self):
        self.__release = None
        self.__build = None
        self.__test_cycle = None

    @property
    def release(self):
        return self.__release

    @release.setter
    def release(self, value):
        self.__release = value

    @property
    def build(self):
        return self.__build

    @build.setter
    def build(self, value):
        self.__build = value

    @property
    def test_cycle(self):
        return self.__test_cycle

    @test_cycle.setter
    def test_cycle(self, value):
        self.__test_cycle = value


QTEST_SERVER = "dolby.qtestnet.com"
QTEST_TOKEN = "ZG9sYnl8VmlzaGFsLktoYXJnZUBkb2xieS5jb206MTY2NTEwMDg4NjU1MTo4OWVlZjY2M2UxOTA3NWYxMDU5NWM1ODc0MWNlYmViNA"
QTEST_PROJECT_NAME = "AP3"

release_name = "Artemis-develop"  # CI_COMMIT_BRANCH
parent_type_release = "release"
build_number = "commit_sha_#4"  # CI_COMMIT_SHORT_SHA

junit_xml_file = "junit.xml"
build_url = "https://gitlab-sfo.dolby.net/ap3/loki/-/pipelines/265787"  # CI_PIPELINE_URL


# build_number
# build_test_cycle
# build_url
def parse_junit_xml(path, build_number, build_test_cycle, build_url=None,
                    debug=False):
    request = {
        "test_cycle": build_test_cycle.id,
        "test_logs": [],
    }

    # Parse junit xml report
    root = ET.parse(path).getroot()
    if not root.tag.startswith("testsuite"):
        raise TypeError(
            "Top level element is not a 'testsuite(s)' but '{0}'".format(
                root.tag))

    if root.tag == "testsuites":

        testsuites = root.findall("testsuite")
        if not testsuites:
            raise TypeError(
                "'Testsuites' element must contain at least one 'testsuite'.")

    root_name = root.attrib.get("name")
    tz = datetime.now(timezone.utc).astimezone().tzinfo
    # Gather test data for each testsuite listed in the junit test report
    for testsuite in testsuites:

        # Not currently used
        test_suite_name = testsuite.attrib.get("name", "?")
        # Not currently used
        test_suite_duration = testsuite.attrib.get("time", 0)
        test_suite_time = datetime.strptime(testsuite.attrib.get("timestamp",
                                                                 datetime.now().strftime(
                                                                     "%Y-%m-%dT%H:%M:%S")),
                                            "%Y-%m-%dT%H:%M:%S")
        # Not currently used
        test_suite_stats = {
            "skipped": testsuite.attrib.get("skipped",
                                            testsuite.attrib.get("skips",
                                                                 None)),
            "errors": testsuite.attrib.get("errors", None),
            "failures": testsuite.attrib.get("failures", None),
            "tests": testsuite.attrib.get("tests", None)
        }

        # Iterate through each test result in a test suite
        for elem in testsuite.findall(".//testcase"):

            tc_name = elem.attrib.get("name", "<missing name>")
            tc_time = timedelta(seconds=float(elem.attrib.get('time', 0)))
            tc_classname = elem.attrib.get("classname", None)

            tc_message = None
            tc_text = None
            tc_stderr = None
            tc_stdout = None
            tc_backtrace = None
            tc_outcome = "PASS"

            # Parse tags for non-passed tests
            for child in elem:
                if child.tag == "system-err":
                    tc_stderr = child.text
                elif child.tag == "system-out":
                    tc_stdout = child.text
                elif child.tag == "skipped":
                    tc_outcome = "SKIP"
                    tc_msg = child.attrib.get("type",
                                              "") + ": " + child.attrib.get(
                        "message", "")
                    tc_text = child.text
                elif child.tag == "failure":
                    tc_outcome = "FAIL"
                    tc_msg = child.attrib.get("message", None)
                    tc_text = child.text
                elif child.tag == "error":
                    tc_outcome = "ERROR"
                    tc_msg = child.attrib.get("message", None)
                    tc_text = child.text

            if debug:
                print("name: " + tc_name)
                print("time: " + str(tc_time))
                print("classname: " + tc_classname)
                print("outcome: " + tc_outcome)
                if tc_message is not None:
                    print("message: " + tc_message)
                if tc_text is not None:
                    print("text: " + tc_text)
                if tc_stdout is not None:
                    print("stdout: " + tc_stdout)
                if tc_stderr is not None:
                    print("stderr: " + tc_stderr)
                if tc_backtrace is not None:
                    print("backtrace: " + tc_backtrace)

            if len(tc_classname) == 0:
                print("test case \"{0}\" - skipping ({1}: {2})".format(tc_name,
                                                                       tc_outcome,
                                                                       tc_msg))
                continue

            note_info = tc_message if tc_message is not None else ""
            if tc_text is not None:
                note_info += "---- text ----\n" + tc_text
            if tc_stdout is not None:
                note_info += "---- standard output ----\n" + tc_stdout
            if tc_stderr is not None:
                note_info += "---- standard error ----\n" + tc_stderr
            if tc_backtrace is not None:
                note_info += "---- backtrace ----\n" + tc_backtrace

            exe_start_time = test_suite_time.astimezone(tz).strftime(
                "%Y-%m-%dT%H:%M:%S%z")
            exe_end_time = (test_suite_time + tc_time).astimezone(tz).strftime(
                "%Y-%m-%dT%H:%M:%S%z")

            # Create entry for test case, including qTest object attributes
            log = {
                "name": tc_name,
                "status": tc_outcome,
                "module_names": [root_name] + test_suite_name.split("/")[1:],
                "exe_start_date": exe_start_time,
                "exe_end_date": exe_end_time,
                "automation_content": tc_classname + "." + tc_name,
                "note": "note: " + note_info,
            }
            if build_number is not None:
                log["build_number"] = build_number
            if build_url is not None:
                log["build_url"] = build_url

            request["test_logs"].append(log)

    return request


tms = TMS()
tms._token = QTEST_TOKEN

if tms.tms_get("", None) is None:
    raise KeyError("QTest Token is not authorised")
else:
    print("QTest Token is valid")

tms.debug = True

print("========= Projects ==========")
projects = tms.get_projects(QTEST_TOKEN)
for project in projects:
    print(project)

print("========= Project ==========")
try:
    project = tms.get_project_by_name(QTEST_TOKEN, QTEST_PROJECT_NAME)
    print(project)
    print(project.id)
    print(project.name)
except:
    print("Project NOT FOUND")

release = tms.get_release_by_attribute(QTEST_TOKEN, str(project.id), "name",
                                       release_name)
if release is None:
    release = tms.create_release(QTEST_TOKEN, str(project.id), release_name)

print(release.id)
print(release.name)

print("========= Build ==========")
build = tms.get_build_by_name(QTEST_TOKEN, str(project.id), None, release.id)
if build is None:
    build = tms.create_build(QTEST_TOKEN, str(project.id), None, False,
                             release.id, parent_type_release)
print(build.id)
print(build.name)

print("========= Builds ==========")
builds = tms.get_builds(QTEST_TOKEN, str(project.id), release.id)
for build in builds:
    print(build.id)
    print(build.name)

print("========= Build Cycle ==========")
build_test_cycle = tms.get_build_cycle_by_name(QTEST_TOKEN, str(project.id),
                                               build_number, str(release.id),
                                               parent_type_release)
if build_test_cycle is None:
    build_test_cycle = tms.create_build_cycle(QTEST_TOKEN, str(project.id),
                                              build_number, str(release.id),
                                              parent_type_release)
print(build_test_cycle.id)
print(build_test_cycle.name)

print("========= Build Cycles ==========")
build_test_cycles = tms.get_build_cycles(QTEST_TOKEN, str(project.id),
                                         str(release.id), parent_type_release)
for build_cycle in build_test_cycles:
    print(build_cycle.id)
    print(build_cycle.name)

print("========= Process XML ==========")

request = parse_junit_xml(junit_xml_file, build_number, build_test_cycle,
                          build_url, True)
print(request)

tms.run_batch(project.id, request)
tms.poll_batch()


# def setup_test_execution(self, release_name, build_number,
#                          test_cycle_name):
#     self.test_setup = TestExecutionSetup()
#     self.test_setup.release = self.__create_release(release_name)
#     self.test_setup.build = self.__create_build(self.release.id,
#                                                 build_number)
#     self.test_setup.test_cycle = self.__create_test_cycle(self.release.id,
#                                                           test_cycle_name)
#
#
# def __parse_junit_xml_for_qTest(self, junit_xml):
#
#         testcases = []
#
#         xml = JUnitXml.fromfile(junit_xml)
#         suites_name = xml.name
#         total_tests = xml.tests
#         total_skip = xml.skipped
#         total_fails = xml.failures
#         total_error = xml.errors
#         total_time = xml.time
#
#
#         for suite in xml:
#             suite_name = suite.name
#             suite_tests = suite.tests
#             suite_skip = suite.skipped
#             suite_fail = suite.failures
#             suite_error = suite.errors
#             suite_time = suite.time
#             #suite_timestamp = suite.timestamp
#
#             suite_start_timestamp = datetime.strptime(suite.timestamp,
#                                                       "%Y-%m-%dT%H:%M:%S")
#             time_delta = 0
#             for case in suite:
#                 test_name = case.name
#                 test_classname = case.classname
#                 test_time = case.time
#
#                 start_time = (suite_start_timestamp + time_delta).strftime(
#                     "%Y-%m-%dT%H:%M:%S%z")
#                 time_delta += timedelta(seconds=float(test_time))
#                 end_time = (suite_start_timestamp + time_delta).strftime(
#                     "%Y-%m-%dT%H:%M:%S%z")
#
#                 test_status = "PASS"
#                 test_message = None
#                 test_text = None
#                 case.system_out
#
#                 if case.result:
#                     if isinstance(case.result, Failure):
#                         test_status = "FAIL"
#                     elif isinstance(case.result, Skipped):
#                         test_status = "SKIP"
#                     elif isinstance(case.result, Error):
#                         test_status = "ERROR"
#
#                     type = case.result.type
#                     test_message = case.result.message
#                     test_text = case.result.text
#
#                 note_info = test_message if test_message is not None else ""
#                 if test_text is not None:
#                     note_info += "---- text ----\n" + test_text
#                 if case.system_out is not None:
#                     note_info += "---- standard output ----\n" + case.system_out
#                 if case.system_err is not None:
#                     note_info += "---- standard error ----\n" + case.system_err
#
#
#
#                 test = {
#                     "name": test_name,
#                     "status": test_status,
#                     "module_names": [suites_name] + suite_name.split("/")[1:],
#                     "exe_start_date": start_time,
#                     "exe_end_date": end_time,
#                     "automation_content": test_classname + "." + test_name,
#                     "note": "note: " + note_info,
#                 }
#
#                 testcases.append(test)
#                 print(case)
#
#         return testcases
