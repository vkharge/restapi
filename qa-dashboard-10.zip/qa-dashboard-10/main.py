import uvicorn

from app.common import config

if __name__ == "__main__":
    uvicorn.run(app="app.main:app",
                host=config.app.hostname,
                port=config.app.port,
                log_level="debug",
                reload=True,
                debug=True)
