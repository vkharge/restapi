
QA-Dashboard


Requirements
- python3.8
- mysql db
- fastapi

Installation:
1. Install python3.8
2. Install pycodestyle: pip install pycodestyle
3. Create Virtual Environment
   apt-get install -y python3-venv
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -U pip
   python -m pip install -r app/requirements.txt
