from fastapi import APIRouter, Depends, status
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from app.api_crud import product_crud
from app.db.db_connection import get_db
from app.api_routers.apikey_auth import get_admin_api_key, \
    get_user_api_key
from app.schemas import req_schemas


router = APIRouter(
    prefix="/products",
    tags=["Product"],
    include_in_schema=True
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_product(payload: req_schemas.Product,
                         db: Session = Depends(get_db),
                         api_key: APIKey = Depends(get_admin_api_key)):
    return product_crud.create_product(payload, db)


@router.get("/")
async def read_products(db: Session = Depends(get_db),
                        api_key: APIKey = Depends(get_user_api_key)):
    return product_crud.get_products(db)


@router.get("/{product_id}")
async def read_product_by_id(product_id: int, db: Session = Depends(get_db),
                             api_key: APIKey = Depends(get_user_api_key)):
    return product_crud.get_product_by_id(product_id, db)


@router.get("/name/{product_name}")
async def read_product_by_name(product_name: str,
                               db: Session = Depends(get_db),
                               api_key: APIKey = Depends(get_user_api_key)):
    return product_crud.get_product_by_name(product_name, db)


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_product(product_id: int, db: Session = Depends(get_db),
                         api_key: APIKey = Depends(get_admin_api_key)):
    return product_crud.delete_product(product_id, db)


@router.put("/{product_id}", status_code=status.HTTP_202_ACCEPTED)
async def update_product(product_id: int, payload: req_schemas.Product,
                         db: Session = Depends(get_db),
                         api_key: APIKey = Depends(get_admin_api_key)):
    return product_crud.update_product(product_id, payload, db)
