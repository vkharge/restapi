from fastapi import Security, HTTPException
from fastapi.security import APIKeyHeader
from starlette.status import HTTP_403_FORBIDDEN


USER_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJyZWFkb25se" \
               "XVzZXIifQ.v_6EWKcDWe6k40HxjGG6tN-69Ruw5BrYUcl_nvjRSEo"
ADMIN_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbnVz" \
                "ZXJhY2Nlc3MifQ.JmramKoSle2GeMQpox0AZURj_9_4fIJkgvOxZVQ7SU0"
ADMIN_API_KEY2 = "Sydney@2021"
API_KEY_NAME = "access_token"
api_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)


async def get_user_api_key(api_key_header: str = Security(api_header)):
    if api_key_header == USER_API_KEY:
        return api_key_header
    elif api_key_header in [ADMIN_API_KEY, ADMIN_API_KEY2]:
        return api_key_header
    else:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="Unauthorized access to the API"
        )


async def get_admin_api_key(api_key_header: str = Security(api_header)):
    if api_key_header in [ADMIN_API_KEY, ADMIN_API_KEY2]:
        return api_key_header
    else:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="Unauthorized access to the API"
        )
