from fastapi import APIRouter, Depends, status
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from app.api_crud import test_type_crud
from app.db.db_connection import get_db
from app.api_routers.apikey_auth import get_admin_api_key, get_user_api_key
from app.schemas import req_schemas


router = APIRouter(
    prefix="/test-types",
    tags=["Test-Type"],
    include_in_schema=True
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_test_type(payload: req_schemas.TestType,
                           db: Session = Depends(get_db),
                           api_key: APIKey = Depends(get_admin_api_key)):
    return test_type_crud.create_test_type(payload, db)


@router.get("/")
async def read_test_types(db: Session = Depends(get_db),
                          api_key: APIKey = Depends(get_user_api_key)):
    return test_type_crud.get_test_types(db)


@router.get("/{test_type_id}")
async def read_test_type_by_id(test_type_id: int,
                               db: Session = Depends(get_db),
                               api_key: APIKey = Depends(get_user_api_key)):
    return test_type_crud.get_test_type_by_id(test_type_id, db)


@router.get("/name/{test_type_name}")
async def read_test_type_by_name(test_type_name: str,
                                 db: Session = Depends(get_db),
                                 api_key: APIKey = Depends(get_user_api_key)):
    return test_type_crud.get_test_type_by_name(test_type_name, db)


@router.delete("/{test_type_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_test_type(test_type_id: int, db: Session = Depends(get_db),
                           api_key: APIKey = Depends(get_admin_api_key)):
    return test_type_crud.delete_test_type(test_type_id, db)


@router.put("/{test_type_id}", status_code=status.HTTP_202_ACCEPTED)
async def update_test_type(test_type_id: int, payload: req_schemas.TestType,
                           db: Session = Depends(get_db),
                           api_key: APIKey = Depends(get_admin_api_key)):
    return test_type_crud.update_test_type(test_type_id, payload, db)
