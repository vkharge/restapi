
from fastapi import APIRouter, Depends
from fastapi.openapi.models import APIKey
from app.api_routers.apikey_auth import get_user_api_key

router = APIRouter(
    prefix="/validate-token",
    tags=["Validate Token"],
    include_in_schema=False
)


@router.get("/")
async def validate_token(api_key: APIKey = Depends(get_user_api_key)):
    return {"detail": f"Access token '{api_key}' is valid"}
