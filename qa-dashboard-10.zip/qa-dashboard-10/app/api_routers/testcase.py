from fastapi import APIRouter, Depends
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from starlette import status

from app.db.db_connection import get_db
from app.api_crud import testcase_crud
from app.api_routers.apikey_auth import get_user_api_key
from app.schemas import req_schemas, res_schemas


router = APIRouter(
    prefix="/suites/{suite_id}/testcases",
    tags=["TestCase"]
)


@router.post("", status_code=status.HTTP_201_CREATED,
             response_model=res_schemas.TestCase)
async def create_testcase(suite_id: int, payload: req_schemas.TestCase,
                          overwrite: bool = False,
                          db: Session = Depends(get_db),
                          api_key: APIKey = Depends(get_user_api_key)):
    return testcase_crud.create_testcase(suite_id, payload, overwrite, db)


@router.post("/bulk", status_code=status.HTTP_201_CREATED,
             response_model=res_schemas.TestCases)
async def create_testcases(suite_id: int, payload: req_schemas.TestCases,
                           overwrite: bool = False,
                           db: Session = Depends(get_db),
                           api_key: APIKey = Depends(get_user_api_key)):
    return testcase_crud.create_testcases(suite_id, payload, overwrite, db)


@router.get("/", response_model=res_schemas.TestCases)
async def read_testcases(suite_id: int, db: Session = Depends(get_db),
                         api_key: APIKey = Depends(get_user_api_key)):
    return testcase_crud.get_testcases(suite_id, db)


@router.get("/{testcase_id}", response_model=res_schemas.TestCase)
async def read_testcase(suite_id: int, testcase_id: int,
                        db: Session = Depends(get_db),
                        api_key: APIKey = Depends(get_user_api_key)):
    return testcase_crud.get_testcase(suite_id, testcase_id, db)


@router.delete("/", status_code=status.HTTP_204_NO_CONTENT)
async def delete_testcases(suite_id: int, db: Session = Depends(get_db),
                           api_key: APIKey = Depends(get_user_api_key)):
    return testcase_crud.delete_testcases(suite_id, db)


@router.delete("/{testcase_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_testcase(suite_id: int, testcase_id: int,
                          db: Session = Depends(get_db),
                          api_key: APIKey = Depends(get_user_api_key)):
    return testcase_crud.delete_testcase(suite_id, testcase_id, db)


@router.put("/{testcase_id}", status_code=status.HTTP_202_ACCEPTED,
            response_model=res_schemas.TestCase)
async def update_testcase(suite_id: int, testcase_id: int,
                          payload: req_schemas.TestCase,
                          db: Session = Depends(get_db),
                          api_key: APIKey = Depends(get_user_api_key)):
    return testcase_crud.update_testcase(suite_id, testcase_id, payload,
                                         db)
