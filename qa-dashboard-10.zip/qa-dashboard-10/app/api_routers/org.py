
from fastapi import APIRouter, Depends, status
from fastapi.openapi.models import APIKey
from sqlalchemy.orm import Session
from app.api_crud import org_crud
from app.db.db_connection import get_db
from app.api_routers.apikey_auth import get_admin_api_key, get_user_api_key
from app.schemas import req_schemas


router = APIRouter(
    prefix="/orgs",
    tags=["Org"],
    include_in_schema=True
)


@router.post("/", status_code=status.HTTP_201_CREATED, include_in_schema=True)
async def create_org(payload: req_schemas.Org, db: Session = Depends(get_db),
                     api_key: APIKey = Depends(get_admin_api_key)):
    return org_crud.create_org(payload, db)


@router.get("/")
async def read_orgs(db: Session = Depends(get_db),
                    api_key: APIKey = Depends(get_user_api_key)):
    return org_crud.get_orgs(db)


@router.get("/{org_id}")
async def read_org(org_id: int, db: Session = Depends(get_db),
                   api_key: APIKey = Depends(get_user_api_key)):
    return org_crud.get_org_by_id(org_id, db)


@router.get("/name/{org_name}")
async def read_org_by_name(org_name: str, db: Session = Depends(get_db),
                           api_key: APIKey = Depends(get_user_api_key)):
    return org_crud.get_org_by_name(org_name, db)


@router.delete("/{org_id}", status_code=status.HTTP_204_NO_CONTENT,
               include_in_schema=True)
async def delete_org(org_id: int, db: Session = Depends(get_db),
                     api_key: APIKey = Depends(get_admin_api_key)):
    return org_crud.delete_org(org_id, db)


@router.put("/{org_id}", status_code=status.HTTP_202_ACCEPTED,
            include_in_schema=True)
async def update_org(org_id: int, payload: req_schemas.Org,
                     db: Session = Depends(get_db),
                     api_key: APIKey = Depends(get_admin_api_key)):
    return org_crud.update_org(org_id, payload, db)
