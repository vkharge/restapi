from typing import List, Optional
from pydantic import BaseModel
from pydantic.validators import datetime
from app.db.models import StatusType, TCStatusType


class Mapping(BaseModel):
    id: int
    org: str
    product: str
    sub_product: str


class Suite(BaseModel):
    id: int
    org: str
    product: str
    sub_product: str
    environment: str
    test_type: str
    release: str
    branch: str
    suite: str
    build: int
    total: int
    passed: int
    failed: int
    skipped: int
    status: StatusType
    report_url: Optional[str]
    console_url: Optional[str]
    log_url: Optional[str]
    duration: Optional[float]
    infra: Optional[str]
    created: datetime


class TestCase(BaseModel):
    id: int
    testno: int
    testclass: Optional[str]
    testname: str
    status: TCStatusType
    duration: Optional[float]
    message: Optional[str]

    class Config():
        orm_mode = True


class TestCases(BaseModel):
    count: int
    testcases: List[TestCase]
