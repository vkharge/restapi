from fastapi import APIRouter, Request, Depends, Form
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.common.data import *
from app.db.db_connection import get_db
from app.ui_crud.common import get_ops_by_name
from app.ui_crud.testcases_crud import \
    get_testcases_search_filter_vals_by_id, \
    get_testcases_history


router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")


@router.get('/testcases')
async def testcases_page(request: Request, db: Session = Depends(get_db)):

    org, product, sub_product = get_ops_by_name(DEFAULT_ORG, DEFAULT_PRODUCT,
                                                DEFAULT_SUB_PRODUCT, db)

    orgs, products, sub_products, suites =\
        get_testcases_search_filter_vals_by_id(
            org.id, product.id, sub_product.id, db)

    return templates.TemplateResponse("testcases_page.html", {
        "request": request,
        "page_title": f"{PAGE_TITLE} - TestCases History",
        "page_header": PAGE_HEADER,
        "default_org": DEFAULT_ORG,
        "default_product": DEFAULT_PRODUCT,
        "default_sub_product": DEFAULT_SUB_PRODUCT,
        "orgs": orgs,
        "products": products,
        "sub_products": sub_products,
        "suites": suites,
        }
    )


@router.post('/get_testcases_history')
async def get_testcase_history(request: Request, org_id: int = Form(...),
                               product_id: int = Form(...),
                               sub_product_id: int = Form(...),
                               suite: str = Form(...),
                               db: Session = Depends(get_db)):

    header, testcases = get_testcases_history(org_id, product_id,
                                              sub_product_id, suite, db)

    return templates.TemplateResponse(
        "components/testcases_history_table.html", {
            "request": request,
            "header": header,
            "testcases": testcases,
        }
    )
