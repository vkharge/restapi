from fastapi import APIRouter, Request, Depends, Form
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.common.data import *
from app.db.db_connection import get_db
from app.ui_crud.common import get_ops_by_name, get_dates
from app.ui_crud.suites_crud import get_search_filter_vals_by_id, \
    get_suite_execution, get_suite_testcase_execution_by_suite_id, \
    get_testclass_wise_report_by_suite_id, \
    get_testcase_execution_for_suite_by_test_class

router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")


@router.get('/suites')
async def suites_page(request: Request, db: Session = Depends(get_db)):
    org, product, sub_product = get_ops_by_name(DEFAULT_ORG, DEFAULT_PRODUCT,
                                                DEFAULT_SUB_PRODUCT, db)

    orgs, products, sub_products, releases, builds, envs, test_types = \
        get_search_filter_vals_by_id(org.id, product.id, sub_product.id, db)

    start_date, end_date = get_dates()

    # Seach with Release/Build and Start Date and End Date
    header, body = get_suite_execution(org.id, product.id, sub_product.id,
                                       DEFAULT_RELEASE, DEFAULT_BUILD,
                                       DEFAULT_ENV, DEFAULT_TEST_TYPE,
                                       start_date, end_date, db)

    return templates.TemplateResponse("suites_page.html", {
        "request": request,
        "page_title": f"{PAGE_TITLE} - Suites",
        "page_header": PAGE_HEADER,
        "default_org": DEFAULT_ORG,
        "default_product": DEFAULT_PRODUCT,
        "default_sub_product": DEFAULT_SUB_PRODUCT,
        "default_release": DEFAULT_RELEASE,
        "default_env": DEFAULT_ENV,
        "default_build": DEFAULT_BUILD,
        "default_test_type": DEFAULT_TEST_TYPE,
        "orgs": orgs,
        "products": products,
        "sub_products": sub_products,
        "releases": releases,
        "builds": builds,
        "environments": envs,
        "test_types": test_types,
        "start_date": start_date,
        "end_date": end_date,
        "table_header": header,
        "table_body": body
    }
    )


@router.post('/get_suite_execution')
async def get_suite_execution_results(
        request: Request, org_id: int = Form(...), product_id: int = Form(...),
        sub_product_id: int = Form(...), release_name: str = Form(...),
        build: str = Form(...), environment_name: str = Form(...),
        test_type_name: str = Form(...), start_date: str = Form(...),
        end_date: str = Form(...), db: Session = Depends(get_db)):

    header, body = get_suite_execution(org_id, product_id, sub_product_id,
                                       release_name, build, environment_name,
                                       test_type_name, start_date, end_date,
                                       db)

    return templates.TemplateResponse(
        "components/suite_execution_table.html", {
            "request": request,
            "table_header": header,
            "table_body": body
        })


@router.get('/get_testcase_execution')
async def get_testcase_execution_results(request: Request, suite_id: int,
                                         db: Session = Depends(get_db)):
    suite_header, suite_body, testcase_header, testcase_body = \
        get_suite_testcase_execution_by_suite_id(suite_id, db)

    report_header, report_body = \
        get_testclass_wise_report_by_suite_id(suite_id, db)

    return templates.TemplateResponse("testcase_page.html", {
        "request": request,
        "page_title": f"{PAGE_TITLE} - TestCases",
        "page_header": PAGE_HEADER,
        "suite_id": suite_id,
        "suite_body": suite_body,
        "report_header": report_header,
        "report_body": report_body,
        "testcase_header": testcase_header,
        "testcase_body": testcase_body,
    })


@router.get('/get_testclass_testcase_execution')
async def get_testclass_testcase_execution_results(
        request: Request, suite_id: int, test_class: str,
        db: Session = Depends(get_db)):

    testcase_header, testcase_body = \
        get_testcase_execution_for_suite_by_test_class(suite_id, test_class,
                                                       db)

    return templates.TemplateResponse("testclass_testcase_page.html", {
        "request": request,
        "page_title": f"{PAGE_TITLE} - {test_class} - TestCases",
        "page_header": PAGE_HEADER,
        "suite_id": suite_id,
        "testcase_header": testcase_header,
        "testcase_body": testcase_body,
    })


@router.get('/update_qtest')
async def get_update_qtest(request: Request, suite_id: int,
                           db: Session = Depends(get_db)):
    suite_header, suite_body, testcase_header, testcase_body = \
        get_suite_testcase_execution_by_suite_id(suite_id, db)

    return templates.TemplateResponse("update_qtest_page.html", {
        "request": request,
        "page_title": f"{PAGE_TITLE} - Update qTest",
        "page_header": PAGE_HEADER,
        "suite_body": suite_body,
        "testcase_header": testcase_header,
        "testcase_body": testcase_body
    })
