from fastapi import APIRouter, Request, Depends, Form
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.common.data import *
from app.db.db_connection import get_db


router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")


@router.get('/contacts')
async def contact_page(request: Request, db: Session = Depends(get_db)):

    return templates.TemplateResponse("contact_page.html", {
        "request": request,
        "page_title": f"{PAGE_TITLE} - Contact Us",
        "page_header": PAGE_HEADER
    })


@router.post('/send_email')
async def send_email(request: Request, name: str = Form(...),
                     email: str = Form(...), subject: str = Form(...),
                     message: str = Form(...), db: Session = Depends(get_db)):

    # Send Email
    return True
