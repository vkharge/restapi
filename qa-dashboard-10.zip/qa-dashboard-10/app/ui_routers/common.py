from fastapi import APIRouter, Request, Depends, Form
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.db.db_connection import get_db
from app.ui_crud.common import get_products_for_given_org_id, \
    get_sub_products_for_given_product_id, get_releases_for_ops, \
    get_builds_for_ops
from app.ui_crud.testcases_crud import get_executed_suites_name


router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")


@router.post('/get_products_for_given_org_id')
async def get_filters_products_for_given_org_id(
        request: Request, org_id: int = Form(...),
        db: Session = Depends(get_db)):
    return get_products_for_given_org_id(org_id, db)


@router.post('/get_sproducts_for_given_prod_id')
async def get_filters_sub_products_for_given_prod_id(
        request: Request, org_id: int = Form(...),
        product_id: int = Form(...),
        db: Session = Depends(get_db)):
    return get_sub_products_for_given_product_id(org_id, product_id, db)


@router.post('/get_suites_for_given_sprod_id')
async def get_filters_suites_for_given_sprod_id(
        request: Request, org_id: int = Form(...),
        product_id: int = Form(...), sub_product_id: int = Form(...),
        db: Session = Depends(get_db)):
    return get_executed_suites_name(org_id, product_id, sub_product_id, db)


@router.post('/get_releases_for_given_ops')
async def get_filters_releases_for_given_ops(
        request: Request, org_id: int = Form(...),
        product_id: int = Form(...), sub_product_id: int = Form(...),
        db: Session = Depends(get_db)):
    return get_releases_for_ops(org_id, product_id, sub_product_id, db)


@router.post('/get_builds_for_given_ops')
async def get_filters_builds_for_given_ops(
        request: Request, org_id: int = Form(...),
        product_id: int = Form(...), sub_product_id: int = Form(...),
        release_name: str = Form(...), db: Session = Depends(get_db)):
    return get_builds_for_ops(org_id, product_id, sub_product_id,
                              release_name, db)
