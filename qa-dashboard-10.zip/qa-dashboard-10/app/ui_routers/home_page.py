from fastapi import APIRouter, Request, Depends
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.common.data import *
from app.db.db_connection import get_db
from app.ui_crud.home_crud import get_all_suites_history


router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")


@router.get('/')
async def home_page(request: Request, db: Session = Depends(get_db)):

    data = get_all_suites_history(db)

    return templates.TemplateResponse("home_page.html", {
        "request": request,
        "page_title": f"{PAGE_TITLE} - Home",
        "page_header": PAGE_HEADER,
        "table_body": data
    })
