from fastapi import APIRouter, Request, Depends, Form
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from starlette import status

from app.common.data import AP3_TOKEN
from app.db.db_connection import get_db
from app.common.tms import TMS
from app.schemas.req_schemas import QTestLog, QTestTestUpload
from app.ui_crud.qtest_crud import get_qtest_login, get_qtest_project, \
    get_qtest_tree_structure, get_qtest_testcases_data, \
    update_qtest_test_log_status, create_qtest_objects, upload_tests_in_qtest
from app.ui_crud.suites_crud import get_suite_execution_by_id


router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory="app/templates")


@router.get('/get_qtest_folders')
async def get_qtest_folders(request: Request, suite_id, project_id,
                            node_id, node_type,
                            db: Session = Depends(get_db)):

    tms = TMS()
    suite = get_suite_execution_by_id(suite_id, db)
    token, project_name = get_qtest_login(suite["product"],
                                          suite["subproduct"])

    if node_id == "#":
        selected = "true"
        opened = "true"

        project = get_qtest_project(tms, token, project_name)

        entities = get_qtest_tree_structure(tms, token, project["id"],
                                            project["type"])

        return templates.TemplateResponse("components/qtest_tree.html", {
            "request": request,
            "root": project,
            "entities": entities,
            "opened": opened,
            "selected": selected
        })
    else:
        entities = get_qtest_tree_structure(tms, token, project_id,
                                            node_type, node_id)

        return templates.TemplateResponse("components/qtest_child_tree.html", {
            "request": request,
            "entities": entities
        })


@router.get('/get_qtest_testcases')
async def get_qtest_testcases(request: Request, suite_id, project_id,
                              node_id, node_type,
                              db: Session = Depends(get_db)):

    tms = TMS()
    suite = get_suite_execution_by_id(int(suite_id), db)
    token, project_name = get_qtest_login(suite["product"],
                                          suite["subproduct"])

    entities = get_qtest_testcases_data(tms, token, project_id, node_type,
                                        node_id)

    return entities


@router.post('/update_qtest_test_status', status_code=status.HTTP_201_CREATED)
async def update_qtest_test_status(request: Request,
                                   testlog: QTestLog, db: Session =
                                   Depends(get_db)):

    tms = TMS()
    suite = get_suite_execution_by_id(testlog.suite_id, db)
    token, project_name = get_qtest_login(suite["product"],
                                          suite["subproduct"])

    success = update_qtest_test_log_status(tms, token, testlog.project_id,
                                           testlog.tests)

    return {"count": success}


@router.post('/upload_qtest_test', status_code=status.HTTP_201_CREATED)
async def upload_qtest_test(request: Request,
                            results: QTestTestUpload, db: Session =
                            Depends(get_db)):

    tms = TMS()
    suite = get_suite_execution_by_id(results.suite_id, db)
    token, project_name = get_qtest_login(suite["product"],
                                          suite["subproduct"])

    success = upload_tests_in_qtest(tms, token, suite, results)

    return {"count": success}


@router.post('/create_qtest_entity')
async def create_qtest_entity(request: Request, entity_type: str = Form(...),
                              entity_name: str = Form(...),
                              project_id: int = Form(...),
                              node_id: int = Form(...),
                              node_type: str = Form(...),
                              db: Session = Depends(get_db)):

    tms = TMS()
    token = AP3_TOKEN
    status = create_qtest_objects(tms, token, entity_type, entity_name,
                                  project_id, node_id, node_type, db)

    return {"status": status}
