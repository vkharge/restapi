from jose import jwt
from passlib.context import CryptContext

USER_SECRET_KEY = \
    "6aa20bf27fec0f66cd29292c993ea5bd3c7e2674a99b61b3a9474221bc7f8a94"
ADMIN_SECRET_KEY = \
    "cbc4deda00c859382277c82e4ee74e8b0f18b3b622804f52c22eb1acc84df3be"
ALGORITHM = "HS256"
user = {"sub": "readonlyuser"}
admin = {"sub": "adminuseraccess"}

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
hashed_password = pwd_context.hash(user["sub"])
encoded_jwt = jwt.encode(user, USER_SECRET_KEY, algorithm=ALGORITHM)

print(hashed_password)
print(encoded_jwt)

hashed_password = pwd_context.hash(admin["sub"])
encoded_jwt = jwt.encode(admin, ADMIN_SECRET_KEY, algorithm=ALGORITHM)

print(hashed_password)
print(encoded_jwt)
