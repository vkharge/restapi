
PAGE_TITLE = "QA Dashboard"
PAGE_HEADER = "QA Dashboard"
DEFAULT_ORG = "DOLBY.IO"
DEFAULT_PRODUCT = "ALL"
DEFAULT_SUB_PRODUCT = "ALL"

# SET RELEASE/BUILD/ENV/TEST_TYPE to ALL
DEFAULT_RELEASE = "ALL"
DEFAULT_BUILD = "ALL"
DEFAULT_ENV = "ALL"
DEFAULT_TEST_TYPE = "ALL"

DEFAULT_SEARCH_DAYS = 30
DEFAULT_SEARCH_DATE_FMT = '%Y-%m-%dT%H:%M:%S'

DEFAULT_LIMIT = 6

SUITE_HEADER = ["Id", "Date", "Org", "Product", "SubProduct", "Suite",
                "Status", "Total", "Passed", "Failed", "Skipped",
                "Environment", "Type", "Logs", "Duration"]

TESTCASE_HEADER = ["TestNo", "TestName", "Status", "Duration", "Message"]


AP3_TOKEN = "ZG9sYnl8VmlzaGFsLktoYXJnZUBkb2xieS5jb206MTY2NTEwMDg4NjU1MTo" \
            "4OWVlZjY2M2UxOTA3NWYxMDU5NWM1ODc0MWNlYmViNA"

MAPI_TOKEN = \
    "ZG9sYnl8RGVubmlzLk90dGVyQGRvbGJ5LmNvbToxNjUzMTA2NjUxMjM1OjdjNGVhMzY2Y" \
    "zg2YjJhM2ViOWU2ZjY1MmM3YzhkODdj"

CAPTURE_SDK_TOKEN = \
    "ZG9sYnl8VmlzaGFsLktoYXJnZUBkb2xieS5jb206MTY3MDU1MjI1MDQzOTplYTUxNDFlNm" \
    "RhYjhiNWJhNzBhNDI0ZDk3MTM0OTE2NA"

MAPI_CLOUD_SERVICES = \
    "ZG9sYnl8VmlzaGFsLktoYXJnZUBkb2xieS5jb206MTY3NDA4NzE3NDY1NjpiM2M3OGU4Nm" \
    "MzZTg4MjVjZGNkY2RlYTFjOTY5NmJiOA"

QTEST_PROJECTS = {
    "DOLBYON": {
        "name": "AP3",
        "token": AP3_TOKEN
    },
    "MAPI-CAPTURE-SDK": {
        "name": "Media API SDKs",
        "token": CAPTURE_SDK_TOKEN
    },
    "MAPI": {
        "name": "Cloud Media API (MAPI)",
        "token": MAPI_TOKEN
    },
    "PLATFORM": {
        "name": "Cloud Services",
        "token": MAPI_CLOUD_SERVICES
    },
    "HYBRIK": {
        "name": "Cloud Services",
        "token": MAPI_CLOUD_SERVICES
    }
}
