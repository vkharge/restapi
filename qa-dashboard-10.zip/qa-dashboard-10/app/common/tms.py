"""
    This module will grow as a generic module for TMS interaction
    qtest is the focus at this point

    :author: Dany Rocheleau
    :contact: ddroch@dolby.com
    :copyright: Copyright 2016 Dolby Laboratories inc.
    :license: Dolby

"""

import requests
import json
import collections
import base64
import argparse
import logging
import pytz
from datetime import datetime

try:
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    from requests.packages.urllib3.exceptions import InsecurePlatformWarning
    from requests.packages.urllib3.exceptions import SNIMissingWarning

    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    requests.packages.urllib3.disable_warnings(InsecurePlatformWarning)
    requests.packages.urllib3.disable_warnings(SNIMissingWarning)
    logging.getLogger("requests").setLevel(logging.WARNING)
except ImportError:
    requests.packages.urllib3.disable_warnings()

from datetime import *
import time
from gti_scutils.model import XU_PASS


class TMS:
    # to be externalized (yaml, xml whatever
    _url_new_login = "/oauth/token"
    _url_login = "api/login"
    _url_projects = "/api/v3/projects/"
    _url_3_1_projects = "/api/v3.1/projects/"
    _url_testcases = "/test-cases"
    _url_builds = "/builds"
    _url_releases = "/releases"
    _url_testsuites = "/test-suites"
    _url_testcycle = "/test-cycles"
    _url_testrun = "/test-runs"
    _url_testrun_execution_status = "/test-runs/execution-statuses"
    _url_modules = "/modules"
    _url_testlogs = "/test-logs"
    _url_requirements = "/requirements"
    _url_settings = "/settings"
    _url_testcase_fields = "/settings/test-cases/fields"
    _url_testrun_fields = "/settings/test-runs/fields"
    _url_testplans = ""
    _url_batch_upload = "/test-runs/0/auto-test-logs?type=automation"
    _url_custom_batch_upload = "/auto-test-logs?type=automation"
    _url_batch_poll = "/queue-processing/"
    _url_batch_upload_status = ""
    _url_header = {
        'Host': 'dolby.qtestnet.com',
        'Authorization': 'Bearer e6e98e11-4908-4f6a-84dd-7591a21be1d7',
        'Cache-Control': 'no-cache'
    }

    _headers = {
        'Host': 'dolby.qtestnet.com',
        'Cache-Control': 'no-cache',
    }

    _user_id = ""
    _password = ""
    _verify_mode = False
    _active_projectid = 0

    # to be externalized

    @property
    def lastparent_id(self):
        return self.__lastparent_id

    @lastparent_id.setter
    def lastparent_id(self, value):
        self.__lastparent_id = value

    @property
    def projects(self):
        return self.__projects

    @property
    def testcases(self):
        return self.__testcases

    # *******************************************************************
    def __init__(self):
        """
        Constructor
        """
        # print("init object")
        self._token = None
        self._json_test_cases = None
        self._json_test_runs = None
        self.__testcases = []
        self.__test_runs = []
        self.__test_logs = []
        self.__testsuites = []
        self.__release = []
        self.__requirements = []
        self.__projects = []
        self.__builds = []
        self.__buildcycles = []
        self.__platforms = []
        self.__modules = []
        self.__field_map = None
        self.__debug = False
        self.__module_root_id = 0
        self.__lastparent_id = 0
        self.__batch_testrun_array = []
        self.__fileindex = 0
        self.__platform_field = 0
        self.__platform_value = 0
        self.__config_field = 0
        self.__config_value = 0
        self.__TLREF = 0
        self.__mapping_field_value = 0
        self.__mapping_field_name = ""
        self.___auto_content = 0
        self.__testcase_prefix = ""
        self.__test_run_fields = []
        self._server_url = "https://dolby.qtestnet.com/"
        self.__context = None
        # *******************************************************************

    @property
    def server_url(self):
        return self._server_url

    @property
    def debug(self):
        return self.__debug

    @debug.setter
    def debug(self, value):
        self.__debug = value
        if value is True:
            print(">>>>>>>>>>>>>>>>>>>>>>> DEBUG <<<<<<<<<<<<<<<<<<<")

    # marked for clean up
    @property
    def tl_ref(self):
        return self.__TLREF

    @tl_ref.setter
    def tl_ref(self, value):
        self.__TLREF = value

    @property
    def testcase_prefix(self):
        return self.__testcase_prefix

    @testcase_prefix.setter
    def testcase_prefix(self, value):
        self.__testcase_prefix = value

    @property
    def mapping_field_value(self):
        return self.__mapping_field_value

    @mapping_field_value.setter
    def mapping_field_value(self, value):
        self.__mapping_field_value = value

    @property
    def mapping_field_name(self):
        return self.__mapping_field_name

    @mapping_field_name.setter
    def mapping_field_name(self, value):
        self.__mapping_field_name = value

    @property
    def auto_content(self):
        return self.___auto_content

    @auto_content.setter
    def auto_content(self, value):
        self.___auto_content = value

    @property
    def context(self):
        return self.__context

    @context.setter
    def context(self, value):
        self.__context = value

    def _auth(self, token):

        """
        :param token:
        :return: formatted header for authorization token to be passed
        """
        auth_header = {
            'Authorization': token
        }

        return auth_header

    # *******************************************************************

    def _post(self, token):

        """
        :param token: auth token obtained at login time
        :return: formatted json data to create/update a record

        post_headers = {'Host': 'dolby.qtestnet.com',
                        'Content-Type': 'application/x-www-form-urlencoded'
                        'application/json',
                        'Cache-Control': 'no-cache',
                        'Authorization': token
                        }
        """
        if self._token is None:
            self._token = token

        post_headers = {'Host': 'dolby.qtestnet.com',
                        'Content-Type': 'application/json',
                        'Cache-Control': 'no-cache',
                        'Authorization': self._token}

        return post_headers

    # *******************************************************************
    def tms_post(self, resturl, data, pid, token):
        """
        :param resturl: URL to service
        :param data: formatted data for the data creatopm/update
        :param pid: current project
        :param token: if token is missing, it is passed in parameter
        :return:
        """

        if self._token is None:
            self._token = token

        if pid is None:
            url = self._url_projects + resturl
        else:
            url = self._url_projects + str(pid) + resturl
        print(self._server_url + url)
        response = requests.post(self._server_url + url, data=json.dumps(data),
                                 headers=self._post(self._token),
                                 verify=False)

        jsonobj = None
        if response is not None and response.status_code not in \
                list(range(400, 599, 1)):
            jsonobj = response.json()
        else:
            print(response.content)
            print(str(response.status_code))

        return jsonobj

    # *******************************************************************
    def tms_get(self, resturl, pid):
        """
        Encapsulate the REST mechanics and return json to calling methods.
        Intended to be an internal re-use plumbing function for the REST GETs
        :param resturl:
        :param pid:
        :return:
        """
        if self.__debug:
            print("TMS.tms_get")

        if pid is not None:
            url = self._url_projects + str(pid) + resturl
        else:
            url = self._url_projects[:-1] + resturl

        print(self._server_url + url)
        response = requests.get(self._server_url + url,
                                headers=self._auth(self._token),
                                verify=self._verify_mode)
        jsonobj = None
        if response is not None and response.status_code not in \
                list(range(400, 599, 1)):
            jsonobj = response.json()

        return jsonobj

    def tms_delete(self, resturl, pid):
        """

        """
        if self.__debug:
            print("TMS.tms_delete")

        if pid is not None:
            url = self._url_projects + str(pid) + resturl
        else:
            url = self._url_projects[:-1] + resturl

        url = self._server_url + url + "?force=true"

        response = requests.delete(url, headers=self._post(self._token))
        jsonobj = None

        if response is not None and response.status_code not in \
                list(range(400, 599, 1)):
            if response.content:
                jsonobj = response.json()

        return jsonobj

    # *******************************************************************
    def get_field_value(self, pid, url, lookup_field):

        key = url[1:]
        fields = {}
        if self.__field_map and key in self.__field_map:
            fields = self.__field_map[key]
        else:
            fields = self.get_fields(pid, key, url)

        for f in fields:
            if f['label'] == lookup_field:
                return f

        return None

    # *******************************************************************
    def get_fields(self, pid, key, url):

        url = self._url_settings + url + "/fields"
        response = self.tms_get(url, pid)

        for f in response:
            t = {}
            t[f['label']] = {'id': f['id']}
            if 'allowed_values' in list(f.keys()):
                t[f['label']]['allowed_value'] = f['allowed_values']

            self.__field_map[key].update(t)

    # ********************************************************************
    def get_mapping(self, pid, field_label):
        if self.__debug:
            print("TMS.getTestRunFields")

        url = self._url_testcase_fields
        response = self.tms_get(url, pid)

        if response is None:
            print("Getting testcase fields failed")
            quit()
        else:
            result = {}
            for r in response:
                if r['label'] == field_label:
                    return r['id']

        print(
            "Mapping field name cannot be found. Please verify the field"
            " name is defined for your project")
        quit()

    def get_mapping_value(self, pid, tc, label, attribute):

        field_id = getattr(self, attribute)

        if field_id == 0 or field_id is None:
            field_id = self.get_mapping(pid, label)
            setattr(self, attribute, field_id)

        for p in tc['properties']:
            if p['field_id'] == field_id:
                if "field_value" in p.keys():
                    return p['field_value']
                else:
                    break

        return "not set"

    # *******************************************************************
    def load_field_maps(self, q_project):
        """
        NOT USED - went laze loading since we don't need
        the fields for items and only on-demand.
        not like full on migration
        FROM MIKE. Saved me time.
        every qTest project has different field id's for various things.
        we need to load this map "on the fly" for every project
        so we put data into the correct
        field id.

        flattens the json so that we have a key:value dict
        in a class instance variable.
        :param q_project:
        :return:
        """
        self.__field_map = {}
        for m in ['releases', 'builds', 'requirements', 'test-cases',
                  'test-suites', 'test-runs', 'defects']:
            self.__field_map[m] = {}
            j = self.tms_get(resturl="/settings/" + m + "/fields",
                             pid=q_project)

            for f in j:
                t = {}
                pass
                t[f['label']] = {'id': f['id']}
                if 'allowed_values' in list(f.keys()):
                    t[f['label']]['allowed_value'] = f['allowed_values']

                self.__field_map[m].update(t)

        return True

    # *******************************************************************
    def search_item_by_query(self, pid, object_type, query_text,
                             field_list=["*"]):
        """ This method search for an object based on the query string passed
            to the method.

            :param: pid is the project id on which to perform the search
            :param: object_type is the the type of object the search will
                    be looking for. Valid values are
                    test-runs, test-cases, requirements and defects
            :param: query_text is the complete query having field(s) and
                    value(s) to perform the search
            :param: field_list is optional and is used to return just the
                    fields needed but the caller by default, all fields are
                     returned
        """

        url = "/search?pageSize=25"

        otype = object_type
        fields = ["*"]

        querydata = {"object_type": object_type,
                     "fields": fields,
                     "query": query_text}

        try:
            response = self.tms_post(url, querydata, str(pid), self._token)

            if response['total'] > 0:
                return response['items'][0]
            else:
                return None
        except requests.exceptions.RequestException as e:
            return None

    # *******************************************************************
    def login(self, server_url, user_id, password, debug=False):
        """
        """

        self.debug = debug
        if self.debug is True:
            print("TMS.login!")

        self._server_url = server_url
        self._user_id = user_id
        self._password = password

        login_params = {
            'j_username': user_id,
            'j_password': password
        }

        # response = requests.post(self._server_url + self._url_login,
        # data=json.dumps(login_params), headers=self._post(self._token),
        #                         verify=False)

        response = requests.post(self._server_url + self._url_login,
                                 data=login_params, headers=self._url_header,
                                 verify=False)

        self._token = response.content

        if response is not None and response.status_code not in \
                list(range(400, 599, 1)):
            return self._token
        else:
            print("Login Failed")
            print(response.content)
            quit()

    # *******************************************************************
    def new_login(self, server_url, user_id, password):

        self._server_url = server_url
        self._user_id = "ddroch@dolby.com"
        self._password = "NoGutsNoGl0ry"

        login_params = {
            'grant_type': 'password',
            'username': 'ddroch@dolby.com'
        }

        # response = requests.post(self._server_url + self._url_new_login,
        # data=json.dumps(login_params), headers=self._post(
        # "Bearer e6e98e11-4908-4f6a-84dd-7591a21be1d7"), verify=False)

        response = requests.post(self._server_url + self._url_new_login,
                                 headers=self._url_header,
                                 verify=False)

        self._token = response.content

        if response is not None and response.status_code not in \
                list(range(400, 599, 1)):
            return self._token
        else:
            print("Login Failed")
            print(response.content)
            quit()

    # *******************************************************************

    def get_test_case_fields(self, token, pid):

        if self.__debug:
            print("TMS.getTestCaseFields")
        if self._token is None:
            self._token = token

        url = self._url_testcase_fields
        response = self.tms_get(url, pid)

        if response is None:
            print("Getting TestCase Fields failed")
            quit()

        fields = response
        return fields

    # *******************************************************************
    def get_test_run_fields(self, token, pid, field_label, value_label,
                            field_only=False):
        if self.__debug:
            print("TMS.getTestRunFields")
        if self._token is None:
            self._token = token

        url = self._url_testrun_fields
        response = self.tms_get(url, pid)

        if response is None:
            print(
                "Getting test-run fields failed, this is most likely due"
                " to your user not having enough rights")
            print(response)
            quit()
        else:
            result = {}
            for r in response:
                if r['label'] == field_label:
                    result['id'] = r['id']
                    if field_only:
                        return result
                    for value in r['allowed_values']:
                        if value['label'].strip() == value_label:
                            result['value'] = value['value']
                            return result

        print(" \n Error: Could not find the value %(value)s in "
              "%(platforms)s list. Please refer to the documentation and "
              "add the proper value before running again."
              % {'platforms': field_label, 'value': value_label})
        quit()
        return None

    # *******************************************************************
    def load_test_runs_build_field(self, token, pid, ):

        if self.__debug:
            print("TMS.load_test_runs_fields")
        if self._token is None:
            self._token = token

        if self.__test_run_fields is None or self.is_empty(
                self.__test_run_fields):
            url = self._url_testrun_fields
            response = self.tms_get(url, pid)
            last_release = TMSTest_run_release_build_info()
            for r in response:
                if r['label'] == "Target Release/Build":
                    for val in r['allowed_values']:
                        test_run_target_build = \
                            TMSTest_run_release_build_info()
                        test_run_target_build.field_id = r['id']
                        test_run_target_build.name = val['label'].strip()
                        test_run_target_build.value_id = val['value']
                        if val['label'][:1] == " ":
                            test_run_target_build.type = "Build"
                        else:
                            test_run_target_build.type = "Release"

                        if test_run_target_build.type != "Release":
                            test_run_target_build.parent = \
                                last_release.value_id
                            test_run_target_build.parent_name = \
                                last_release.name

                        if test_run_target_build.type == "Release":
                            last_release = test_run_target_build

                        self.__test_run_fields.append(test_run_target_build)

        return self.__test_run_fields

    def get_test_cases(self, token, pid, mapping_field_name="",
                       parent_id=None):
        if self.lastparent_id == parent_id:
            return self.__testcases

        self.lastparent_id == parent_id

        if self.__debug:
            print("TMS.getTestCases")
        if self._token is None:
            self._token = token

        start_url = self._url_testcases
        if parent_id is None:
            start_url = start_url + "?size=100&expandProps=true"
        else:
            start_url = start_url + "?parentId=" + str(
                parent_id) + " &size=100&expandProps=true"

        print("Loading Testcases for mapping >> " + str(datetime.now().time()))
        response = self.tms_get(start_url, pid)
        tcases = response

        pagecnt = 1
        # to avoid a API call if we do not have 100 records
        stop = False
        self.mapping_field_name = mapping_field_name
        while len(tcases) > 0 and not stop:
            try:
                for tc in tcases:
                    if self.testcase_prefix == "":
                        temp = tc['pid'].split("-")
                        self.testcase_prefix = temp[0]

                    test_case = TMSTestCase()
                    test_case.id = tc['id']
                    test_case.pid = tc['pid']
                    test_case.name = tc['name']
                    test_case.parent_id = tc['parent_id']
                    if mapping_field_name is not "":
                        test_case.mapping_field_value = self.get_mapping_value(
                            pid, tc, mapping_field_name,
                            "mapping_field_value")
                    else:
                        test_case.mapping_field_value = tc["pid"]

                    test_case.automation_content = \
                        self.get_mapping_value(pid, tc, "Automation Content",
                                               "auto_content")
                    # testcase.generated_path =
                    self.__testcases.append(test_case)
            except Exception as ex:
                print(ex)

            if len(tcases) >= 100:
                pagecnt += 1
                url = start_url + "&page="
                url += str(pagecnt)
                response = self.tms_get(url, pid)
                tcases = response
                if tcases is None:
                    break
            else:
                stop = True

        print("Loading Testcases Completed! >> " + str(datetime.now().time()))
        # print [tcase.name for tcase in self.__test_cases],
        # for elem in self.__testcases:
        #    print elem.name + " " + str(elem.parent_id)

        return self.__testcases

    # *******************************************************************

    def get_test_plan(self):
        # No API - need mapping ?? need to understand the concept
        print("TMS.getTestPlan")
        pass

    # *******************************************************************

    def get_test_cases_for_test_plan(self):
        # wait for now
        print("TMS.getTestCasesForTestPlan")

    # *******************************************************************

    def get_test_case_id_by_name(self, token, pid, test_case_name, parent_id):
        if self.__debug:
            print("TMS.getTestCaseIDByName")
        if self._token is None:
            self._token = token

        tcs = self.get_test_cases(self._token, pid, parent_id)
        for tc in tcs:
            if tc['name'] == test_case_name:
                return tc

        # will looked up cached data when ready (in progress)

    # *******************************************************************

    def get_test_cases_by_id(self, token, pid, tc_id):
        if self.__debug:
            print("TMS.getTestCasesById")

        if self._token is None:
            self._token = token

        url = self._url_testcases + "/" + tc_id
        response = self.tms_get(url, pid)

        tc = response
        # will be a tc object soon in progress
        return tc

    # *******************************************************************

    def get_releases(self, token, pid):
        if self.__debug:
            print("TMS.getReleases")

        if self._token is None:
            self._token = token

        url = self._url_releases

        response = self.tms_get(url, pid)
        rels = response
        if rels:
            releases = []
            for r in rels:
                rel = TMSTestRelease()
                rel.id = r['id']
                rel.name = r['name']
                releases.append(rel)
                self.__release.append(rel)

            return releases
        return None

    # *******************************************************************
    def get_release_by_attribute(self, token, pid, field_name=None,
                                 field_value=None):
        if self.__debug:
            print("TMS.getReleases")

        if self._token is None:
            self._token = token

        url = self._url_releases

        if len(self.__release) == 0:
            releases = self.get_releases(token, pid)
        else:
            releases = self.__release

        if releases is None:
            return None

        if field_value:
            for rel in releases:
                if field_value == getattr(rel, field_name):
                    return rel

        return None

    # *******************************************************************
    def get_test_suites(self, token, pid, parent_id, parent_type):
        if self.__debug:
            print("TMS.getTestSuites")

        if self._token is None:
            self._token = token

        url = self._url_testsuites
        url = url + "?parentId=" + parent_id + "&parentType=" + parent_type

        response = self.tms_get(url, pid)
        test_suites = response
        # self.__testsuites = TMSTestSuite()

        # not needed for now
        suites = []
        for ts in test_suites:
            testsuite = TMSTestSuite()
            testsuite.name = ts['name']
            testsuite.id = ts['id']
            suites.append(testsuite)
            self.__testsuites.append(testsuite)

        return suites

    # *******************************************************************
    def get_requirements(self, token, pid):
        if self.__debug:
            print("TMS.get_requirements")

        if self._token is None:
            self._token = token

        url = self._url_requirements
        response = self.tms_get(url, pid)

        reqs = response
        for rec in reqs:
            new_rec = TMSRequirements()
            new_rec.id = rec['id']
            new_rec.pid = rec['pid']
            new_rec.name = rec['name']
            self.__requirements.append(new_rec)

        return self.__requirements

    # *******************************************************************

    def link_objects(self, token, pid, parent_type, parent_id, children_type,
                     children):
        if self.__debug:
            print("TMS.link_objects")

        if self._token is None:
            self._token = token

        url = "/" + parent_type + "/" + str(
            parent_id) + "/" + "link" + "?type=" + children_type
        response = self.tms_post(url, children, pid, token)

        return True

    # *******************************************************************

    def get_test_suite_by_id(self, token, pid, ts_id):
        """
        :param token: token if the object token is null
        :param pid: project id
        :param ts_id:  test suite id
        :return: test suite data (object soon)
        """
        if self.__debug:
            print("TMS.getTestSuiteByID")

        if self._token is None:
            self._token = token

        url = self._url_testsuites + "/" + ts_id

        response = self.tms_get(url, pid)

        self.__testsuites = response

        return response

    # ********************************************************************

    def get_test_suite_by_name(self, token, pid, test_suite_name, parent_id,
                               parent_type):
        """
        """
        if self.__debug:
            print("TMS.getTestSuiteByName")
        if self._token is None:
            self._token = token

        # if not self.__testsuites:
        #    testsuite = self.getTestSuites(token,pid,relid)
        #    print ">>>>>>>> TEST SUITE >>>>  " + str(testsuite)

        testsuite = self.get_test_suites(token, pid, parent_id, parent_type)

        for ts in testsuite:
            if ts['name'] == test_suite_name:
                return ts

    # *******************************************************************

    def get_projects(self, token):

        if self.__debug:
            print("TMS.getProjects")

        if self._token is None:
            self._token = token

        response = self.tms_get("", None)
        all_projects = response

        for p in all_projects:
            project = TMSProject()
            project.id = p['id']
            project.name = p['name']
            project.automation = p['automation']
            self.__projects.append(project)

        return response

    # *******************************************************************

    def get_project_by_name(self, token, project_name):

        if self.__debug:
            print("TMS.getProject by name")

        # get the project from cache (coming)
        # if self._active_projectname:

        if self._token is None:
            self._token = token

        if not self.__projects:
            self.get_projects(token)

        for p in self.__projects:
            if p.name == project_name:
                self._active_projectid = p.id
                # to be defined
                # self._active_projectname = p.name
                # self.load_field_maps(p)
                if p.automation is False:
                    print(
                        "This is project does not have automation turned on."
                        " Please, contact your qtest administrator")
                    quit(0)
                return p

        print("project> " + project_name + " not found")
        quit()

    # *******************************************************************
    def get_builds(self, token, pid, rel_id):
        if self.__debug:
            print("TMS.getBuilds")

        if self._token is None:
            self._token = token

        url = self._url_builds + "?releaseId=" + str(rel_id)

        response = self.tms_get(url, pid)
        b = response

        if not b:
            return None

        for item in b:
            build = TMSBuild()
            build.id = item['id']
            build.name = item['name']
            self.__builds.append(build)

        return self.__builds

    # *******************************************************************
    def get_build_cycles(self, token, pid, rel_id=None, parent_type=None):
        if self.__debug:
            print("TMS.getBuildCycles")

        if self._token is None:
            self._token = token

        if rel_id and parent_type:
            url = self._url_testcycle + "?parentId=" + str(
                rel_id) + "&parentType=" + parent_type
        else:
            url = self._url_testcycle + "?expand=descendants"

        response = self.tms_get(url, pid)

        b = response

        if not b or len(b) == 0:
            return None

        cycles = []
        for item in b:
            cycle = TMSBuildCycle()
            cycle.id = item['id']
            cycle.name = item['name']
            cycle.pid = item['pid']
            cycles.append(cycle)
            self.__buildcycles.append(cycle)

        return cycles

    # *******************************************************************
    def get_build_by_name(self, token, pid, build_name, rel_id):
        if self.__debug:
            print("TMS.getBuildByName")
        if self._token is None:
            self._token = token

        if not self.__builds:
            builds = self.get_builds(token, pid, rel_id)
        else:
            builds = self.__builds

        if not builds:
            return None

        for b in builds:
            if b.name == build_name:
                return b

        return None

    # *******************************************************************
    def get_build_cycle_by_name(self, token, pid, cycle_name, rel_id,
                                parent_type, force_load=False):
        if self.__debug:
            print("TMS.getBuilCycledByName")
        if self._token is None:
            self._token = token

        if not self.__buildcycles or force_load:
            cycles = self.get_build_cycles(token, pid, rel_id, parent_type)
        else:
            cycles = self.__buildcycles

        if not cycles:
            return None

        for c in cycles:
            if c.name == cycle_name:
                return c

        return None

    # *******************************************************************
    def get_modules(self, token, pid, parent_id=None):
        if self.__debug:
            print("TMS.getModules")

        def load_modules(modules):
            for item in modules:
                mod = TMSModule()
                mod.id = item['id']
                mod.name = item['name']
                mod.parent_id = item['parent_id']
                if 'children' in list(item.keys()):
                    load_modules(item['children'])
                self.__modules.append(mod)

        if self._token is None:
            self._token = token

        url = self._url_modules + "?"

        if parent_id is not None:
            url += "parentId=" + str(parent_id) + "&"

        url += "expand=descendants"

        response = self.tms_get(url, pid)

        m = response
        if m is None:
            return None

        load_modules(m)
        return self.__modules

    # *******************************************************************

    def get_test_runs(self, token, pid, parent_id=-1, parent_type="release"):
        if self.__debug:
            print("TMS.getTestRuns")
        if self._token is None:
            self._token = token

        url = self._url_testrun

        if parent_id is not None and parent_id > -1:
            url = url + "?parentId=" + str(parent_id) + \
                  "&parentType=" + parent_type + "&expand=descendants"
        else:
            url = url + "?expand=descendants"

        url = url + "&pageSize=999"
        response = self.tms_get(url, pid)

        if not response or len(response) == 0:
            return []

        test_runs = []
        for tr in response["items"]:
            testrun = TMSTestRun()
            testrun.id = tr['id']
            testrun.name = tr['name']

            for p in tr['properties']:
                if p["field_name"] == "Status":
                    testrun.status = p["field_value_name"]
                    break

            test_runs.append(testrun)

        return test_runs

    # *******************************************************************

    def get_test_logs(self, token, pid, test_run_id):
        if self.__debug:
            print("TMS.getTestLogs")
        if self._token is None:
            self._token = token

        url = self._url_testrun + "/" + str(test_run_id) + self._url_testlogs

        response = self.tms_get(url, pid)

        tlogs = response
        for tl in tlogs:
            testlog = TMSTestLog()
            testlog.status = tlogs['items'][0]['id']
            testlog.status = tlogs['items'][0]['status']['name']
            self.__test_logs.append(testlog)

        if self.__test_logs is None:
            return None

        return self.__test_logs

    # ------------------- CREATE REQUESTS -------------------
    def create_or_get_test_case_structure(self, token, pid, path):
        """
        :param token: to be able to test in case of a different instance
        :param pid: project id
        :param path: path (tree structure)
        :more to come
        """
        if self.__debug:
            print("TMS.create_or_get_test_case_structure")
        if self._token is None:
            self._token = token

        modules = path.split(".")
        parent_id = None
        cnt = 1
        for m in modules:
            new_module = self.get_module_by_name(token, pid, m, parent_id)
            if new_module is None:
                new_module = self.create_test_module(token, pid, m, parent_id)

            if cnt == 1:
                self.__module_root_id = new_module.id
            cnt += 1
            parent_id = new_module.id

        return parent_id

    # ******************************************************************

    def create_or_get_testcase(self, token, pid, test_case, parent_id):
        """
        :param token: to be able to test in case of a different instance
        :param pid: project id
        :param parent_id:
        :param test_case:
        """
        if self._token is None:
            self._token = token

        get_tcase = self.get_test_case_by_name(token, pid, test_case.name,
                                               parent_id)
        if get_tcase is None:
            tcase = self.create_test_case(token, pid, test_case, parent_id)
            if tcase is not None:
                parent_id = tcase.id
        else:
            parent_id = get_tcase.id

        return parent_id

    # ******************************************************************

    def create_or_get_testrun(self, token, pid, t_run_name, t_case_id,
                              parent_id, parent_type):
        if self.__debug:
            print("TMS.create_or_get_testrun")

        if self._token is None:
            self._token = token

        trun = self.get_test_run_by_name(token, pid, t_run_name, parent_id,
                                         parent_type)
        if trun is None:
            trun = self.create_test_run(token, pid, t_run_name, t_case_id,
                                        parent_id, parent_type)

        return trun.id

    # *******************************************************************
    def get_test_run_by_name(self, token, pid, t_run_name, parent_id,
                             parent_type):
        if self.__debug:
            print("TMS.getTestRunByName")
        if self._token is None:
            self._token = token

        if self.__test_runs is None or len(self.__test_runs) == 0:
            test_runs = self.get_test_runs(token, pid, parent_id, parent_type)
        else:
            test_runs = self.__test_runs

        if test_runs is None:
            return None

        for tr in test_runs:
            if tr.name == t_run_name:
                return tr

        return None

    # *******************************************************************

    def get_test_runs_by_name_and_release(self, pid, test_run_name, ac,
                                          release_name):
        if self.__debug:
            print("TMS.get_test_runs_by_name_and_release")

        test_run_to_update = self.search_item_by_query(
            pid, "test-runs", "'Test Case Automation Content' = '" + ac + "'")

        test_run_fields = self.__test_run_fields
        tr_info = None
        if test_run_to_update:
            if test_run_to_update['name'].strip() == test_run_name.strip():
                for field in test_run_fields:
                    for p in test_run_to_update["properties"]:
                        if p["field_name"] == "Target Release/Build":
                            tr_info = {"name": test_run_name,
                                       "id": test_run_to_update['id'],
                                       "field_id": p["field_id"],
                                       "field_value_id": p["field_value"],
                                       "field_text_value": p[
                                           "field_value_name"]}
                            break
                    break
        return tr_info

        if not any(self.__release):
            self.get_releases(token, pid)
        release_id = None

        for r in self.__release:
            if r.name == release_name:
                release_id = r.id

        if self.__test_runs is None or len(self.__test_runs) == 0:
            test_runs = self.get_test_runs(token, pid, release_id, "release")
        else:
            test_runs = self.__test_runs

        if test_runs is None:
            return None

        for tr in test_runs:
            if tr.name == test_run_name and \
                    tr.release_name.name == release_name:
                return tr

        return None

    def get_test_case_by_name(self, token, pid, t_case_name, parent_id):
        if self.__debug:
            print("TMS.getTestCaseByName")
        if self._token is None:
            self._token = token

        test_cases = self.__testcases

        if not test_cases:
            test_cases = self.get_test_cases(token, pid, parent_id)
        else:
            if test_cases[-1].parent_id != parent_id:
                test_cases = self.get_test_cases(token, pid, parent_id)

        # if test_cases is None:
        #    return None

        for tc in test_cases:
            if tc.name == t_case_name:
                return tc
        return None

    # *******************************************************************
    def get_module_by_name(self, token, pid, mname, parent_id):
        if self.__debug:
            print("TMS.getModuleByName")
        if self._token is None:
            self._token = token

        def lookup(module_name):
            for m in self.__modules:
                if m.name == module_name:
                    return m
            return None

        modules = self.__modules
        if not modules:
            modules = self.get_modules(token, pid, parent_id)

        mod = lookup(mname)
        if mod is None:
            modules = self.get_modules(token, pid, parent_id)
            return lookup(mname)
        else:
            return mod

        # return None

    # *******************************************************************

    def delete_module(self, token, pid):
        if not pid:
            # hard coded for testing purpose only
            pid = self.get_project_by_name(token, "GTI Scutils_Test").id

        modules = self.get_modules(token, pid)
        urlbase = self._url_modules
        if modules:
            for m in modules:
                url = urlbase + "/" + str(m.id)
                self.tms_delete(url, pid)
        return pid

    def delete_release(self, token, pid):
        if not pid:
            # hard coded for testing purpose only
            pid = self.get_project_by_name(token, "GTI_Scutils_Test").id

        releases = self.get_releases(token, pid)
        urlbase = self._url_releases
        if releases:
            for r in releases:
                url = urlbase + "/" + str(r.id)
                self.tms_delete(url, pid)

    # ******************************************************************
    # def createTestCase(self,token , pid, tcname, tcdesc,arg,parent_id=None)
    def create_test_case(self, token, pid, test_case, parent_id):
        if self.__debug:
            print("TMS.createTestCase")

        if self._token is None:
            self._token = token

        tc_data = {
            "name": test_case.name,
            "parent_id": parent_id
        }
        # if parent_id is not None:
        #    tc_data.update({"parent_id": str(parent_id)})

        url = self._url_testcases

        response = self.tms_post(url, tc_data, str(pid), self._token)

        new_test_case = TMSTestCase()
        if response is not None:
            temp = response
            new_test_case.id = temp['id']
            new_test_case.name = temp['name']
            new_test_case.parent_id = parent_id
            self.__testcases.append(new_test_case)
        else:
            print("Creating Test case has failed")
            quit()

        # approve it
        # url = self._url_projects + str(pid) + self._url_testcases +
        # "/" + str(new_test_case.id) + "/approve"
        url = f"{self._url_projects}{pid}{self._url_testcases}" \
              f"/{new_test_case.id}/approve"

        # not usef for now. Will need to revisit if needed
        approve = requests.put(self._server_url + url,
                               headers=self._post(self._token), verify=False)

        if response is not None and response.status_code not in \
                list(range(400, 599, 1)):
            if self.__debug:
                print("test case approved")
        else:
            print("Cannot approved test case")

        return new_test_case

    # *******************************************************************

    def update_test_case(self, token, pid, test_case_id, field_name, value):

        if self.__debug:
            print("TMS.createTestCase")

        if self._token is None:
            self._token = token

        field_id = self.get_mapping(pid, field_name)

        tc_data = {
            "id": test_case_id,
            "properties": [
                {
                    "field_id": field_id,
                    "field_value": value
                },
            ]
        }

        url = self._url_projects + str(pid) + self._url_testcases + "/" + str(
            test_case_id)

        response = requests.put(self._server_url + url,
                                headers=self._post(self._token),
                                data=json.dumps(tc_data),
                                verify=False)

        if response is not None and response.status_code not in \
                list(range(400, 599, 1)):
            return response

        return None

    # *******************************************************************
    def create_test_suite(self, token, pid, tsname,
                          tsdesc="automation created", parent_id=None,
                          parent_type=None):
        if self.__debug:
            print("TMS.createTestSuite")

        if self._token is None:
            self._token = token

        ts_data = {
            "name": tsname,
            "description": tsdesc
        }

        # url = self._url_projects  + pid + self._url_testsuites
        if parent_id is not None:
            url = self._url_testsuites + "?parentId=" + parent_id + \
                  "&parentType=" + parent_type
        else:
            url = self._url_testsuites

        response = self.tms_post(url, ts_data, pid, self._token)
        return response

    # *******************************************************************

    def create_test_run_structure(self, token, pid, tr_structure, tr_name,
                                  build_name, parent_id=0):
        list_of_folders = tr_structure.split("/")
        cycle = None
        self._loadCycles(token, pid)
        for folder in list_of_folders:
            for c in self.__buildcycles:
                cycle = None
                if c.id == parent_id:
                    cycle = c
                    break
            if cycle is None:
                cycle = self.create_build_cycle(self._token, pid, tr_name,
                                                build_name, parent_id)

            parent_id = cycle.id

        self.create_test_run(self, token, pid, tr_name, build_name, cycle.id)
        # check if this exist
        # if YES take the id
        # if NO create it and get the ID

    def loadCycle(self, token, pid):
        pass

    def create_test_run(self, token, pid, trname, build_name, parent_id=0,
                        parent_type="release"):
        if self.__debug:
            print("TMS.createTestrun")

        if self._token is None:
            self._token = token
        test_run_release_build_field = self.get_test_run_fields(
            token, pid, "Target Release/Build", build_name)
        tr_data = {
            "name": trname,
            "properties": [
                {
                    "field_id": test_run_release_build_field['id'],
                    "field_value": test_run_release_build_field['value']
                },
            ],
        }
        url = self._url_testrun
        if parent_id is not None:
            url = url + "?parentId=" + str(
                parent_id) + "&parentType=" + parent_type

        response = self.tms_post(url, tr_data, pid, self._token)
        test_run = TMSTestRun()

        if response is not None:
            test_run.id = response['id']
            test_run.name = response['name']
            # test_run.target_build_name =
            self.__test_runs.append(test_run)
            return test_run

        return None

    # *******************************************************************
    def create_test_log(self, token, pid, test_run_id, status, notes=""):
        if self.__debug:
            print("TMS.createTestLog")

        if self._token is None:
            self._token = token

        # quick test
        status_id = 0
        if status == "fail":
            status_id = 602
        elif status == "pass":
            status_id = 601
        else:
            status_id = 604

        exe_date = datetime.now(pytz.timezone("UTC"))
        test_log_data = {
            "exe_start_date": exe_date.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "exe_end_date": exe_date.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "status": {"id": status_id}
        }

        url = self._url_testrun + "/" + str(test_run_id) + self._url_testlogs

        response = self.tms_post(url, test_log_data, pid, self._token)

        return response

    # *******************************************************************
    def create_release(self, token, pid, rname):
        if self.__debug:
            print("TMS.createRelease")

        if self._token is None:
            self._token = token

        rel_data = {
            'name': rname,
            'properties': []
        }

        url = self._url_projects + pid + self._url_releases
        # response = requests.post(self._server_url + url,
        # json=rel_data, headers=self._post(self._token), verify=False)
        response = self.tms_post(self._url_releases, rel_data, pid,
                                 self._token)

        release = TMSTestRelease()
        release.id = response['id']
        release.name = response['name']
        self.__release.append(release)

        return release

    # *******************************************************************

    def create_build(self, token, pid, bname, build_date, parent_id=None,
                     parent_type=None):

        if self.__debug:
            print("TMS.createBuild")

        if self._token is None:
            self._token = token

        if build_date:
            build_date = str(build_date) + "T00:00:00-00:00"

        url = self._url_settings + self._url_builds + "/fields"
        response = self.tms_get(url, pid)
        fields = response
        my_id = 0
        try:
            for f in fields:
                if f['label'] == "Build Date":
                    my_id = f['id']
                    break
        except Exception as e:
            print(
                "Not enough permission to access field detail information, "
                "please contact a Qtest administrator")
            quit()
        b_data = {
            "name": bname,
            "release": {"id": parent_id},
            "properties": []
        }
        if build_date:
            b_data['properties'].append({
                "field_id": my_id,
                "field_value": str(build_date)
            })

        # only using release right now
        url = self._url_builds  # + "?parent_id&parent_type=release"
        response = self.tms_post(url, b_data, pid, self._token)

        build = TMSBuild()
        temp = response
        if temp is None:
            print("Creating build failed")
            quit()

        build.id = temp['id']
        build.name = temp['name']

        return build

    # *******************************************************************

    def create_build_cycle(self, token, pid, bname, parent_id, parent_type,
                           target_build_id=0):
        if self.__debug:
            print("TMS.createBuildCycle")

        if self._token is None:
            self._token = token

        b_data = {
            "name": bname,
            "target_release_id": parent_id,
            # "target_build_id": target_build_id - removed to
            # link the test cycle to the release
        }

        # only using release right now
        # url = self._url_testcycle + "?parentId=" + parent_id +
        # "&parentType=" + parent_type
        url = f"{self._url_testcycle}?parentId={parent_id}" \
              f"&parentType={parent_type}"
        response = self.tms_post(url, b_data, pid, self._token)

        cycle = TMSBuildCycle()
        temp = response

        if temp is None:
            "Creating Test Cycle failed"
            quit()

        cycle.id = temp['id']
        cycle.name = temp['name']
        cycle.pid = temp['pid']
        self.__buildcycles.append(cycle)

        return cycle

    # *******************************************************************
    def get_tree_path(self, parent_id):

        for mod in self.__modules:
            if str(mod.id) == str(parent_id):
                ret = self.get_tree_path(mod.parent_id)
                if ret is not None:
                    return ret + '/' + mod.name
                else:
                    return mod.name
        return None

    # *******************************************************************
    def get_full_path(self, mapping_id):
        for tc in self.__testcases:
            if str(tc.mapping_field_value) == str(mapping_id):
                full_path = self.get_tree_path(tc.parent_id)

                ac = full_path.replace("/", ".")
                if ac + "." + tc.name != tc.automation_content:
                    ac += ("." + tc.name)
                    response = self.update_test_case(self._token,
                                                     self._active_projectid,
                                                     tc.id,
                                                     "Automation Content",
                                                     ac)
                    if response is None:
                        print("Cannot update test case for mapping")

                return full_path + "." + tc.name + "." + str(tc.id)

        return None

    # *******************************************************************
    def create_test_module(self, token, pid, tmname, parent_id=None):
        if self.__debug:
            print("TMS.createTestModule")

        if self._token is None:
            self._token = token

        tm_data = {
            "name": tmname,
        }

        #
        # url = self._url_projects  + str(pid) + self._url_modules
        url = self._url_modules
        if parent_id is not None:
            url += "?parentId=" + str(parent_id)

        response = self.tms_post(url, tm_data, pid, self._token)
        m = response
        q_module = None
        if m is not None:
            q_module = TMSModule()
            q_module.id = m['id']
            q_module.name = m['name']
            self.__modules.append(q_module)
        else:
            print("Creating Module failed")
            quit()

        return q_module

    # *******************************************************************
    def create_qtums_report(self, qid, status):

        api_endpoint = 'http://gti-qtums-01.eng.dolby.net/api/v1/upload'

        try:
            import platform
            import os
            info = platform.uname()
            info_more = os.environ
            queue_data = {
                "name": self.context['project_name'],
                "queue_id": qid,
                "queue_status": status,
                "upload_username": self._user_id,
                "project_name": self.context['project_name'],
                "release_name": self.context['release_name'],
                'build_name': self.context['build_name'],
                "computer_name": info[1],
                "os_info": info[3],
                "user": info_more['USER']
            }
            response = requests.post(api_endpoint, data=json.dumps(queue_data),
                                     verify=False)
        except Exception as e:
            print("Error occured: create_qtums_report")

        return

    # *******************************************************************
    def batch_upload(self, token, pid, struct):

        url = self._url_3_1_projects + str(pid) + self._url_batch_upload

        response = requests.post(self._server_url + url,
                                 data=json.dumps(struct),
                                 headers=self._post(self._token),
                                 verify=False)

        data = response.json()
        print("Upload status =" + str(data['state']))
        self.__batch_testrun_array.append(data)

    def poll_batch(self):

        url = self._url_batch_poll
        failed_array = []
        process = True
        trying = 12  # this will be configurable

        if len(self.__batch_testrun_array) > 0:
            queue_id = self.__batch_testrun_array[0]['id']
        last_status = None
        while process and trying > 0:
            for testrun in self.__batch_testrun_array:
                if testrun is None:
                    print("No result found. Results are required")
                    exit(0)
                # which means it's the first call
                if trying == 12:
                    url = url + str(testrun['id'])

                response = self.tms_get(url, None)
                data = response
                if data:
                    last_state = str(data["state"])
                    print("Polling status =" + str(data["state"]))
                    if data['state'] != 'SUCCESS':
                        failed_array.append(testrun)

            if failed_array:
                trying = trying - 1
                print("Still processing")
                time.sleep(20)
            else:
                process = False

            self.__batch_testrun_array = failed_array
            failed_array = []

        if any(self.__batch_testrun_array):
            print("TEST RUNS NOT PROCESSED " + str(
                len(self.__batch_testrun_array)))
            status = "STILL IN QUEUE PROCESSING. " \
                     "Please verify your data in Qtest"

        # not a blocking call if this fails, it fails
        try:
            self.create_qtums_report(queue_id, last_state)
        except requests.exceptions.RequestException as e:
            print("INFO: No upload report:", e)

        print("UPLOAD COMPLETE >> " + last_state)
        print("COMPLETED UPLOAD >> " + str(datetime.now().time()))

        if last_state.lower().strip() == "success":
            return True
        return False

    # *********************************************************************
    def create_test_run_struct_obsolete(self, token, pid, trunname, parent_id,
                                        tcase_id, status, testsuite_id,
                                        parent_type, test_run_struct):

        if self.__debug:
            print("TMS.createTestRunStruct")

        if self._token is None:
            self._token = token

        if test_run_struct is None or any(
                test_run_struct) is False or parent_id != self.lastparent_id:
            if self.lastparent_id != parent_id and any(test_run_struct):
                # This is for testing -debug ONLY
                # self.savefile(test_run_struct, "qtestBatch", "w")
                self.batch_upload(self, pid, test_run_struct)

            test_run = {
                "test_suite": str(testsuite_id),
                "parent_module": str(parent_id),
                "execution_date": time.strftime("%Y/%m/%d"),
                # str(datetime.now()),
                "test_logs": []
            }
            json_data = test_run
            self.lastparent_id = parent_id
        else:
            json_data = test_run_struct

        test_logs = [
            {
                "name": trunname,
                "status": status,
                "exe_start_date": time.strftime(
                    "%Y/%m/%d") + 'T00:00:00-00:00',
                "exe_end_date": time.strftime("%Y/%m/%d") + 'T00:00:00-00:00',
                "automation_content": trunname
            }
        ]

        json_data['test_logs'].extend(test_logs)
        return json_data

    # *********************************************************************
    def create_test_run_struct_30(self, token, pid, trunname, parent_id,
                                  tcase_id, status, testsuite_pid, parent_type,
                                  test_run_struct, path, base_path,
                                  keep_structure, platform_name, config_name,
                                  mapping_id=0):
        """

        :param token: identication token, used for special case when the
            class the does not have to token set
        :param pid: prject id
        :param trunname: test run and test case name (same name in QTest)
        :param parent_id: parent where the structure has to be created,
            this has to be a test cycle
        :param tcase_id:
        :param status: status of the test
        :param parent_type: Test Cycle for now but still using a parameter
            in case that changes in the future
        :param test_run_struct: JSON structure that will be passed to the REST
            Api when the creation is complete
        :param path: string that identifie where the test case is (full tree)
            separated by "."
            Example module1.module2.testnname. This will be stored in the
             automation content which is used to uniquely
            identify a test case
        :return:a modified test_run_struct which is the combination of the
            original version passed to this method and
            the organization of the rest of the data appened to the struct.
        """
        # print("platform_name=" + platform_name)
        automation_content = ""
        escaped_trunname = ""
        if mapping_id is None:
            mapping_id = 0

        if self.__debug:
            print("TMS.createTestRunStruct")

        if self.__platform_field == 0 and platform_name != "" \
                and platform_name is not None:
            platform_res = self.get_test_run_fields(token, pid, "Environment",
                                                    platform_name)
            self.__platform_field = platform_res['id']
            self.__platform_value = platform_res['value']

        if self.__config_field == 0 and config_name != "" \
                and config_name is not None:
            config_res = self.get_test_run_fields(token, pid, "Configuration",
                                                  config_name)
            self.__config_field = config_res['id']
            self.__config_value = config_res['value']

        default_path = path.replace(".", "/")
        temp = base_path.replace(".", "/")
        base_path = temp

        if base_path and keep_structure:
            path = base_path + "/" + path
        elif base_path and not keep_structure:
            path = base_path

        if not base_path and not keep_structure:
            path = default_path

        if mapping_id > 0:
            if self.mapping_field_name == "":
                new_path = self.get_full_path(
                    self.testcase_prefix + "-" + str(mapping_id))
            else:
                new_path = self.get_full_path(str(mapping_id))

            if new_path is not None:
                n = new_path.split(".")
                new_path = n[0]
                automation_content = n[1] + "." + n[2]
                path = new_path[new_path.find("/") + 1:]
            else:
                print("No mapping found for id " + str(
                    mapping_id) + ". Please verify the mapping or mapping "
                                  "field and try again")
                quit()
        else:
            automation_content = path + "." + escaped_trunname

        escaped_trunname = self.escape_data(trunname)

        if self._token is None:
            self._token = token

        # path = path.replace(".", "/")

        if test_run_struct is None or any(test_run_struct) is False:
            test_run = {
                "test_cycle": testsuite_pid,
                "test_logs": [],
            }
            json_data = test_run
        else:
            json_data = test_run_struct

        test_logs = [
            {
                "properties": [
                    {
                        "field_id": self.__platform_field,
                        "field_value": self.__platform_value
                    },
                    {
                        "field_id": self.__config_field,
                        "field_value": self.__config_value
                    }
                ],
                "name": escaped_trunname,
                "status": status,
                "module_names": path.split("/"),
                "exe_start_date": time.strftime("%Y-%m-%dT%H:%M:%S+00:00",
                                                time.gmtime()),
                "exe_end_date": time.strftime("%Y-%m-%dT%H:%M:%S+00:00",
                                              time.gmtime()),
                "automation_content": automation_content,
                # path + "." + escaped_trunname,

            }
        ]

        json_data['test_logs'].extend(test_logs)

        return json_data

    # *********************************************************************
    def create_test_run_struct_31(self, token, pid, trunname, parent_id,
                                  tcase_id, status, testsuite_pid, parent_type,
                                  test_run_struct, build_name, structure_path,
                                  base_path, keep_structure, platform_name,
                                  config_name,
                                  test_case, mapping_id=0, property=None):
        """

        :param token: identication token, used for special case when the
            class the does not have to token set
        :param pid: prject id
        :param trunname: test run and test case name (same name in QTest)
        :param parent_id: parent where the structure has to be created,
            this has to be a test cycle
        :param tcase_id:
        :param status: status of the test
        :param parent_type: Test Cycle for now but still using a parameter
            in case that changes in the future
        :param test_run_struct: JSON structure that will be passed to the REST
            Api when the creation is complete
        :param structure_path: string that identifie where the test case is
            (full tree) separated by "."
            Example module1.module2.testnname. This will be stored in the
            automation content which is used to uniquely
            identify a test case
        :return:a modified test_run_struct which is the combination of the
            original version passed to this method and
            the organization of the rest of the data appened to the struct.
        """
        # print("platform_name=" + platform_name)
        test_case_id = 0
        # This is to support upload of pass only test. Specific for
        # complex setup.
        if self.context["pass_only"] and status != XU_PASS:
            return test_run_struct

        custom_fid = 0
        custom_fname = ""
        custom_value = ""
        if self.context['custom_field_name'] is not None:
            custom_fname = self.context['custom_field_name']
            custom_fid = self.get_test_run_fields(
                token, pid, custom_fname, None, True)["id"]
            custom_value = self.context['custom_field_value']

        # update test-run custom field with property from xunit
        custom_field = 0
        custom_field_value = ""
        if property is not None:
            property_map = property.split("=")
            custom_field = self.get_test_run_fields(
                token, pid, property_map[0], None, True)["id"]
            # to be added for multiple custom fields
            # custom_fields.append(custom_field)
            custom_field_value = property_map[1]

        automation_content = ""
        escaped_trunname = self.escape_data(trunname)
        if mapping_id is None:
            mapping_id = 0

        if self.__debug:
            print("TMS.createTestRunStruct")

        if self.__platform_field == 0 and platform_name != "" \
                and platform_name is not None:
            platform_res = self.get_test_run_fields(token, pid, "Environment",
                                                    platform_name)
            self.__platform_field = platform_res['id']
            self.__platform_value = platform_res['value']

        if self.__config_field == 0 and config_name != "" \
                and config_name is not None:
            config_res = self.get_test_run_fields(token, pid, "Configuration",
                                                  config_name)
            self.__config_field = config_res['id']
            self.__config_value = config_res['value']

        structure_path = structure_path.replace(".", "/")
        temp = base_path.replace(".", "/")
        base_path = temp

        if (base_path and base_path != "Automated") and keep_structure:
            structure_path = base_path + "/" + structure_path

        elif base_path and not keep_structure:
            structure_path = base_path

        if (not base_path or base_path == "Automated") and not keep_structure:
            structure_path = structure_path

        if mapping_id > 0:
            if self.mapping_field_name == "":
                new_path = self.get_full_path(
                    self.testcase_prefix + "-" + str(mapping_id))
            else:
                new_path = self.get_full_path(str(mapping_id))

            if new_path is not None:
                n = new_path.split(".")
                temp = n[0].replace(".", "/")
                if not self.context['ignore_testcase_path']:
                    structure_path = temp
                automation_content = temp + "." + n[1]
                # for when then implement the fix to map to test case id
                test_case_id = n[2]
            else:
                print("No mapping found for id " + str(
                    mapping_id) + ". Please verify the mapping or mapping "
                                  "field and try again")
                quit()
        else:
            automation_content = structure_path + "." + escaped_trunname

        if self._token is None:
            self._token = token

        automation_content = automation_content.replace("/", ".")

        # self.create_test_run(token,pid,escaped_trunname,test_case_id,
        # testsuite_pid,"Test-Cycle")
        json_data = None
        if test_run_struct is None or any(test_run_struct) is False:
            # self.create_test_run_structure(self._token,pid, structure_path,
            # trunname, build_name, parent_id)
            test_run = {
                "test_cycle": testsuite_pid,
                "test_logs": [],
            }
            json_data = test_run
        if json_data is None:
            json_data = test_run_struct
        if self.update_test_run(token, pid, escaped_trunname,
                                automation_content, build_name) is None:
            pass
        # if len(test_run_struct['test_logs']) >= 0:
        test_logs = [
            {
                "properties": [
                    {
                        "field_id": self.__platform_field,
                        "field_value": self.__platform_value
                    },
                    {
                        "field_id": self.__config_field,
                        "field_value": self.__config_value
                    },
                    {
                        "field_id": custom_fid,
                        "field_value": custom_value
                    },

                ],
                "name": escaped_trunname,
                "status": status,
                "module_names": structure_path.split("/"),
                "exe_start_date": time.strftime("%Y-%m-%dT%H:%M:%S+00:00",
                                                time.gmtime()),
                "exe_end_date": time.strftime("%Y-%m-%dT%H:%M:%S+00:00",
                                              time.gmtime()),
                "automation_content": automation_content,
                # path + "." + escaped_trunname,
                "note": test_case.name + " >> " + test_case.description,
            }
        ]

        json_data['test_logs'].extend(test_logs)

        return json_data

    # *********************************************************************
    def update_test_run(self, token, pid, tr_name, automation_content,
                        build_name):
        tr_data = {}
        target_release_build = self.load_test_runs_build_field(token, pid)
        # when release is not supplied, testset will be used as release
        if self.context['release_name'] is None:
            self.context['release_name'] = self.context['set_name']

        # if self.search_item_by_query(pid,"test-runs",
        # "'Test Automation content")
        test_run_info = self.get_test_runs_by_name_and_release(
            pid, tr_name, automation_content, self.context['release_name'])

        if test_run_info:
            # if the value is the same, no need to update
            if test_run_info["field_text_value"] != build_name:
                for record in target_release_build:
                    if record.name == build_name \
                            and record.type.lower() == "build" and \
                            record.parent_name == self.context['release_name']:
                        break
                    record = None

        if test_run_info and record:
            tr_data = {
                "id": test_run_info["id"],
                "properties": [
                    {
                        "field_id": record.field_id,
                        "field_value": record.value_id
                    },
                ],
            }
            url = self._server_url + self._url_projects + str(
                pid) + "/test-runs/" + str(test_run_info["id"])
            response = requests.put(url, headers=self._post(self._token),
                                    data=json.dumps(tr_data), verify=False)
            return "success"

        # else:
        #    This needs to be fixed but need to find the root node
        #    and create the whole tree of test cycles
        #    self.create_test_run_with_path(self._token,pid,tr_name,build_name)

        return None

    def create_test_run_with_path(self, pid, automation_content, test_cycle_id,
                                  test_run_name, target_build):
        pass

        # list_of_cycles = automation_content.split(".")
        # release = self.get_release_by_attribute(self._token,pid,name=)
        # for cycle in list_of_cycles:
        #    self.get_build_cycle_by_name(self._token,pid, cycle, )

    def escape_data(self, str_to_escape):
        newdata = str_to_escape.replace("<", "&lt;")
        newdata = newdata.replace(">", "&gt;")
        newdata = newdata.replace('"', "&quot;")
        newdata = newdata.replace("'", "&apos;")
        newdata = newdata.replace("&", "&amp;")
        return newdata

    def run_batch(self, pid, data):

        # request exception for now...
        # This is left there for testing only
        # print(" <<<<<<<<<<<<<<< PRINT JSON  >>>>>>>>>>>>>> ")
        # out_file = open("test.json", "w")
        # json.dump(data, out_file, indent=4, sort_keys=True)
        # out_file.close()
        print("STARTING UPDLOAD >> " + str(datetime.now().time()))

        url = self._url_custom_batch_upload
        response = self.tms_post(url, data, pid, self._token)

        print("UPLOAD REQUEST SENT")
        self.__batch_testrun_array.append(response)

    # *********************************************************************

    def get_test_case_parent_id(self, testcase_id):
        for testcase in self.__testcases:
            if testcase.id == testcase_id:
                return testcase.parent_id

        return 0

    # *********************************************************************

    def get_module_by_id(self, module_id):
        for mod in self.__modules:
            if mod.id == module_id:
                return mod

        return None

    # def savefile(self,data,filename, mode):
    #    import simplejson
    #    qtestUpload = open(filename + str(self.__fileindex) + ".json", mode)
    #    self.__fileindex +=1
    #    #magic happens here to make it pretty-printed
    #    qtestUpload.write(simplejson.dumps(data))
    #    qtestUpload.close

    def is_empty(self, obj):
        for i in obj:
            return False

        return True

    # *******************************************************************

    def get_instance_tms_test_case(self):
        t = TMSTestCase()
        return t

    def get_instance_tms_project(self):
        p = TMSProject()
        return p

    def get_test_runs_all(self, token, pid, suitet_id):
        if self.__debug:
            print("TMS.getTestRunsAll")
        if self._token is None:
            self._token = token

        url = self._url_testsuites

        if suitet_id is not None and suitet_id > -1:
            url = url + "/" + str(suitet_id) + "/test-runs"

        response = self.tms_get(url, pid)

        truns = response
        self._json_test_runs = truns
        try:
            for tr in truns:
                testrun = TMSTestRun()
                testrun.name = tr['name']
                testrun.id = tr['id']
                for p in tr['properties']:
                    if 'field_name' in p:
                        if p['field_name'] == "Target Release/Build":
                            if 'field_value_name' in p:
                                testrun.release_build_value = p[
                                    'field_value_name'].strip()
                                if p['field_value_name'][:1] == " ":
                                    testrun.release_build_type = "Build"
                                else:
                                    testrun.release_build_type = "Release"

                                break
                for link in tr['links']:
                    if link['rel'] == 'release':
                        start_pos = link['href'].rfind('/')
                        rel_id = link['href'][start_pos + 1:]
                        release = self.get_release_by_attribute(token, pid,
                                                                "id",
                                                                int(rel_id))
                        testrun.release_name = release
                        break
                self.__test_runs.append(testrun)
        except Exception as exep:
            pass

        if self.__test_runs is None:
            return None

        return self.__test_runs


# --------------------------------------- CLASSES ----------------------------


class TMSProject:
    """

    """

    def __init__(self):
        self.__name = None
        self.__end_date = None
        self.__start_date = None
        self.__description = None
        self.__automation = None
        self.__id = None

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def description(self):
        return self.__description

    @property
    def start_date(self):
        return self.__start_date

    @property
    def end_date(self):
        return self.__end_date

    @property
    def automation(self):
        return self.__automation

    @automation.setter
    def automation(self, value):
        self.__automation = value


# ========================================================
class TMSRequirements:
    def __init__(self):
        self.__id = None
        self.__name = None
        self.__pid = None

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def pid(self):
        return self.__pid

    @pid.setter
    def pid(self, value):
        self.__pid = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value


# ========================================================

class TMSTestRelease:

    def __init__(self):
        self.__id = None
        self.__name = None
        self.__note = None
        self.__start_date = None
        self.__end_date = None

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def note(self):
        return self.__note

    @note.setter
    def note(self, value):
        self.__note = value


# ========================================================
class TMSTestCase:

    def __init__(self):
        self.__description = None
        self.__id = None
        self.__pid = None
        self.__name = None
        self.__type = None
        self.__automation_content = None
        self.__mapping_field_value = ""
        self.__precondition = None
        self.__steps = []
        self.__properties = []
        self.__fields = []
        self.__parent_id = None

    @property
    def automation_content(self):
        return self.__automation_content

    @automation_content.setter
    def automation_content(self, value):
        self.__automation_content = value

    @property
    def mapping_field_value(self):
        return self.__mapping_field_value

    @mapping_field_value.setter
    def mapping_field_value(self, value):
        self.__mapping_field_value = value

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def pid(self):
        return self.__pid

    @pid.setter
    def pid(self, value):
        self.__pid = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def description(self):
        return self.__description

    @description.setter
    def description(self, value):
        self.__description = value

    @property
    def type(self):
        return self.__type

    @property
    def precondition(self):
        return self.__precondition

    @property
    def steps(self):
        return self.__steps

    @property
    def properties(self):
        return self.__properties

    @property
    def fields(self):
        return self.__fields

    @fields.setter
    def fields(self, values):
        self.__fields = values

    @property
    def parent_id(self):
        return self.__parent_id

    @parent_id.setter
    def parent_id(self, value):
        self.__parent_id = value


# ========================================================

class TMSTestSuite:
    """

    """

    def __init__(self):
        self.__id = None
        self.__name = None

    @property
    def id(self):
        return self.__id

    @property
    def name(self):
        return self.__name

    @id.setter
    def id(self, value):
        self.__id = value

    @name.setter
    def name(self, value):
        self.__name = value


# ========================================================


class TMSTestStep:

    def __init__(self):
        self.__id = None
        self.__step_number = None
        self.__description = None
        self.__expected_result = None
        self.__attachments = []

    @property
    def id(self):
        return self.__id

    @property
    def step_number(self):
        return self.__step_number

    @property
    def description(self):
        return self.__description

    @property
    def expected_result(self):
        return self.__expected_result

    @property
    def attachments(self):
        return self.__attachments


# ========================================================
class TMSField:

    def __init__(self):
        self.__field_id = None
        self.__field_value = None

    @property
    def field_id(self):
        return self.__field_id

    @property
    def field_value(self):
        return self.__field_value


# ========================================================

class TMSCustomField:
    """
    """

    def __init__(self):
        self.__id = None
        self.__name = None
        self.__value = None

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def value(self):
        return self.__value

    @value.setter
    def value(self, value):
        self.__value = value


# ========================================================
class TMSTest_run_release_build_info:
    def __init__(self):
        self.__name = ""
        self.__field_id = 0
        self.__value_id = 0
        self.__release_id = 0
        self.__release_name = ""
        self.__type = ""

    @property
    def release_name(self):
        return self.__release_name

    @release_name.setter
    def release_name(self, value):
        self.__release_name = value

    @property
    def release_id(self):
        return self.__release_id

    @release_id.setter
    def release_id(self, value):
        self.__release_id = value

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, value):
        self.__type = value

    @property
    def value_id(self):
        return self.__value_id

    @value_id.setter
    def value_id(self, value):
        self.__value_id = value

    @property
    def field_id(self):
        return self.__field_id

    @field_id.setter
    def field_id(self, value):
        self.__field_id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value


class TMSTestRun:
    """
    """

    def __init__(self):
        self.__id = None
        self.__name = None
        self.__status = None

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def status(self):
        return self.__status

    @status.setter
    def status(self, value):
        self.__status = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value


# ========================================================
class TMSBuild:
    """
    """

    def __init__(self):
        self.__id = None
        self.__name = None
        self.__fields = []
        self.__build_date = None

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def fields(self):
        return self.__fields

    @fields.setter
    def fields(self, value):
        self.__fields = value

    @property
    def build_date(self):
        return self.__build_date

    @build_date.setter
    def build_date(self, value):
        self.__build_date = value


# ========================================================

class TMSBuildCycle:
    """

    """

    def __init__(self):
        self.__id = None
        self.__name = None
        self.__pid = None

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def pid(self):
        return self.__pid

    @pid.setter
    def pid(self, value):
        self.__pid = value


# ========================================================

class TMSModule:
    """

    """

    def __init__(self):
        self.__id = None
        self.__name = None
        self.__parent_id = None
        self.__testcases = []

    @property
    def parent_id(self):
        return self.__parent_id

    @parent_id.setter
    def parent_id(self, value):
        self.__parent_id = value

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def testcases(self):
        return self.__testcases

    @testcases.setter
    def testcases(self, values):
        self.__testcases = values


class TMSTestLog:
    """
    """

    def __init__(self):
        self.__id = None
        self.__name = None
        self.__status = None

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def status(self):
        return self.__status

    @status.setter
    def status(self, value):
        self.__status = value

# ========================================================
