from app.common.config_reader import Config

config = Config().config
