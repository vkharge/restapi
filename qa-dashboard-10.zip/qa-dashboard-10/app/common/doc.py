

API_VERSION = "v1"
prefix = "/api/{}".format(API_VERSION)

title = "QA-Dashboard-RestAPI"
description = "RestAPI endpoints to push test execution" \
              " data in the report server"
version = "1.0"
contact = {
    "name": "Vishal Kharge",
    "email": "vishal.kharge@dolby.com",
    }

tags_metadata = [
    {
        "name": "Org",
        "description": "Org CRUD API",
    },
    {
        "name": "Product",
        "description": "Product CRUD API",
    },
    {
        "name": "Sub-Product",
        "description": "Sub-Product CRUD API",
    },
    {
        "name": "Environment",
        "description": "Environment CRUD API",
    },
    {
        "name": "Test-Type",
        "description": "Test-Type CRUD API",
    },

    {
        "name": "Mappings",
        "description": "Mappings CRUD API",
    },
    {
        "name": "SuiteMappings",
        "description": "Suite Mappings CRUD API",
    },
    {
        "name": "Suite",
        "description": "Suite CRUD API",
    },
    {
        "name": "TestCase",
        "description": "TestCase CRUD API",
    },
]
