$(document).ready(function () {

    //$('#suite-summary-table').DataTable();

    $('[data-toggle="tooltip"]').tooltip();   

    $(document).on("click", ".view-testcases", function(){
        id = $(this).attr('id');
        var url = location.protocol + '//' + location.host + '/get_testcase_execution?suite_id='+ id;
        var myWindow = window.open();
        myWindow.location.href = url;
    }); 


    capturingRegex = /<br>Executed: (.*?)<br>/;
    $('[data-toggle="tooltip"]').each(function(){
        title = $(this).attr('data-original-title')
        found = title.match(capturingRegex);
        local =moment.utc(found[1]).local().format('DD-MM-YYYY HH:mm:ss')

        new_title = title.replace(capturingRegex, '<br>Executed: ' + local + '<br>')
        $(this).attr('data-original-title', new_title)
    });

});


