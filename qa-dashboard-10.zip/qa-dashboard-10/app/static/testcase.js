$(document).ready(function () {

    $('#testcase-table').DataTable({
        lengthMenu: [[25, 50, 100, -1], [25, 50, 100, "All"]],
        pagingType: "full_numbers"
    });

    $(document).on("click", ".view-testclass-testcases", function(){
        testClass = $(this).attr('id');
        id = $("#report-table").attr('suite-id');

        var url = location.protocol + '//' + location.host + '/get_testclass_testcase_execution?suite_id='+ id + '&test_class=' + testClass;
        var myWindow = window.open();
        myWindow.location.href = url;        
    });

    executed_date = $('#executed-date').text();
    $('#executed-date').text(moment.utc(executed_date).local().format('DD-MM-YYYY HH:mm:ss'));
    
});


