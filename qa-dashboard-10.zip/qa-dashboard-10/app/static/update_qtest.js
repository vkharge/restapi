$(document).ready(function () {

    $("#match-alert").hide();

    $('#testcase-table').DataTable({
        lengthMenu: [[-1, 25, 50, 100], ["All", 25, 50, 100]],
        pagingType: "full_numbers"
    });

    $('#qtest-tree').jstree({
        'contextmenu': {
            'items': customMenu
        },
        'plugins': ['contextmenu'],       
        'core':{
            'multiple': false,

            'data' : {
                'url' : '/get_qtest_folders',
                'data' : function (node) {
                    suite_id = $('#qtest-tree').data('id')
                    try {
                        node_type = node.data.type
                        project_id = node.data.project
                    } catch (e) {
                        node_type = $('#qtest-tree').data('type')
                        project_id = 0
                    }
                    return { 'suite_id': suite_id,
                             'project_id': project_id,
                             'node_id' : node.id,
                             'node_type': node_type};
                }
            }
        }
    });

    $('.selection-btn').click(function (e) {
        e.preventDefault();
        $(this).addClass('active').siblings().removeClass('active');
        var selectedButtonName = $(this).attr('name');

        // if matched is selected : select the rows which has qTest Status in it
        // if All is selected : select the all the rows irrespective of the qTest Status in it
        if ($('#matched-test').hasClass('active')){
            allRows = $('#testcase-table tbody tr').filter(function( index ) {
                col = $(this).children('.col-qteststatus').text();
                return col != '';
           });
        } else {
            allRows = $('#testcase-table tbody tr').filter(function( index ) {
                col = $(this).children('.col-qteststatus').text();
                return true;
           });
        }

        //console.log(allRows)

        if(selectedButtonName === "all"){
            allRows.addClass('selected');
        }else if(selectedButtonName === "none"){
            allRows.removeClass('selected');
        }else if(selectedButtonName === "passed"){
            allRows.removeClass('selected');
            allRows.each(function (index, value) {
                status = $(this).children('.status').text();

                if(status === "PASSED"){
                    $(this).addClass('selected')
                }
            });
        }else if(selectedButtonName === "failed"){
            allRows.removeClass('selected');
            allRows.each(function (index, value) {
                status = $(this).children('.status').text();
                if(status === "FAILED"){
                    $(this).addClass('selected')
                }
            });
        }

    });

    $('#testcase-table tbody').on('click', 'tr', function () {
        $(this).toggleClass('selected');
    });

    $('#qtest-tree').on("changed.jstree", function (e, data) {

        disable_matched_buttons(true);
        disable_selection_buttons(true);
        disable_upload_button(true)

        // get the selected node
        selected_element = $('#' + data.selected[0]);
        isTestCycleOrSuite = selected_element.hasClass( "test-suite" ) || selected_element.hasClass( "test-cycle" );

        if (isTestCycleOrSuite) {

            $('#dvLoading').fadeIn(500);

            disable_selection_buttons(false);

            // get the selected node details
            node_id = data.selected[0];
            node_name = $('#' + data.selected[0]).attr('name');
            node_type = $('#' + data.selected[0]).attr('data-type');
            project_id = $('#' + data.selected[0]).attr('data-project');
            suite_id = $('#qtest-tree').data('id');

            // set the selected node name
            set_test_suite_name(node_name, node_id);

            //show_all_tests()

            // get the test cases for the selected node
            $.getJSON("/get_qtest_testcases", {
                'suite_id' : suite_id,
                'project_id' : project_id,
                'node_id' : node_id,
                'node_type' : node_type
                },
               function (data, textStatus, jqXHR) {
                    e.preventDefault();

                    // Clear the qtest status from test cases and display again
                    show_all_tests_with_qtest_status_empty()

                    // Iterate over the executed test cases
                    testNames = $('.testcasename');
                    match_count = 0;
                    testNames.each(function (index, value) {
                        tdElement = $(this);
                        testcasename = $(this).text();

                        // Set the qTest status for the executed test cases
                        if(data.hasOwnProperty(testcasename)){
                            match_count += 1
                            qtest_teststatus = data[testcasename]['status']
                            qtest_testid = data[testcasename]['id']
                            tdElement.siblings('.col-qteststatus').text(qtest_teststatus);
                            tdElement.siblings('.col-qteststatus').attr('id', qtest_testid);
                        }

                    });

                    // Display the warning the warning message
                    show_selected_test_msg(testNames.length, match_count);

                    // Hide the non matching executed test cases and Display only the match test cases
                    hide_non_matched_tests();

                    $('#matched-test').attr('data-count', match_count);
                    $('#all-test').removeClass('active');
                    $('#matched-test').addClass('active');

                    disable_matched_buttons(false);
                    // match count is zero and matched button is selected
                    //disable_selection_buttons(true); 
                    if (match_count <= 0 && $('#matched-test').hasClass('active')) {
                        disable_selection_buttons(true);
                        disable_upload_button(true)
                        disable_update_button(true)
                    } else {
                        disable_upload_button(true)
                        disable_update_button(false)
                    }                  

                    // if (match_count > 0) {
                    //     //disable_selection_buttons(false);
                    //     disable_upload_button(true)
                    //     disable_update_button(false)
                    // }
                    // else {                       
                    //     //disable_selection_buttons(true);
                    //     disable_upload_button(false)
                    //     disable_update_button(true)
                    // }
               }
           );

           $('#dvLoading').fadeOut(1000);
        }
        else {
            disable_selection_buttons(true);

            // set the selected node to --- Selected test Suite ---
            // when the user clicks on build_cycle or release name
            unset_test_suite_name();
        }
    });


    $('.selection-match-btn').click(function (e) {
        e.preventDefault();
        $(this).addClass('active').siblings().removeClass('active');
        var selectedButtonName = $(this).attr('name');

        if(selectedButtonName === "all"){
            // get the selected node
            var node = $("#qtest-tree").jstree("get_selected", true)[0]
            if (node.data.type === "test-suite"){
                disable_selection_buttons(true);
                disable_upload_button(true)
            } else {
                disable_selection_buttons(false);
                disable_upload_button(false)
            }

            disable_update_button(true)
            show_all_tests();
        }
        else if(selectedButtonName === "matched"){
            disable_upload_button(true)
            matched = $('#matched-test').attr('data-count');
            if (matched > 0){
                disable_selection_buttons(false);
                disable_update_button(false)
            } else {
                disable_selection_buttons(true);
                disable_update_button(true)
            }

            hide_non_matched_tests();
        }

    });

    $('#update-results').click(function (e) {
        e.preventDefault();

        var rows = $('#testcase-table tbody tr').filter(".selected");
        rows_count = rows.length
        if (rows_count == 0){
            //show_danger_alert('Please select atleast 1 testcase to update in qTest');
            show_alert('danger', 'Please select atleast 1 testcase to update in qTest');
            return 0;
        }

        //("FADE IN")
        $('#dvLoading').fadeIn(300);

        var tests = [];
        rows.each(function (index, value) {

            var testName = $(this).children('.testcasename').text();
            var testStatus = $(this).children('.status').text();
            var testCaseId = $(this).children('.col-qteststatus').attr("id");

            test = {
                "name": testName,
                "status": testStatus,
                "id": testCaseId
            }

            tests.push(test)
        });

        var projectId = $("#qtest-tree").jstree("get_selected", true)[0]["data"]["project"];
        suite_id = $('#qtest-tree').data('id');
        formData = {
            "suite_id": suite_id,
            "project_id": projectId,
            "tests": tests
        }
        //console.log(formData)

        $.ajax({
            method: "POST",
            url: "/update_qtest_test_status",
            data: JSON.stringify(formData),
            contentType: "application/json; charset=utf-8",
            success: function (response) {
                console.log("Tests Count: " + tests.length)
                console.log("Response Count: " + response.count)
                if (response.count == tests.length){
                    show_alert('success', 'Test Status Updated Successfully In QTest.')
                }
                else if (response.count > 0){

                    show_alert('warning', 'Only ' + response.count + ' Test Status Updated Successfully In QTest Out Of ' + tests.length)
                } 
                else {
                    show_alert('danger', 'ERROR: Test Status Not Updated In QTest.')
                }
 
                // get the selected node
                selected_element = $("#qtest-tree").jstree("get_selected", true)[0];
                
                // get the selected node details
                node_id = selected_element["id"];
                node_type = selected_element["data"]["type"];
                project_id = selected_element["data"]["project"];
                suite_id = $('#qtest-tree').data('id');

                // get the test cases for the selected node
                $.getJSON("/get_qtest_testcases", {
                    'suite_id' : suite_id,
                    'project_id' : project_id,
                    'node_id' : node_id,
                    'node_type' : node_type
                    },
                    function (data, textStatus, jqXHR) {
                        e.preventDefault();

                        // Iterate over the executed test cases
                        testNames = $('.testcasename');
                        match_count = 0;
                        testNames.each(function (index, value) {
                            tdElement = $(this);
                            testcasename = $(this).text();

                            // Set the qTest status for the executed test cases
                            if(data.hasOwnProperty(testcasename)){
                                match_count += 1
                                qtest_teststatus = data[testcasename]['status']
                                qtest_testid = data[testcasename]['id']
                                tdElement.siblings('.col-qteststatus').text(qtest_teststatus);
                                tdElement.siblings('.col-qteststatus').attr('id', qtest_testid);
                            }

                        });
                    }
                );

                $('#dvLoading').fadeOut(1000);
                //$("#none").addClass('active').siblings().removeClass('active');
            },
            error: function(data) {
                console.log(data);
                console.log("Error" + data['responseText']);
                show_alert('danger', 'Error: '+ data['responseText']);
                
                $('#dvLoading').fadeOut(1000);
            },
        });

    });

    $('#upload-results').click(function (e) {
        e.preventDefault();

        var rows = $('#testcase-table tbody tr').filter(".selected");
        rows_count = rows.length
        if (rows_count == 0){
            //show_danger_alert('Please select atleast 1 testcase to update in qTest');
            show_alert('danger', 'Please select atleast 1 testcase to upload in qTest');
            return 0;
        }

        //console.log("FADE IN")
        $('#dvLoading').fadeIn(300);

        var tests = [];
        rows.each(function (index, value) {

            var testClass = $(this).children('.testclassname').text();
            var testName = $(this).children('.testcasename').text();
            var testStatus = $(this).children('.status').text();

            test = {
                "classname": testClass,
                "name": testName,
                "status": testStatus
            }
            tests.push(test)
        });

        var node = $("#qtest-tree").jstree("get_selected", true)[0]
        var projectId = $("#qtest-tree").jstree("get_selected", true)[0]["data"]["project"];
        suite_id = $('#qtest-tree').data('id');

        formData = {
            "suite_id": suite_id,
            "project_id": projectId,
            "node_id" : node.id,
            "node_type" : node.data.type,
            "tests": tests
        }
        //console.log(formData)

        $.ajax({
            method: "POST",
            url: "/upload_qtest_test",
            data: JSON.stringify(formData),
            contentType: "application/json; charset=utf-8",
            success: function (response) {
                console.log("Tests Count: " + tests.length)
                console.log("Response Count: " + response.count)
                if (response.count == tests.length){
                    show_alert('success', 'Test Case and its Status Uploaded Successfully In QTest.')
                }
                else if (response.count > 0){

                    show_alert('warning', 'Only ' + response.count + ' Test testClass Uploaded Successfully In QTest Out Of ' + tests.length)
                } 
                else {
                    show_alert('danger', 'ERROR: Test Case and its Status not uploaded In QTest.')
                }
 
                // get the selected node
                selected_element = $("#qtest-tree").jstree("get_selected", true)[0];
                
                // get the selected node details
                node_id = selected_element["id"];
                node_type = selected_element["data"]["type"];
                project_id = selected_element["data"]["project"];
                suite_id = $('#qtest-tree').data('id');

                // get the test cases for the selected node
                $.getJSON("/get_qtest_testcases", {
                    'suite_id' : suite_id,
                    'project_id' : project_id,
                    'node_id' : node_id,
                    'node_type' : node_type
                    },
                    function (data, textStatus, jqXHR) {
                        e.preventDefault();

                        // Iterate over the executed test cases
                        testNames = $('.testcasename');
                        match_count = 0;
                        testNames.each(function (index, value) {
                            tdElement = $(this);
                            testcasename = $(this).text();

                            // Set the qTest status for the executed test cases
                            if(data.hasOwnProperty(testcasename)){
                                match_count += 1
                                qtest_teststatus = data[testcasename]['status']
                                qtest_testid = data[testcasename]['id']
                                tdElement.siblings('.col-qteststatus').text(qtest_teststatus);
                                tdElement.siblings('.col-qteststatus').attr('id', qtest_testid);
                            }

                        });
                    }
                );

                $('#dvLoading').fadeOut(1000);
                //$("#none").addClass('active').siblings().removeClass('active');
            },
            error: function(data) {
                console.log(data);
                console.log("Error" + data['responseText']);
                show_alert('danger', 'Error: '+ data['responseText']);
                
                $('#dvLoading').fadeOut(1000);
            },
        });

    });

    function disable_matched_buttons(state){
        $('#matched-test').prop("disabled", state);
        $('#all-test').prop("disabled", state);       
    }

    function unset_test_suite_name(){
        $('.selected-testsuite').val("");
        $('.selected-testsuite').removeAttr('name');
        $('.selected-testsuite').removeAttr('id');
        $('.selected-testsuite').css('border', '1px solid red');
        $('.selected-testsuite').css('background-color', '');
        $('.selected-testsuite').css('color', 'red !important');
        $('.selected-testsuite').css('text-align', 'center');
    }

    function set_test_suite_name(node_name, node_id){
        $('.selected-testsuite').val(node_name);
        $('.selected-testsuite').attr('name', node_name);
        $('.selected-testsuite').attr('id', node_id);
        $('.selected-testsuite').css('border', '1px solid green');
        $('.selected-testsuite').css('background-color', '#dff0d8');
        $('.selected-testsuite').css('text-align', 'center');
    }

    function show_all_tests(){
        var collection = $('.col-qteststatus');
        collection.each(function() {
            row = $(this).parent();
            row.show();
        });
    }

    function show_all_tests_with_qtest_status_empty(){
        var collection = $('.col-qteststatus');
        collection.each(function() {
            $(this).empty();
            $(this).removeAttr('id');
            row = $(this).parent();
            row.show();
        });
    }

    function hide_non_matched_tests(){
        var collection = $('.col-qteststatus:empty');
        collection.each(function() {
            row = $(this).parent();
            row.hide();
        });
    }

    function disable_selection_buttons(state){
        $('#passed').prop("disabled", state);
        $('#failed').prop("disabled", state);
        $('#all').prop("disabled", state);
        $('#none').prop("disabled", state);

        $('#update-results').prop("disabled", state);        
    }

    function show_selected_test_msg(executed, matched) {

        var msg = matched + ' testcases matched in qTest out of ' + executed;

        // $(".alert").text(msg);
        // $("#match-alert").removeClass('alert-success');
        // $("#match-alert").removeClass('alert-danger');
        // $("#match-alert").removeClass('alert-warning');

        if (matched == executed){
            //$("#match-alert").addClass('alert-success');
            show_alert('success', msg)
        } else if (matched == 0){
            //$("#match-alert").addClass('alert-danger');
            show_alert('danger', msg)
        } else if (matched < executed){
             //$("#match-alert").addClass('alert-warning');
             show_alert('warning', msg)
        }

        // $("#match-alert").fadeTo(3000, 1000).slideUp(1000, function() {
        //     $("#match-alert").slideUp(500);
        // });

    }

    function show_alert(type, msg) { 
        $(".alert").text(msg);
        $("#match-alert").removeClass('alert-success');
        $("#match-alert").removeClass('alert-danger');
        $("#match-alert").removeClass('alert-warning');
        $("#match-alert").addClass('alert-' + type);
        $("#match-alert").fadeTo(3000, 1000).slideUp(1000, function() {
            $("#match-alert").slideUp(5100);
        });       
  
    }

    function customMenu(node)
    {
        var items = {
            release : {
                'icon' : '/static/img/release.png',
                'label' : 'New Release',
                'action' : function () {
                    set_modal_header("Release", "release")
                    show_modal()
                }
            },
            cycle : {
                'icon' : '/static/img/cycle.png',
                'label' : 'New Test Cycle',
                'action' : function () {
                    set_modal_header("Test Cycle", "cycle")
                    show_modal()
                }
            },
            suite : {
                'icon' : '/static/img/suite.png',
                'label' : 'New Test Suite',
                'action' : function () {
                    set_modal_header("Test Suite", "suite")
                    show_modal()
               }
            }
        }

        //console.log(node.data.type);
        if ((node.data.type === 'release') || (node.data.type === 'test-cycle' )) {
            delete items.release;
        } else if (node.data.type === 'test-suite' ) {
            delete items.release;
            delete items.cycle;
            delete items.suite;
        }  
        return items;
    }
   
    $('#qTestCreateEntity').click(function (e) {
        e.preventDefault();
        
        var node = $("#qtest-tree").jstree("get_selected", true)[0]
 
        data = {
            entity_type : $("#qTestModalEntityTitle").attr('type'),
            entity_name : $("#entity-name").val(),
            project_id : (node.data.project === undefined) ? node.id : node.data.project,
            node_id : node.id,
            node_type : node.data.type
        };
 
        $('#qTestModalEntity').modal('hide') 

        $.ajax({
            url: "/create_qtest_entity",
            method: "POST",
            data: data,
            success: function (response) {
                if (data.node_type === "project"){
                    $('#qtest-tree').jstree(true).refresh();
                } else {
                    $('#qtest-tree').jstree(true).refresh_node(data.node_id)
                }
            },
            error: function(response) {
                console.log("Error" + response['responseText']);
                $('#dvLoading').fadeOut(500);
            },
        });


        
    }); 

    $('#qTestModalEntity').on('hidden.bs.modal', function () {
        $(this).find('form').trigger('reset');
    })

    function disable_update_button(state){
        $('#update-results').prop("disabled", state);
    }

    function disable_upload_button(state){
        $('#upload-results').prop("disabled", state);
    }

    function set_modal_header(title, type){
        console.log(title)
        $("#qTestModalEntityTitle").text("Create " + title);
        $("#qTestModalEntityTitle").attr('type', type);
      
    }

    function show_modal(){
        $('#qTestModalEntity').find('form').trigger('reset');
        $('#qTestModalEntity').modal('show')  
    }

});


