$(document).ready(function () {

    $("#org").selectpicker();
    $("#product").selectpicker();
    $("#sub-product").selectpicker();
    $("#suite-name").selectpicker();
    
    $('#testcase-history-table').DataTable({
        //order: [[0, "desc"]],
        lengthMenu: [[ -1, 25, 50, 100], ["All", 25, 50, 100]],
        pagingType: "full_numbers"
    });   

    function load_products(id) {
        $.ajax({
            url: "/get_products_for_given_org_id",
            method: "POST",
            data: { org_id: id },
            dataType: "json",
            success: function (data) {
                var html = "";
                html += "<option hidden >Hidden</option>";
                $.each(data, function(index, product) {
                    if (product.id !== 0) {
                        html += '<option value="' + product.id + '">' + product.name + "</option>";
                    }
                });

                $("#product").html(html);
                $("#product").selectpicker("refresh");
            },
        });
    }

    function load_sub_products(org_id, product_id) {
        $.ajax({
            url: "/get_sproducts_for_given_prod_id",
            method: "POST",
            data: { org_id: org_id,  product_id: product_id},
            dataType: "json",
            success: function (data) { //alert(category_id)
                var html = "";
                html += "<option hidden >Hidden</option>";
                $.each(data, function(index, sub_product) {
                    if (sub_product.id !== 0) {
                        html += '<option value="' + sub_product.id + '">' + sub_product.name + "</option>";
                    }
                });
                $("#sub-product").html(html);
                $("#sub-product").selectpicker("refresh");

            },
        });
    }

    function load_suites(org_id, product_id, sub_product_id) {
        $.ajax({
            url: "/get_suites_for_given_sprod_id",
            method: "POST",
            data: { org_id: org_id,  product_id: product_id, sub_product_id: sub_product_id},
            dataType: "json",
            success: function (data) { //alert(category_id)
                var html = "";
                html += "<option hidden >Hidden</option>";
                $.each(data, function(index, suite) {
                    html += '<option value="' + suite.name + '">' + suite.name + "</option>";
                });
                $("#suite-name").html(html);
                $("#suite-name").selectpicker("refresh");
            },
        });
    }

    $(document).on("change", "#org", function () {
        var org_id = $("#org").val();
        load_products(org_id);
        //load_sub_products(0, 0);

    });

    $(document).on("change", "#product", function () {
        var org_id = $("#org").val();
        var product_id = $("#product").val();
        load_sub_products(org_id, product_id);
    });

    $(document).on("change", "#sub-product", function () {
        var org_id = $("#org").val();
        var product_id = $("#product").val();
        var sub_product_id = $("#sub-product").val();
        load_suites(org_id, product_id, sub_product_id);
    });

    $('#filter-form-testcases').submit(function (event) {

        event.preventDefault();
        data = {
				org_id : $("#org").val(),
				product_id : $("#product").val(),
				sub_product_id : $("#sub-product").val(),
                suite : $('#suite-name').find('option:selected').text()
			};

        if ((data.suite == "") || (data.suite == "Hidden")){
            show_alert();
            $('#testcase-history-content').css('display', 'none');
            return false;       
        }

        $('#dvLoading').fadeIn(300);
        $.ajax({
            url: "/get_testcases_history",
            method: "POST",
            data: data,
            success: function (response) {
                $('#testcase-history-content').removeAttr('style');
                
                // Convert UTC date format to local timezone
                capturingRegex = /<span id="executed-date">(.*?)<\/span>/g
                founds = [...response.matchAll(capturingRegex)];

                founds.forEach(function (item, index) {
                    local = moment.utc(item[1]).local().format('DD-MM-YYYY HH:mm:ss')
                    response = response.replace('<span id="executed-date">' + item[1] + '</span>', '<span id="executed-date">' + local + '</span>')
                }); 

                $('#testcase-history-content').html(response);
                $('#dvLoading').fadeOut(500);
                $('#testcase-history-table').DataTable({
                    //order: [[0, "desc"]],
                    scrollY: 500,
                    scrollX: true,
                    scrollCollapse: true,
                    fixedColumns:   {
                        left: 1
                    },
                    lengthMenu: [[ -1, 25, 50, 100], ["All", 25, 50, 100]],
                    "pagingType": "full_numbers",
                    "destroy": true,
                });
            },
            error: function(response) {
                console.log("Error" + response['responseText']);
                $('#dvLoading').fadeOut(500);
            },
        });
     });

     $(document).on("click", ".view-testcases", function(){
        id = $(this).attr('id');
        var url = location.protocol + '//' + location.host + '/get_testcase_execution?suite_id='+ id;
        var myWindow = window.open();
        myWindow.location.href = url;
    });     
    
    function show_alert(){
        $(".alert").toggleClass('hide show'); 
        $(".alert").fadeTo(2000, 800).slideUp(800, function() {
            $("#match-alert").slideUp(3000);
        }); 
        return false; // Keep close.bs.alert event from removing from DOM
    }
    
    $('#bsalert').on('close.bs.alert', show_alert)

});


