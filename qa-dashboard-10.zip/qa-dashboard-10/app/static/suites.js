$(document).ready(function () {

    $('#suite-execution').DataTable({
        order: [[0, "desc"]],
        lengthMenu: [[25, 50, 100, -1], [25, 50, 100, "All"]],
        pagingType: "full_numbers",
        createdRow: function (row, data, index) {
            utcDate = $('.date', row).text()
            $('.date', row).text(moment.utc(utcDate).local().format('DD-MM-YYYY HH:mm:ss'))
        }
    });

    $('#filter-form').submit(function (event) {

        event.preventDefault();

        start_date_obj = new Date($("#start_date").val());
        end_date_obj = new Date($("#end_date").val());

        if(start_date_obj > end_date_obj){
            alert('Start Date cannot be greater than End Date');
            return false;
        }
        console.log(new moment($("#start_date").val() + "T00:01:01", "YYYY-MM-DDTHH:mm:ss").utc().format())
        console.log(new moment($("#end_date").val() + "T23:59:59", "YYYY-MM-DDTHH:mm:ss").utc().format())
        data = {
				org_id : $("#org").val(),
				product_id : $("#product").val(),
				sub_product_id : $("#sub-product").val(),
                release_name: $('#release').find('option:selected').text(),
                build: $('#build').find('option:selected').text(),
				environment_name : $('#environment').find('option:selected').text(),
				test_type_name : $('#test-type').find('option:selected').text(),
                start_date: new moment($("#start_date").val() + "T00:01:01", "YYYY-MM-DDTHH:mm:ss").utc().format(),
                end_date: new moment($("#end_date").val() + "T23:59:59", "YYYY-MM-DDTHH:mm:ss").utc().format()
                //timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
			};
        console.log(data)
        $('#dvLoading').fadeIn(300);
        $.ajax({
            url: "/get_suite_execution",
            method: "POST",
            data: data,
            success: function (response) {
                $('.suite-execution-content').html(response);
                $('#dvLoading').fadeOut(500);
                $('#suite-execution').DataTable({
                    order: [[0, "desc"]],
                    "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
                    "pagingType": "full_numbers",
                    "destroy": true,
                    createdRow: function (row, data, index) {
                        utcDate = $('.date', row).text()
                        $('.date', row).text(moment.utc(utcDate).local().format('DD-MM-YYYY HH:mm:ss'))
                    }
                });
            },
            error: function(response) {
                console.log("Error" + response['responseText']);
                $('#dvLoading').fadeOut(500);
            },
        });
     });

    //$("#suite-execution").on("click", ".view-testcases", function(){
    $(document).on("click", ".view-testcases", function(){
        id = $(this).attr('id');
        var url = location.protocol + '//' + location.host + '/get_testcase_execution?suite_id='+ id;
        var myWindow = window.open();
        myWindow.location.href = url;
    });

    //$("#suite-execution").on("click", ".update-qtest", function(){
    $(document).on("click", ".update-qtest", function(){
        id = $(this).attr('id');
        var url = location.protocol + '//' + location.host +
        '/update_qtest?suite_id='+ id;
        var myWindow = window.open();
        myWindow.location.href = url;
    });

    // Set Start date and end date in client timezone
    start_date = $('#start_date').attr('datetime');
    end_date = $('#end_date').attr('datetime');

    //console.log(moment.tz.guess()) -> Timezone found Australia/Sydney from the Intl api, but did not have that data loaded.
    //console.log(Intl.DateTimeFormat().resolvedOptions().timeZone) //-> Australia/Sydney

    $('#start_date').val(moment.utc(start_date).local().format('YYYY-MM-DD'));
    $('#end_date').val(moment.utc(end_date).local().format('YYYY-MM-DD'));
});


