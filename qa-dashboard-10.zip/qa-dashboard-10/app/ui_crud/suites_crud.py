from datetime import datetime
from sqlalchemy.orm import Session
from app.common.data import SUITE_HEADER, TESTCASE_HEADER
from app.db import models
from app.db.queries import get_suite_data_by_all_filters_query, \
    get_suite_data_by_suite_id_query, get_mapping_by_all_ids_query, \
    get_testclass_wise_report_by_suite_id_query, get_testcases_by_filters_query

# View/Routes Methods
from app.schemas import req_schemas
from app.ui_crud.common import get_orgs, get_products_for_given_org_id, \
    get_sub_products_for_given_product_id, get_environments, get_test_types, \
    get_ops_by_name, time_format, get_testcase_execution_by_suite_id, \
    get_releases_for_ops, get_testcase_execution_by_filters


def get_search_filter_vals_by_id(org_id, product_id, sub_product_id,
                                 db: Session):
    orgs = get_orgs(db)
    products = get_products_for_given_org_id(org_id, db)
    sub_products = get_sub_products_for_given_product_id(org_id, product_id,
                                                         db)

    releases = get_releases_for_ops(org_id, product_id, sub_product_id, db)
    # builds = get_builds_for_ops(org_id, product_id, sub_product_id,
    # release_name, db)
    builds = [{"id": 0, "name": "ALL"}]

    environments = get_environments(db)
    test_types = get_test_types(db)

    return (orgs, products, sub_products, releases, builds,
            environments, test_types)


def get_search_filter_vals_by_name(org_name, product_name, sub_product_name,
                                   db: Session):
    org, product, sub_product = get_ops_by_name(org_name, product_name,
                                                sub_product_name, db)

    return get_search_filter_vals_by_id(org.id, product.id, sub_product.id, db)


def get_suite_execution(org_id, product_id, sub_product_id, release_name,
                        build, environment_name, test_type_name,
                        start_date, end_date, db: Session):
    suite_results = get_suite_execution_for_given_search_filters(
        org_id, product_id, sub_product_id, release_name, build,
        environment_name, test_type_name, start_date, end_date, db)

    if suite_results:
        header = [column.capitalize() for column in suite_results[0].keys()]
    else:
        header = SUITE_HEADER

    return header, suite_results


def get_suite_testcase_execution_by_suite_id(suite_id, db: Session):
    suite_result = get_suite_execution_by_id(suite_id, db)
    testcase_results = get_testcase_execution_by_suite_id(suite_id, db)

    if suite_result:
        suite_header = [column.capitalize() for column in suite_result.keys()]
    else:
        suite_header = SUITE_HEADER

    if testcase_results:
        testcase_header = [column.capitalize() for column in
                           testcase_results[0].keys()]
    else:
        testcase_header = TESTCASE_HEADER

    return suite_header, suite_result, testcase_header, testcase_results


def get_testclass_wise_report_by_suite_id(suite_id, db: Session):
    # Creating TestClass Wise Table
    report_data = get_testclass_wise_report_by_suite_id_query(suite_id, db). \
        all()

    report = {}
    for data in report_data:
        test_class, status, count = data
        if test_class not in report:
            report[test_class] = {"PASSED": 0,
                                  "FAILED": 0,
                                  "SKIPPED": 0,
                                  "ERROR": 0,
                                  "TOTAL": 0}

        report[test_class][status] = count
        report[test_class]["TOTAL"] += count

    header = ["TestClass", "PASSED", "FAILED", "SKIPPED", "ERROR", "TOTAL"]
    return header, report


def get_testcase_execution_for_suite_by_test_class(suite_id, test_class,
                                                   db: Session):
    query_filters = {models.TestCase.suite_id: suite_id,
                     models.TestCase.testclass: test_class
                     }

    testcase_results = get_testcase_execution_by_filters(query_filters, db)

    if testcase_results:
        testcase_header = [column.capitalize() for column in
                           testcase_results[0].keys()]
    else:
        testcase_header = TESTCASE_HEADER

    return testcase_header, testcase_results


# Data Methods
def get_suite_execution_for_given_search_filters(org_id, product_id,
                                                 sub_product_id, release_name,
                                                 build, environment_name,
                                                 test_type_name, start_date,
                                                 end_date, db: Session):
    suite_data = get_suite_data_by_all_filters_query(org_id, product_id,
                                                     sub_product_id,
                                                     release_name, build,
                                                     environment_name,
                                                     test_type_name,
                                                     start_date, end_date,
                                                     db).all()

    table = []
    for suite, suite_mapping, org, product, sub_product in suite_data:
        # "Id", "Date", "Org", "Product", "SubProduct", "Status", "Total",
        # "Passed", "Failed", "Environment", "Type", "Logs"

        logs = {
            "report": suite.report_url,
            "console": suite.console_url,
            "log": suite.log_url
        }

        stats = {
            "total": suite.total,
            "passed": suite.passed,
            "failed": suite.failed,
            "skipped": suite.skipped,
        }

        row = {
            "id": suite.id,
            # "date": datetime.strptime(str(suite.created),
            # "%Y-%d-%m %H:%M:%S"),
            # "date": str(suite.created).split(" ")[0],
            "date": str(suite.created),
            "org": org.name,
            "product": product.name,
            "subproduct": sub_product.name,
            "suite": suite_mapping.suite,
            "status": suite.status,
            "stats": stats,
            "release": suite_mapping.release,
            "build": suite.build,
            # "environment": suite_mapping.environment,
            # "type": suite_mapping.test_type,
            "logs": logs,
            "duration": time_format(suite.duration)
        }
        table.append(row)

    return table[::-1]


def get_suite_execution_by_id(suite_id, db: Session):
    suite, suite_mapping, org, product, sub_product = \
        get_suite_data_by_suite_id_query(suite_id, db).first()

    logs = {
        "report": suite.report_url,
        "console": suite.console_url,
        "log": suite.log_url
    }

    stats = {
        "total": suite.total,
        "passed": suite.passed,
        "failed": suite.failed,
        "skipped": suite.skipped,
    }

    suite_result = {
        "id": suite.id,
        "date": datetime.strftime(suite.created, "%Y-%m-%d %H:%M:%S"),
        "org": org.name,
        "product": product.name,
        "subproduct": sub_product.name,
        "release": suite_mapping.release,
        "branch": suite.branch,
        "build": suite.build,
        "suite": suite_mapping.suite,
        "status": suite.status,
        "stats": stats,
        "environment": suite_mapping.environment,
        "type": suite_mapping.test_type,
        "logs": logs,
        "duration": time_format(suite.duration),
        "infra": suite.infra
    }

    return suite_result
