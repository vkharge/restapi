from sqlalchemy.orm import Session
from app.common.data import DEFAULT_LIMIT
from app.db.models import SuiteMapping, Suite
from app.db.queries import get_all_suite_names_query, \
    get_suite_mapping_by_suite_name_query, \
    get_suite_data_by_suite_mapping_id_query, \
    get_suite_data_by_suite_mapping_ids_query


def get_all_suites_history(db: Session):

    orgs = []
    suite_mappings = get_all_executed_suite_mapping_ids(db)

    for entry in suite_mappings:
        suite_name = entry["suite_name"]
        suite_data = get_suite_data_by_suite_mapping_ids(entry["ids"], db)
        for suite, suite_mapping, org, product, sub_product in suite_data:

            # Check if org exist, if not add it
            org_dict = check_org(orgs, org.name)

            # Check if product exist, if not add it
            prod_dict = check_product(org_dict, product.name)

            # Check if sproduct exist, if not add it
            sprod_dict = check_sproduct(prod_dict, sub_product.name)

            # Check if suite exist, if not add it
            suite_dict = check_suite(org_dict, prod_dict, sprod_dict,
                                     suite_mapping.suite)

            # Check if suite history if not add it
            check_history(suite_dict, suite_mapping, suite)

    return orgs


# Data Methods
def get_all_executed_suite_names(db: Session):
    suite_names = get_all_suite_names_query(db).distinct()\
        .order_by(SuiteMapping.suite.asc()).all()

    return [suite[0] for suite in suite_names]


def get_all_executed_suite_mapping_ids(db: Session):
    suite_names = get_all_suite_names_query(db).distinct()\
        .order_by(SuiteMapping.suite.asc()).all()

    mapping_ids = []
    for suite in suite_names:
        suite_name = suite[0]
        suite_mapping_ids = get_suite_mapping_ids_by_suite_name(suite_name, db)
        mapping_ids.append({
            "suite_name": suite_name,
            "ids": suite_mapping_ids
        })

    return mapping_ids


def get_suite_mapping_ids_by_suite_name(suite_name, db: Session):
    suite_mappings = get_suite_mapping_by_suite_name_query(suite_name, db)\
        .order_by(SuiteMapping.id.desc()) \
        .limit(DEFAULT_LIMIT).all()

    return [suite_mapping.id for suite_mapping in suite_mappings]


def get_suite_data_by_suite_mapping_id(id, db: Session):
    suite_data = get_suite_data_by_suite_mapping_id_query(id, db)\
        .order_by(SuiteMapping.id.desc()) \
        .limit(DEFAULT_LIMIT).all()

    return suite_data


def get_suite_data_by_suite_mapping_ids(ids, db: Session):
    suite_data = get_suite_data_by_suite_mapping_ids_query(ids, db)\
        .order_by(Suite.id.desc()) \
        .limit(DEFAULT_LIMIT).all()

    return suite_data


def check_key_dict_list(key, value, dict_list):
    for dict in dict_list:
        if key in dict:
            if dict[key] == value:
                return dict
    return False


def check_org(orgs, org_name):

    org_dict = check_key_dict_list("name", org_name, orgs)
    if org_dict is False:
        org_dict = {
            "name": org_name,
            "suite_count": 0,
        }
        orgs.append(org_dict)

    return org_dict


def check_product(org_dict, prod_name):

    if "products" not in org_dict:
        org_dict["products"] = []

    products = org_dict["products"]
    prod_dict = check_key_dict_list("name", prod_name, products)
    if prod_dict is False:
        prod_dict = {
            "name": prod_name,
            "suite_count": 0,
        }
        products.append(prod_dict)

    return prod_dict


def check_sproduct(prod_dict, sprod_name):

    if "sproducts" not in prod_dict:
        prod_dict["sproducts"] = []

    sproducts = prod_dict["sproducts"]
    sprod_dict = check_key_dict_list("name", sprod_name, sproducts)
    if sprod_dict is False:
        sprod_dict = {
            "name": sprod_name,
            "suite_count": 0,
        }
        sproducts.append(sprod_dict)

    return sprod_dict


def check_suite(org_dict, prod_dict, sprod_dict, suite_name):
    if "suites" not in sprod_dict:
        sprod_dict["suites"] = []

    suites = sprod_dict["suites"]
    suite_dict = check_key_dict_list("name", suite_name, suites)
    if suite_dict is False:
        suite_dict = {
            "name": suite_name,
        }
        suites.append(suite_dict)
        org_dict["suite_count"] += 1
        prod_dict["suite_count"] += 1
        sprod_dict["suite_count"] += 1

    return suite_dict


def check_history(suite_dict, suite_mapping, suite):

    if "history" not in suite_dict:
        suite_dict["history"] = []

    history = suite_dict["history"]

    if len(history) <= DEFAULT_LIMIT:
        stats = {
            "total": suite.total,
            "passed": suite.passed,
            "failed": suite.failed,
            "skipped": suite.skipped,
        }

        suite_status = {
            "id": suite.id,
            "executed": suite.created,
            "build": suite.build,
            "status": suite.status,
            "stats": stats,
            "branch": suite.branch,
            "release": suite_mapping.release
        }
        history.append(suite_status)

    return history
