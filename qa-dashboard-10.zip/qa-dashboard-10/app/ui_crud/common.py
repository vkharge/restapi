from datetime import timedelta, datetime
from sqlalchemy.orm import Session

from app.common.data import DEFAULT_SEARCH_DATE_FMT, DEFAULT_SEARCH_DAYS
from app.db import models
from app.db.queries import get_orgs_query, get_org_by_name_query, \
    get_product_by_name_query, get_sub_product_by_name_query, \
    get_products_for_given_org_id_query, \
    get_sub_products_for_given_product_id_query, get_environments_query, \
    get_test_types_query, get_testcases_by_suite_id_query, \
    get_mapping_by_all_ids_query, get_releases_by_mapping_id_query, \
    get_suite_mapping_by_filters_query, \
    get_suite_by_filters_query, get_testcases_by_filters_query
from app.db.models import Org, Product, SubProduct, TestCase

# View/Routes Methods
from app.schemas import req_schemas


def get_ops_by_name(org_name, product_name, sub_product_name, db: Session):
    org = get_org_by_name(org_name, db)
    product = get_product_by_name(product_name, db)
    sub_product = get_sub_product_by_name(sub_product_name, db)

    return org, product, sub_product


# Data Methods
def get_orgs(db: Session, add_all_option=True):
    orgs = get_orgs_query(db).all()
    orgs = [{"id": org.id, "name": org.name} for org in orgs]
    if add_all_option:
        orgs.insert(0, {"id": 0, "name": "ALL"})
    return orgs


def get_org_by_name(org_name, db: Session):
    if org_name == "ALL":
        return Org(id=0, name="ALL")
    return get_org_by_name_query(org_name, db).first()


def get_product_by_name(product_name, db: Session):
    if product_name == "ALL":
        return Product(id=0, name="ALL")

    return get_product_by_name_query(product_name, db).first()


def get_sub_product_by_name(sub_product_name, db: Session):
    if sub_product_name == "ALL":
        return SubProduct(id=0, name="ALL")
    return get_sub_product_by_name_query(sub_product_name, db).first()


def get_products_for_given_org_id(org_id, db: Session, add_all_option=True):
    products = get_products_for_given_org_id_query(org_id, db).distinct().all()
    products = [{"id": product.id, "name": product.name} for product in
                products]
    if add_all_option:
        products.insert(0, {"id": 0, "name": "ALL"})
    return products


def get_sub_products_for_given_product_id(org_id, product_id, db: Session,
                                          add_all_option=True):
    sub_products = get_sub_products_for_given_product_id_query(
        org_id, product_id, db).distinct().all()
    sub_products = [{"id": sub_product.id, "name": sub_product.name} for
                    sub_product in sub_products]
    if add_all_option:
        sub_products.insert(0, {"id": 0, "name": "ALL"})
    return sub_products


def get_releases_for_ops(org_id, product_id, sub_product_id, db: Session,
                         add_all_option=True):
    releases = []
    ops = req_schemas.MappingID(org_id=org_id, product_id=product_id,
                                sub_product_id=sub_product_id)
    mapping = get_mapping_by_all_ids_query(ops, db).first()

    if mapping:
        mappings = get_releases_by_mapping_id_query(mapping.id, db) \
            .distinct().all()
        releases = [{"id": index + 1, "name": release[0]}
                    for index, release in enumerate(mappings)]

    if add_all_option:
        releases.insert(0, {"id": 0, "name": "ALL"})
    return releases


def get_builds_for_ops(org_id, product_id, sub_product_id, release_name,
                       db: Session, add_all_option=True):
    builds = []

    ops = req_schemas.MappingID(org_id=org_id, product_id=product_id,
                                sub_product_id=sub_product_id)
    mapping = get_mapping_by_all_ids_query(ops, db).distinct().first()

    if mapping:
        # get suite id for the mapping id and releases
        query_filters = {
            "mapping_id": mapping.id,
            "release": release_name
        }
        data_filters = ["id"]
        suite_mappings = get_suite_mapping_by_filters_query(
            data_filters, query_filters, db, raise_exception=False)\
            .distinct().all()

        # Get builds based on the suite id
        builds_set = set()
        for suite_mapping in suite_mappings:
            query_filters = {
                "suite_mapping_id": suite_mapping[0],
            }
            data_filters = ["build"]

            builds_data = get_suite_by_filters_query(data_filters,
                                                     query_filters, db,
                                                     raise_exception=False) \
                .distinct().all()

            for build_data in builds_data:
                builds_set.add(build_data[0])

        for index, item in enumerate(builds_set):
            builds.append({"id": index + 1, "name": item})

    if add_all_option:
        builds.insert(0, {"id": 0, "name": "ALL"})

    return builds


def get_environments(db: Session):
    envirs = get_environments_query(db).all()
    environments = [{"id": env.id, "name": env.name} for env in envirs]
    environments.insert(0, {"id": 0, "name": "ALL"})
    return environments


def get_test_types(db: Session):
    test_types = get_test_types_query(db).all()
    test_types = [{"id": test_type.id, "name": test_type.name} for test_type in
                  test_types]
    test_types.insert(0, {"id": 0, "name": "ALL"})
    return test_types


def time_format(time: float):
    td = timedelta(seconds=time)
    seconds = td.seconds
    ms = int(str(td.microseconds)[:3])

    d = seconds // (3600 * 24)
    h = seconds // 3600 % 24
    m = seconds % 3600 // 60
    s = seconds % 3600 % 60
    if d > 0:
        return '{}D {}H {}m {}s {}ms'.format(d, h, m, s, ms)
    elif h > 0:
        return '{}H {}m {}s {}ms'.format(h, m, s, ms)
    elif m > 0:
        return '{}m {}s {}ms'.format(m, s, ms)
    elif s > 0:
        return '{}s {}ms'.format(s, ms)
    elif ms > 0:
        return '{}ms'.format(ms)
    else:
        return '-'


def get_dates():
    end_date = datetime.utcnow().strftime(DEFAULT_SEARCH_DATE_FMT)
    start_date = (datetime.utcnow() - timedelta(days=DEFAULT_SEARCH_DAYS)) \
        .strftime(DEFAULT_SEARCH_DATE_FMT)

    return start_date, end_date


# Test Cases
def get_testcase_execution_by_suite_id(suite_id, db: Session):
    testcases = get_testcases_by_suite_id_query(suite_id, db) \
        .order_by(TestCase.testno).all()

    testcase_results = []
    for testcase in testcases:
        test = {
            "testno": testcase.testno,
            "testclass": testcase.testclass,
            "testname": testcase.testname,
            "status": testcase.status,
            "duration": time_format(testcase.duration),
            "message": testcase.message,
        }

        testcase_results.append(test)
    return testcase_results


def get_testcase_execution_by_filters(query_filters, db: Session):
    data_filters = [models.TestCase]

    testcases = get_testcases_by_filters_query(
        data_filters, query_filters, db).order_by(TestCase.testno).all()

    testcase_results = []
    for testcase in testcases:
        test = {
            "testno": testcase.testno,
            "testclass": testcase.testclass,
            "testname": testcase.testname,
            "status": testcase.status,
            "duration": time_format(testcase.duration),
            "message": testcase.message,
        }

        testcase_results.append(test)
    return testcase_results
