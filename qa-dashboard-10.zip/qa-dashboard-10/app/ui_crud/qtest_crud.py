import concurrent
from concurrent import futures
from app.common.data import QTEST_PROJECTS
import pytz
from datetime import datetime


# View/Routes Methods
def get_qtest_project_details(tms, product, sub_product):
    token, name = get_qtest_login(product, sub_product)
    project = get_qtest_project(tms, token, name)
    return project


def get_qtest_tree_structure(tms, token, project_id, entity_type=None,
                             entity_id=None):
    entities = []

    if entity_type == 'project':

        if entity_id is None:
            entity_id = project_id

        releases = get_qtest_releases(tms, token, project_id)
        entities.extend(releases)

        cycles = get_qtest_build_cycles(tms, token, project_id)
        entities.extend(cycles)

        suites = get_qtest_test_suites(tms, token, project_id, "root",
                                       entity_id)
        entities.extend(suites)

    elif entity_type == 'release' or entity_type == 'test-cycle':
        cycles = get_qtest_build_cycles(tms, token, project_id, entity_type,
                                        entity_id)
        entities.extend(cycles)
        print(cycles)
        suites = get_qtest_test_suites(tms, token, project_id, entity_type,
                                       entity_id)
        entities.extend(suites)
        print(suites)
    elif entity_type == 'test-suite':
        pass

    return entities


def get_qtest_testcases_data(tms, token, project_id, entity_type, entity_id):

    entities = get_qtest_test_cases(tms, token, project_id, entity_type,
                                    entity_id)
    return entities


def update_qtest_test_log_status1(tms, token, project_id, tests):

    success = 0
    for test in tests:

        if test.status.lower() in ["passed", "pass"]:
            status = "pass"
        elif test.status.lower() in ["failed", "fail"]:
            status = "fail"
        elif test.status.lower() in ["skipped", "skipp"]:
            continue

        r = tms.create_test_log(token, project_id, test.id, status)
        if r or "status" in r:
            qtest_status = r["status"]["name"]
            if qtest_status.lower() == status + "ed":
                success += 1

    return success


def update_qtest_test_log_status(tms, token, project_id, tests):
    success = 0

    with concurrent.futures.ThreadPoolExecutor(max_workers=25) as executor:

        futures = []
        results = []

        for test in tests:

            if test.status.lower() in ["passed", "pass"]:
                status = "pass"
            elif test.status.lower() in ["failed", "fail"]:
                status = "fail"
            elif test.status.lower() in ["skipped", "skipp"]:
                continue

            # r = tms.create_test_log(token, project_id, test.id, status)
            futures.append(
                executor.submit(
                    tms.create_test_log, token, project_id, test.id, status))

        for future in concurrent.futures.as_completed(futures):
            r = future.result()
            if r or "status" in r:
                qtest_status = r["status"]["name"]
                if qtest_status.lower() in ["passed", "failed"]:
                    success += 1

    return success


def upload_tests_in_qtest(tms, token, suite, results):

    batch_payload = constuct_qtest_batch_test_logs(suite, results)
    tms._token = token
    tms.run_batch(results.project_id, batch_payload)
    status = tms.poll_batch()

    if status:
        return len(results.tests)

    return -1


def create_qtest_objects(tms, token, entity_type, entity_name, project_id,
                         node_id, node_type, db):

    if entity_type.lower() == "release":
        tms.create_release(token, str(project_id), entity_name)
    elif entity_type.lower() == "cycle":
        tms.create_build_cycle(token, str(project_id), entity_name,
                               str(node_id), node_type)
    elif entity_type.lower() == "suite":
        tms.create_test_suite(token, str(project_id), entity_name,
                              tsdesc="Created By Dashboard - IP",
                              parent_id=str(node_id), parent_type=node_type)

    return True


# Data Methods

def get_qtest_login(product, sub_product):
    if sub_product in QTEST_PROJECTS:
        details = QTEST_PROJECTS.get(sub_product)
    elif product in QTEST_PROJECTS:
        details = QTEST_PROJECTS.get(product)

    name = details.get("name")
    token = details.get("token")

    return token, name


def get_qtest_project(tms, token, name):
    project = tms.get_project_by_name(token, name)
    element = {'type': 'project', 'id': project.id, 'parentId': 0,
               'name': project.name, 'status': '', 'projectId': project.id}

    return element


def get_qtest_releases(tms, token, project_id):
    releases = tms.get_releases(token, project_id)
    entities = []
    if releases:
        for release in releases:
            element = {'type': 'release', 'id': release.id,
                       'parentId': project_id,
                       'name': release.name, 'status': '',
                       'projectId': project_id}
            entities.append(element)

    return entities[::-1]


def get_qtest_build_cycles(tms, token, project_id, entity_type=None,
                           entity_id=None):

    if entity_id is None:
        entity_id = project_id

    if entity_type:
        test_cycles = tms.get_build_cycles(token, project_id, entity_id,
                                           entity_type)
    else:
        test_cycles = tms.get_build_cycles(token, project_id)

    entities = []
    if test_cycles:
        for test_cycle in test_cycles:
            element = {'type': 'test-cycle', 'id': test_cycle.id,
                       'parentId': entity_id, 'name': test_cycle.name,
                       'status': '', 'projectId': project_id}
            entities.append(element)

    return entities


def get_qtest_test_suites(tms, token, project_id, entity_type, entity_id):
    test_suites = tms.get_test_suites(token, project_id, str(entity_id),
                                      entity_type)
    entities = []
    if test_suites:
        for test_suite in test_suites:
            element = {'type': 'test-suite', 'id': test_suite.id,
                       'parentId': entity_id,
                       'name': test_suite.name,
                       'status': '', 'projectId': project_id}
            entities.append(element)

    return entities


def get_qtest_test_cases(tms, token, project_id, entity_type, entity_id):

    test_cases = tms.get_test_runs(token, int(project_id), int(entity_id),
                                   entity_type)
    entities = {}
    if test_cases:
        for test_case in test_cases:
            element = {'type': 'test-case',
                       'id': test_case.id,
                       'parentId': entity_id,
                       'name': test_case.name,
                       'status': test_case.status,
                       'bug': 'DOS-1111',
                       'projectId': project_id}
            entities[test_case.name] = element

    return entities


def constuct_qtest_batch_test_logs(suite, results):

    payload = {
        "test_cycle": results.node_id,
    }
    test_logs = []

    for test in results.tests:
        status = get_formatted_test_status(test.status)

        if status == "UNKNOWN":
            continue

        exe_date = datetime.now(pytz.timezone("UTC"))
        modules = [f"{suite['subproduct']}-Automated-Tests"]

        if test.classname != "":
            modules.append(test.classname)
        else:
            modules.append(suite['suite'])

        test_log = {
            "name": test.name,
            "status": status,
            "exe_start_date": exe_date.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "exe_end_date": exe_date.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "module_names": modules,
            "automation_content": f"{suite['product']} -> "
                                  f"{suite['subproduct']} -> "
                                  f"{test.classname} -> {test.name}"
        }

        test_logs.append(test_log)

    payload["test_logs"] = test_logs

    return payload


def get_formatted_test_status(status):

    if status.lower() in ["passed", "pass"]:
        formatted_status = "PASS"
    elif status.lower() in ["failed", "fail"]:
        formatted_status = "FAIL"
    else:
        formatted_status = "UNKNOWN"

    return formatted_status
