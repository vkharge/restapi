from collections import OrderedDict

from sqlalchemy.orm import Session

from app.common.data import DEFAULT_LIMIT
from app.db.queries import get_mapping_by_all_ids_query,\
    get_suites_by_mapping_id_query, \
    get_suite_data_by_suite_name_query
from app.db.models import Suite
from app.schemas import req_schemas
from app.ui_crud.common import get_orgs, get_products_for_given_org_id, \
    get_sub_products_for_given_product_id, \
    get_testcase_execution_by_suite_id


# View/Routes Methods
def get_testcases_search_filter_vals_by_id(org_id, product_id, sub_product_id,
                                           db: Session):
    orgs = get_orgs(db, add_all_option=False)

    products = get_products_for_given_org_id(org_id, db, add_all_option=False)

    if product_id == 0 and len(products) > 0:
        product_id = products[0]["id"]

    sub_products = get_sub_products_for_given_product_id(
        org_id, product_id, db, add_all_option=False)

    if sub_product_id == 0 and len(sub_products) > 0:
        sub_product_id = sub_products[0]["id"]

    suites = get_executed_suites_name(org_id, product_id, sub_product_id, db)

    return orgs, products, sub_products, suites


def get_testcases_history(org_id, product_id, sub_product_id, suite,
                          db: Session):
    header = []
    testcases = OrderedDict()

    # Get the Suite ID and details list based on Suite Mapping ID List
    suites_result = get_suite_data_by_suite_name(org_id, product_id,
                                                 sub_product_id, suite, db)

    no_of_suites = len(suites_result)
    index = 0
    for suite, suite_mapping, org, product, sub_product in suites_result:

        stats = {
            "total": suite.total,
            "passed": suite.passed,
            "failed": suite.failed,
            "skipped": suite.skipped,
        }

        header.append({
            "id": suite.id,
            "executed": suite.created,
            "build": suite.build,
            "status": suite.status,
            "stats": stats,
            "branch": suite.branch,
            "release": suite_mapping.release
        })

        # Get the Test Case Details based on the suite id
        testcase_results = get_testcase_execution_by_suite_id(suite.id, db)

        for testcase in testcase_results:
            testclass = testcase["testclass"]
            name = testcase["testname"]
            status = testcase["status"]

            if (testclass, name) in testcases:
                row = testcases[(testclass, name)]
            else:
                row = [''] * no_of_suites

            row[index] = status
            testcases[(testclass, name)] = row

        index += 1

    return header, testcases


# Data Methods
def get_executed_suites_name(org_id, product_id, sub_product_id, db: Session):
    # Get mapping id based on the org_id, product_id, sub_product_id
    mapping = req_schemas.MappingID(org_id=org_id, product_id=product_id,
                                    sub_product_id=sub_product_id)
    mapping_id = get_mapping_by_all_ids_query(mapping, db).first().id

    # Get suite names based on mapping id
    suites = get_suites_by_mapping_id_query(mapping_id, db, False)\
        .distinct().all()
    suites_name = [{"name": suite[0]} for suite in suites]
    return suites_name


def get_suite_data_by_suite_name(org_id, product_id, sub_product_id,
                                 suite, db):
    data = get_suite_data_by_suite_name_query(
        org_id, product_id, sub_product_id, suite, db) \
        .order_by(Suite.created.desc()) \
        .limit(DEFAULT_LIMIT).all()

    return data
