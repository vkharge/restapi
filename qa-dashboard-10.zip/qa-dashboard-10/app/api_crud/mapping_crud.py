from sqlalchemy.orm import Session

from app.common.exceptions import CannotDelete, DuplicateEntity
from app.db.queries import create_mapping_query,\
    get_mapping_by_all_ids_query, \
    get_mappings_data_query, get_mapping_data_by_id_query, \
    get_suite_mapping_by_mapping_id_query, get_mapping_by_id_query, \
    get_org_by_name_query, get_product_by_name_query, \
    get_sub_product_by_name_query

from app.api_crud.org_crud import create_org
from app.api_crud.product_crud import create_product
from app.api_crud.sub_product_crud import create_sub_product
from app.schemas import req_schemas
from app.schemas.req_schemas import MappingID


def create_mapping(payload: req_schemas.Mapping, db: Session):

    org_id = get_org_id(payload, db)
    product_id = get_product_id(payload, db)
    sub_product_id = get_sub_product_id(payload, db)

    mapping_payload = MappingID(org_id=org_id, product_id=product_id,
                                sub_product_id=sub_product_id)
    mapping = get_mapping_by_all_ids_query(mapping_payload, db).first()
    if not mapping:
        mapping = create_mapping_query(mapping_payload, db)

    return mapping


def get_mappings(db: Session):

    mappings_data = get_mappings_data_query(db).all()

    mapping_result = []
    for mapping_data in mappings_data:
        result = construct_mapping_entry(*mapping_data)
        mapping_result.append(result)

    return {"count": len(mapping_result), "mappings": mapping_result}


def get_mapping(mapping_id: int, db: Session):

    mapping_data = get_mapping_data_by_id_query(mapping_id, db).first()

    return construct_mapping_entry(*mapping_data)


def delete_mapping(mapping_id: int, db: Session):

    suite_mapping = get_suite_mapping_by_mapping_id_query(mapping_id, db,
                                                          False)

    if suite_mapping.first():
        raise CannotDelete(f"Cannot delete mapping id {mapping_id}")

    mapping = get_mapping_by_id_query(mapping_id, db)
    mapping.delete(synchronize_session=False)
    db.commit()

    return


def update_mapping(mapping_id: int, payload: req_schemas.Mapping, db: Session):
    mapping = get_mapping_by_id_query(mapping_id, db)

    org_id = get_org_id(payload, db)
    product_id = get_product_id(payload, db)
    sub_product_id = get_sub_product_id(payload, db)

    mapping_payload = MappingID(org_id=org_id, product_id=product_id,
                                sub_product_id=sub_product_id)
    if get_mapping_by_all_ids_query(mapping_payload, db).first():
        raise DuplicateEntity(f"Mapping entry with org_name={payload.org}, "
                              f"product_name={payload.product},"
                              f"sub_product_name={payload.sub_product} "
                              f"already exists")
    else:
        mapping.update(mapping_payload.dict())
        db.commit()
        return mapping.first()


def get_org_id(payload: req_schemas.Mapping, db: Session):
    org = get_org_by_name_query(payload.org, db, raise_exception=False).\
        first()

    if not org:
        org_payload = req_schemas.Org(name=payload.org)
        org = create_org(org_payload, db)

    return org.id


def get_product_id(payload: req_schemas.Mapping, db: Session):
    product = get_product_by_name_query(payload.product, db,
                                        raise_exception=False).first()

    if not product:
        product_payload = req_schemas.Product(name=payload.product)
        product = create_product(product_payload, db)

    return product.id


def get_sub_product_id(payload: req_schemas.Mapping, db: Session):

    sub_product = get_sub_product_by_name_query(payload.sub_product, db,
                                                raise_exception=False).first()

    if not sub_product:
        sub_product_payload = req_schemas.SubProduct(name=payload.sub_product)
        sub_product = create_sub_product(sub_product_payload, db)

    return sub_product.id


def construct_mapping_entry(mapping, org, product, sub_product):

    return {
        "id": mapping.id,
        "org_id": org.id,
        "org": org.name,
        "product_id": product.id,
        "product": product.name,
        "sub_product_id": sub_product.id,
        "sub_product": sub_product.name,
    }
