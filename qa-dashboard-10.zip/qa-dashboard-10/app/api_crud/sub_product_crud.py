from sqlalchemy.orm import Session

from app.db.queries import get_sub_product_by_name_query, \
    create_sub_product_query, get_sub_products_query, \
    get_sub_product_by_id_query, get_mapping_by_sub_product_id_query
from app.common.exceptions import DuplicateEntity, CannotDelete
from app.schemas import req_schemas


def create_sub_product(payload: req_schemas.SubProduct, db: Session):
    sub_product = get_sub_product_by_name_query(payload.name, db,
                                                raise_exception=False)
    if sub_product.first():
        raise DuplicateEntity(f"Duplicate Sub-Product name {payload.name}")

    return create_sub_product_query(payload, db)


def get_sub_products(db: Session):
    sub_products = get_sub_products_query(db).all()
    return {"count": len(sub_products), "products": sub_products}


def get_sub_product_by_id(sub_product_id: int, db: Session):
    return get_sub_product_by_id_query(sub_product_id, db).first()


def get_sub_product_by_name(sub_product_name: str, db: Session):
    return get_sub_product_by_name_query(sub_product_name, db).first()


def delete_sub_product(sub_product_id: int, db: Session):
    sub_product = get_sub_product_by_id_query(sub_product_id, db)
    sub_product_in_mapping = get_mapping_by_sub_product_id_query(
        sub_product.first().name, db, raise_exception=False)

    if sub_product_in_mapping.first():
        raise CannotDelete(f"Sub-Product with id {sub_product_id} "
                           f"cannot be deleted")
    sub_product.delete(synchronize_session=False)
    db.commit()

    return


def update_sub_product(sub_product_id: int, payload: req_schemas.SubProduct,
                       db: Session):
    sub_product = get_sub_product_by_id_query(sub_product_id, db)
    sub_product.update(payload.dict())
    db.commit()

    return sub_product.first()
