import copy
from sqlalchemy.orm import Session
from app.db.queries import get_suite_by_id_query, \
    find_duplicate_test_under_suite, create_testcase_query, \
    get_testcases_by_suite_id_query, get_testcase_by_id_query, \
    get_max_testcase_no_query, get_testcase_status_count_by_suite_id_query
from app.schemas import req_schemas


def create_testcase(suite_id: int, payload: req_schemas.TestCase,
                    overwrite: bool, db: Session):

    if overwrite:
        testcase_response = handle_overwrite(suite_id, payload, db)
        update_suite_based_on_test_case(suite_id, db)
    else:
        get_suite_by_id_query(suite_id, db)
        find_duplicate_test_under_suite(suite_id, payload, db)
        testcase_payload = {"suite_id": suite_id, **payload.dict()}
        testcase_response = create_testcase_query(testcase_payload, db)

    return testcase_response


def create_testcases(suite_id: int, payload: req_schemas.TestCases,
                     overwrite: bool, db: Session):

    get_suite_by_id_query(suite_id, db)
    testcases = []

    for test in payload.testcases:
        if overwrite:
            testcase_response = handle_overwrite(suite_id, test, db)
        else:
            find_duplicate_test_under_suite(suite_id, test, db)
            test_payload = {"suite_id": suite_id, **test.dict()}
            testcase_response = create_testcase_query(test_payload, db)

        entry = copy.deepcopy(testcase_response)
        testcases.append(entry)

    if overwrite:
        update_suite_based_on_test_case(suite_id, db)

    return {"count": len(testcases), "testcases": testcases}


def get_testcases(suite_id: int, db: Session):
    get_suite_by_id_query(suite_id, db)
    testcases = get_testcases_by_suite_id_query(suite_id, db).all()
    return {"count": len(testcases), "testcases": testcases}


def get_testcase(suite_id: int, testcase_id: int, db: Session):
    get_suite_by_id_query(suite_id, db)
    return get_testcase_by_id_query(suite_id, testcase_id, db).first()


def delete_testcases(suite_id: int, db: Session):
    get_suite_by_id_query(suite_id, db)
    testcases = get_testcases_by_suite_id_query(suite_id, db)

    testcases.delete(synchronize_session=False)
    db.commit()

    return


def delete_testcase(suite_id: int, testcase_id: int, db: Session):
    get_suite_by_id_query(suite_id, db)
    testcase = get_testcase_by_id_query(suite_id, testcase_id, db)

    testcase.delete(synchronize_session=False)
    db.commit()

    return


def update_testcase(suite_id: int, testcase_id: int,
                    payload: req_schemas.TestCases, db: Session):
    get_suite_by_id_query(suite_id, db)
    testcase = get_testcase_by_id_query(suite_id, testcase_id, db)
    testcase.update(payload.dict())
    db.commit()

    return testcase.first()


def handle_overwrite(suite_id, payload, db: Session):

    suite = get_suite_by_id_query(suite_id, db)
    testcase_entry = find_duplicate_test_under_suite(suite_id, payload, db,
                                                     False).first()

    if testcase_entry:
        testcase_update = {"status": payload.status,
                           "duration": payload.duration,
                           "message": payload.message
                           }
        testcase = get_testcase_by_id_query(suite_id, testcase_entry.id,
                                            db)
        testcase.update(testcase_update)
        db.commit()

        testcase_response = testcase.first()
    else:
        # Create an New Entry in the test case table with testno as
        # auto calculated
        test_no = 1
        max_entry = get_max_testcase_no_query(suite_id, db).first()[0]
        if max_entry:
            test_no = max_entry + 1

        payload.testno = test_no
        testcase_payload = {"suite_id": suite_id, **payload.dict()}
        testcase_response = create_testcase_query(testcase_payload, db)

    # return Update Test Case entry payload
    return testcase_response


def update_suite_based_on_test_case(suite_id, db):

    suite = get_suite_by_id_query(suite_id, db)

    # Get the passed/failed/skipped/total count and update the count and
    # suite status
    suite_payload = {"passed": 0,
                     "failed": 0,
                     "skipped": 0,
                     "total": 0,
                     "status": "passed"
                     }
    status_counts = get_testcase_status_count_by_suite_id_query(suite_id,
                                                                db).all()
    for status_count in status_counts:
        status, count = status_count
        suite_payload[status.lower()] = count
        suite_payload["total"] += count

    if suite_payload["failed"] > 0:
        suite_payload["status"] = "failed"
    elif suite_payload["skipped"] > 0:
        suite_payload["status"] = "skipped"

    # Update the suite table
    suite.update(suite_payload)
    db.commit()
