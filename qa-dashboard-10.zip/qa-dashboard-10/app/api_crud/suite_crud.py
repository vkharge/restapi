from sqlalchemy.orm import Session

from app.db.queries import get_org_by_name_query, get_product_by_name_query, \
    get_sub_product_by_name_query, get_test_type_by_name_query, \
    get_environment_by_name_query, get_mapping_by_all_ids_query, \
    get_suite_mapping_by_all_cols_query, create_suite_mapping_query, \
    create_suite_query, get_suite_data_query, get_suite_by_id_query, \
    get_testcases_by_suite_id_query, get_suite_data_by_id_query, \
    get_suite_by_filters_query
from app.common.exceptions import NotFound, CannotDelete
from app.schemas import req_schemas
from app.schemas.req_schemas import MappingID
from datetime import datetime


def create_suite(payload: req_schemas.Suite, overwrite: bool, db: Session):
    org, product, sub_product, environment, test_type =\
        validate_parameters(payload, db)

    mapping_payload = MappingID(org_id=org.id, product_id=product.id,
                                sub_product_id=sub_product.id)
    mapping = get_mapping_by_all_ids_query(mapping_payload, db).first()
    if not mapping:
        message = f"Mapping entry not found for org: {payload.org}, " \
                  f"product: {payload.product}, " \
                  f"sub_product: {payload.sub_product}"
        raise NotFound(message)

    payload.created = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')

    suite_mapping_id = insert_suite_mapping_parameters(payload, mapping.id, db)

    if overwrite:
        query_filters = {
            "suite_mapping_id": suite_mapping_id,
            "build": payload.build
        }
        data_filters = ["table"]

        suite_entry = get_suite_by_filters_query(data_filters, query_filters,
                                                 db, raise_exception=False)\
            .first()

        if suite_entry:
            suite_id = suite_entry.id
            return update_suite_payload(payload, suite_mapping_id, suite_id)

    suite_payload = construct_suite_payload(payload, suite_mapping_id)
    suite = create_suite_query(suite_payload, db)

    return update_suite_payload(payload, suite_mapping_id, suite.id)


def get_suites(db: Session):

    suites = get_suite_data_query(db).all()

    results = []
    for suite in suites:
        result = construct_response(suite)
        results.append(result)

    return {"count": len(results), "suites": results}


def get_suite(suite_id: int, db: Session):
    suite_run = get_suite_data_by_id_query(suite_id, db).first()
    return construct_response(suite_run)


def delete_suite(suite_id: int, db: Session):
    suite = get_suite_by_id_query(suite_id, db)
    testcases = get_testcases_by_suite_id_query(suite_id, db)

    if testcases.first():
        raise CannotDelete(f"Suite id {suite_id} have test cases associated "
                           f"with it. Please delete the associated testcase "
                           f"first.")

    suite.delete(synchronize_session=False)
    db.commit()

    return


def update_suite(suite_id: int, payload: req_schemas.Suite, db: Session):

    suite = get_suite_by_id_query(suite_id, db)

    org, product, sub_product, environment, test_type =\
        validate_parameters(payload, db)

    mapping_payload = MappingID(org_id=org.id, product_id=product.id,
                                sub_product_id=sub_product.id)
    mapping = get_mapping_by_all_ids_query(mapping_payload, db).first()
    if not mapping:
        message = f"Mapping entry not found for org: {payload.org}, " \
                  f"product: {payload.product}, " \
                  f"sub_product: {payload.sub_product}"
        raise NotFound(message)

    suite_mapping_id = insert_suite_mapping_parameters(payload, mapping.id, db)
    suite_payload = construct_suite_payload(payload, suite_mapping_id)

    suite.update(suite_payload)
    db.commit()

    return update_suite_payload(payload, suite_mapping_id, suite_id)


def validate_parameters(payload: req_schemas.Suite, db: Session):

    # Validate Org
    org = get_org_by_name_query(payload.org, db).first()

    # Validate Product
    product = get_product_by_name_query(payload.product, db).first()

    # Validate SubProduct
    sub_product = get_sub_product_by_name_query(payload.sub_product, db)\
        .first()

    # Validate TestType
    test_type = get_test_type_by_name_query(payload.test_type, db).first()

    # Validate Environment
    environment = get_environment_by_name_query(payload.environment, db)\
        .first()

    return org, product, sub_product, environment, test_type


def insert_suite_mapping_parameters(payload: req_schemas.Suite,
                                    mapping_id: int, db: Session):

    suite_mapping = get_suite_mapping_by_all_cols_query(
        payload, mapping_id, db).first()

    if not suite_mapping:
        payload = {
            "mapping_id": mapping_id,
            "environment": payload.environment,
            "test_type": payload.test_type,
            "release": payload.release,
            "branch": "main",
            "suite": payload.suite
        }
        suite_mapping = create_suite_mapping_query(payload, db)

    return suite_mapping.id


def construct_suite_payload(payload: req_schemas.Suite, suite_mapping_id: int):

    payload = {**payload.dict()}
    payload.pop("org")
    payload.pop("product")
    payload.pop("sub_product")
    payload.pop("environment")
    payload.pop("test_type")
    payload.pop("release")
    payload.pop("suite")
    payload["suite_mapping_id"] = suite_mapping_id

    return payload


def update_suite_payload(payload: req_schemas.Suite, suite_mapping_id: int,
                         suite_id: int):

    updated_payload = {
        "id": suite_id,
        "suite_mapping_id": suite_mapping_id,
        **payload.dict()
    }

    return updated_payload


def construct_response(suite_data):
    suite, suite_mapping, org, product, sub_product = suite_data

    result = {
        "id": suite.id,
        "org": org.name,
        "product": product.name,
        "sub_product": sub_product.name,
        "test_type": suite_mapping.test_type,
        "environment": suite_mapping.environment,
        "release": suite_mapping.release,
        "branch": suite.branch,
        "suite": suite_mapping.suite,
        "build": suite.build,
        "total": suite.total,
        "passed": suite.passed,
        "failed": suite.failed,
        "skipped": suite.skipped,
        "status": suite.status,
        "report_url": suite.report_url,
        "console_url": suite.console_url,
        "log_url": suite.log_url,
        "duration": suite.duration,
        "infra": suite.infra,
        "created": suite.created
    }

    return result
