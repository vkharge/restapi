from sqlalchemy.orm import Session

from app.db.queries import get_suite_mappings_query, \
    get_suite_mapping_by_id_query


def get_suite_mappings(db: Session):
    suite_mappings = get_suite_mappings_query(db).all()
    return {"count": len(suite_mappings), "suite_mappings": suite_mappings}


def get_suite_mapping(suite_mapping_id: int, db: Session):
    return get_suite_mapping_by_id_query(suite_mapping_id, db).first()
