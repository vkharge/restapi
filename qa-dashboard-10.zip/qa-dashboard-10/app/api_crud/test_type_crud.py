from sqlalchemy.orm import Session

from app.db.queries import get_test_type_by_name_query, \
    create_test_type_query, get_test_types_query, get_test_type_by_id_query, \
    get_suite_mapping_by_test_type_query
from app.common.exceptions import DuplicateEntity, CannotDelete
from app.schemas import req_schemas


def create_test_type(payload: req_schemas.TestType, db: Session):
    test_type = get_test_type_by_name_query(payload.name, db,
                                            raise_exception=False)
    if test_type.first():
        raise DuplicateEntity(f"Duplicate TestType name {payload.name}")

    return create_test_type_query(payload, db)


def get_test_types(db: Session):
    test_types = get_test_types_query(db).all()
    return {"count": len(test_types), "test_types": test_types}


def get_test_type_by_id(test_type_id: int, db: Session):
    return get_test_type_by_id_query(test_type_id, db).first()


def get_test_type_by_name(test_type_name: str, db: Session):
    return get_test_type_by_name_query(test_type_name, db).first()


def delete_test_type(test_type_id: int, db: Session):
    test_type = get_test_type_by_id_query(test_type_id, db)
    test_type_in_mapping = get_suite_mapping_by_test_type_query(
        test_type.first().name, db, raise_exception=False)

    if test_type_in_mapping.first():
        raise CannotDelete(f"Test type with id {test_type_id} "
                           f"cannot be deleted")
    test_type.delete(synchronize_session=False)
    db.commit()

    return


def update_test_type(test_type_id: int, payload: req_schemas.TestType,
                     db: Session):
    test_type = get_test_type_by_id_query(test_type_id, db)
    test_type.update(payload.dict())
    db.commit()

    return test_type.first()
