import argparse
import os
import json
from dashboard import ReportServer, parse_firebase_log, download_from_bucket
from pathlib import Path
import traceback
import subprocess


def get_firebase_android_device_list():
    out = subprocess.run(
        ["gcloud", "firebase", "test", "android", "models", "list", "--format",
         "json"], stdout=subprocess.PIPE, text=True)

    device_json = {}
    for item in json.loads(out.stdout):
        device_json[item["codename"]] = item

    return device_json


def get_firebase_ios_device_list():
    out = subprocess.run(
        ["gcloud", "firebase", "test", "ios", "models", "list", "--format",
         "json"], stdout=subprocess.PIPE, text=True)

    device_json = {}
    for item in json.loads(out.stdout):
        device_json[item["id"]] = item

    return device_json


def get_firebase_device_list():
    android_devices = get_firebase_android_device_list()
    ios_devices = get_firebase_ios_device_list()

    devices = {**android_devices, **ios_devices}

    return devices


def save_to_json_file(file, data):
    with open(file, 'w') as f:
        json.dump(data, f, indent=4)


def delete_file(file):
    fo = Path(file)
    if fo.exists():
        os.remove(file)


#SERVER = "http://syd-dolby-io-qa.apac-eng.dolby.net"
SERVER = "http://127.0.0.1:8080"
TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJyZWFkb25seXVzZXIifQ" \
        ".v_6EWKcDWe6k40HxjGG6tN-69Ruw5BrYUcl_nvjRSEo"

try:
    parser = argparse.ArgumentParser()
    parser.add_argument("--org", default="DOLBY.IO", dest="org")
    parser.add_argument("--product", dest="product", required=True)
    parser.add_argument("--sub-product", dest="sub_product", required=True)
    parser.add_argument("--test-type", dest="test_type", required=True)
    parser.add_argument("--environment", dest="environment", required=True)
    parser.add_argument("--suite-name", default="", dest="suite_name")
    parser.add_argument("--infra", default="", dest="infra")

    parser.add_argument("--release", default=os.environ.get(
        "CI_MERGE_REQUEST_TARGET_BRANCH_NAME"), dest="release")

    parser.add_argument("--branch",
                        default=os.environ.get("CI_COMMIT_BRANCH"),
                        dest="branch")

    parser.add_argument("--build-number",
                        default=os.environ.get("CI_COMMIT_SHORT_SHA"),
                        dest="build_number")

    parser.add_argument("--build-url",
                        default=os.environ.get("CI_PIPELINE_URL"),
                        dest="build_url")

    parser.add_argument("--junit-xml", default=None, dest="junit_xml")
    parser.add_argument("--firebase-log", default=None, dest="firebase_log")

    parser.add_argument("--report-url", default=None, dest="report_url")
    parser.add_argument("--job-url", default=None, dest="job_url")
    parser.add_argument("--log-url", default=None, dest="log_url")
    parser.add_argument("--gcloud-cred-file", default=None,
                        dest="gcloud_cred_file")
    parser.add_argument("--option", default="suites", dest="option")
    parser.add_argument("--overwrite", default=False, dest="overwrite")

    args = parser.parse_args()

    if args.release is None or args.release == "":
        args.release = os.environ.get("CI_DEFAULT_BRANCH")
    else:
        args.release = "private"

    if args.branch is None or args.branch == "":
        args.branch = os.environ.get("CI_MERGE_REQUEST_SOURCE_BRANCH_NAME")

    if args.suite_name is None or args.suite_name == "":
        args.suite_name = os.environ.get("CI_JOB_NAME")

    if args.job_url is None:
        args.job_url = os.environ.get("CI_JOB_URL")

    execution = {
        "org": args.org,
        "product": args.product,
        "sub_product": args.sub_product,
        "test_type": args.test_type,
        "environment": args.environment,
        "suite": args.suite_name,

        "release": args.release,
        "branch": args.branch,
        "build": args.build_number,

        "console_url": args.job_url,
        "infra": args.infra
    }

    server = ReportServer(SERVER, TOKEN)

    if args.firebase_log:

        if args.gcloud_cred_file is None:
            filename = "gcloud_service-account.json"
            save_to_json_file(filename, os.environ['FB_SERVICE_ACCOUNT'])
            args.gcloud_cred_file = filename

        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = args.gcloud_cred_file
        report = parse_firebase_log(args.firebase_log)

        devices = get_firebase_device_list()

        for test in report["tests"]:

            if report["type"] == "flank":
                src = f"{report['bucket_path']}/matrix_0/" \
                      f"{test['axis']}-test_results_merged.xml"
                execution["log_url"] = report['bucket']
            else:
                src = f"{report['bucket_path']}/{test['axis']}" \
                      f"/test_result_1.xml"
                execution["log_url"] = f"{report['bucket']}/{test['axis']}"

            device_code = test['axis'].split("-")[0]
            device = devices.get(device_code, None)
            if device is None:
                suite_name = test['axis']
            else:
                suite_name = device["manufacturer"] + "-"\
                             + device["name"].replace(" ", "-")
                suite_name = test['axis'].replace(device_code, suite_name)

            execution["suite"] = suite_name

            dst = f"{test['axis']}_junit.xml"
            download_from_bucket(report["bucket_name"], src, dst)
            execution["report_url"] = test["report"]
            server.push_results_using_junit(execution, dst, args.option, args.overwrite)

    elif args.junit_xml:
        if args.report_url is not None:
            execution["report_url"] = args.report_url
        if args.log_url is not None:
            execution["log_url"] = args.log_url

        server.push_results_using_junit(execution, args.junit_xml, args.option, args.overwrite)
except Exception as e:
    print("ERROR: " + str(e))
    print("Traceback: " + str(traceback.format_exc()))
    exit(1)
exit(0)
