import argparse
import os
from dashboard import ReportServer
import traceback


#SERVER = "http://syd-dolby-io-qa.apac-eng.dolby.net"
SERVER = "http://127.0.0.1:8080"
TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJyZWFkb25seXVzZXIifQ" \
        ".v_6EWKcDWe6k40HxjGG6tN-69Ruw5BrYUcl_nvjRSEo"

try:
    parser = argparse.ArgumentParser()
    parser.add_argument("--org", default="DOLBY.IO", dest="org")
    parser.add_argument("--product", dest="product", required=True)
    parser.add_argument("--sub-product", dest="sub_product", required=True)
    parser.add_argument("--test-type", dest="test_type", required=True)
    parser.add_argument("--environment", dest="environment", required=True)
    parser.add_argument("--suite-name", default="", dest="suite_name")
    parser.add_argument("--infra", default="", dest="infra")

    parser.add_argument("--release", default=os.environ.get(
        "CI_COMMIT_BRANCH"), dest="release")

    parser.add_argument("--branch",
                        default=os.environ.get("CI_COMMIT_BRANCH"),
                        dest="branch")

    parser.add_argument("--build-number",
                        default=os.environ.get("CI_COMMIT_SHORT_SHA"),
                        dest="build_number")

    parser.add_argument("--build-url",
                        default=os.environ.get("CI_PIPELINE_URL"),
                        dest="build_url")

    parser.add_argument("--junit-xml", default=None, dest="junit_xml")

    parser.add_argument("--report-url", default=None, dest="report_url")
    parser.add_argument("--job-url", default=None, dest="job_url")
    parser.add_argument("--log-url", default=None, dest="log_url")

    parser.add_argument("--option", default="suites", dest="option")
    parser.add_argument("--overwrite", default=False, dest="overwrite")

    args = parser.parse_args()

    if "release/" in args.release or args.release == "develop":
        if args.release == "develop":
            args.release = "Transcode_develop"

        if args.suite_name is None or args.suite_name == "":
            args.suite_name = os.environ.get("CI_JOB_NAME")

        if args.job_url is None:
            args.job_url = os.environ.get("CI_JOB_URL")

        execution = {
            "org": args.org,
            "product": args.product,
            "sub_product": args.sub_product,
            "test_type": args.test_type,
            "environment": args.environment,
            "suite": args.suite_name,

            "release": args.release,
            "branch": args.branch,
            "build": args.build_number,

            "console_url": args.job_url,
            "infra": args.infra
        }

        if args.report_url is not None:
            execution["report_url"] = args.report_url
        if args.log_url is not None:
            execution["log_url"] = args.log_url

        server = ReportServer(SERVER, TOKEN)
        server.push_results_using_junit(execution, args.junit_xml, args.option, args.overwrite)
    else:
        raise RuntimeError(
            'Cannot push test results to QA-dashboard on a non-release or '
            'non-develop branch.')

except Exception as e:
    print("ERROR: " + str(e))
    print("Traceback: " + str(traceback.format_exc()))
    exit(1)
exit(0)
