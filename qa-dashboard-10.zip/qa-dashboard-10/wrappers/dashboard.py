import json
import requests
import xml.etree.ElementTree as ET
import copy
import re
from google.cloud import storage
from pprint import pprint


class JUnitParser:

    def __init__(self, file, option="suite"):
        if option not in ["suites", "suite"]:
            raise ValueError("Invalid option passed, valid options are ["
                             "'suites', 'suite']")

        self.file = file
        self.option = option
        self.root = None

    def parse(self):
        self.root = ET.parse(self.file).getroot()
        root_tag = self._check_root_element()

        suite_info = self._get_suites_info()
        results = self._get_test_suites_details(root_tag, suite_info)

        return results

    def _check_root_element(self):
        if not self.root.tag.strip() in ["testsuites", "testsuite"]:
            raise TypeError("Top level element is not a 'testsuite(s)'"
                            " but '{0}'".format(self.root.tag))

        return self.root.tag

    def _get_suites_info(self):
        suites = {
            "name": self.root.attrib.get("name", ""),
            "tests": int(self.root.attrib.get("tests", 0)),
            "failures": int(self.root.attrib.get("failures", 0)),
            "errors": int(self.root.attrib.get("errors", 0)),
            "skipped": int(self.root.attrib.get("skipped", 0)),
            "time": float(self.root.attrib.get("time", 0)),
        }

        return suites

    def _get_test_suites_details(self, root_tag, suite_info):

        results = copy.deepcopy(suite_info)

        if root_tag == "testsuites":
            testsuites = self.root.findall("testsuite")
            if not testsuites:
                raise TypeError("'suites' element must contain at least "
                                "one 'suite'.")
        else:
            testsuites = [self.root]

        testno = 1
        timestamp = None
        testcases_all = []
        suites = []

        total_tests = 0
        total_errors = 0
        total_failures = 0
        total_skipped = 0
        total_duration = 0.0
        final_status = []

        for testsuite in testsuites:
            suite = self._get_suite_info(testsuite)
            total_tests += suite["tests"]
            total_errors += suite["errors"]
            total_failures += suite["failures"]
            total_skipped += suite["skipped"]
            total_duration += suite["time"]
            final_status.append(suite["status"])

            if timestamp is None:
                timestamp = suite["timestamp"]

            if self.option == "suite":
                testno = 1

            testcases = []
            for test in testsuite.findall(".//testcase"):
                testcase = self._get_testcase_info(test)
                testcase["testno"] = testno
                testno += 1

                testcases.append(testcase)

            if self.option == "suites":
                testcases_all.extend(testcases)
            else:
                suite["testcases"] = testcases
                suites.append(suite)

        if self.option == "suites":
            results["testcases"] = testcases_all
        else:
            results["suites"] = suites

        results["timestamp"] = timestamp

        if results["tests"] == 0:
            results["tests"] = total_tests
        if results["errors"] == 0:
            results["errors"] = total_errors
        if results["failures"] == 0:
            results["failures"] = total_failures
        if results["skipped"] == 0:
            results["skipped"] = total_skipped
        if results["time"] == 0:
            results["time"] = total_duration

        results["failed"] = results["failures"] + results["errors"]
        results["passed"] = results["tests"] - results["failed"] - results[
            "skipped"]

        if "FAILED" in final_status:
            results["status"] = "FAILED"
        elif "SKIPPED" in final_status:
            results["status"] = "SKIPPED"
        else:
            results["status"] = "PASSED"

        return results

    @staticmethod
    def _get_suite_info(testsuite):
        suite = {
            "name": testsuite.attrib.get("name", ""),
            "tests": int(testsuite.attrib.get("tests", 0)),
            "errors": int(testsuite.attrib.get("errors", 0)),
            "failures": int(testsuite.attrib.get("failures", 0)),
            "skipped": int(testsuite.attrib.get("skipped", 0)),
            "time": round(float(testsuite.attrib.get("time", 0.0)), 3),
            "timestamp": testsuite.attrib.get("timestamp", ""),
        }

        suite["failed"] = suite["failures"] + suite["errors"]
        suite["passed"] = suite["tests"] - suite["failed"] - suite["skipped"]

        if suite["skipped"] > 0:
            suite["status"] = "SKIPPED"
        elif suite["failed"] > 0:
            suite["status"] = "FAILED"
        else:
            suite["status"] = "PASSED"

        return suite

    def _get_testcase_info(self, case):
        status, message = self._get_test_status_info(case)

        test = {
            "testclass": case.attrib.get("classname", ""),
            "testname": case.attrib.get("name", ""),
            "status": status,
            "duration": round(float(case.attrib.get("time", 0.0)), 3),
            "message": message
        }

        return test

    @staticmethod
    def _get_test_status_info(case):
        test_status = "PASSED"
        test_message = ""

        if list(case):
            if case[0].tag == "failure":
                test_status = "FAILED"
            elif case[0].tag == "error":
                test_status = "SKIPPED"
            elif case[0].tag == "skipped":
                test_status = "SKIPPED"

            for obj in case:
                test_message += obj.attrib.get("message", "")
                if obj.text:
                    test_message += obj.text

        return test_status, test_message


class RestClient:
    API_KEY_NAME = "access_token"

    def __init__(self, server, token):
        self.server = server
        self.token = token

    def get(self, endpoint, headers):
        url = f"{self.server}{endpoint}"
        headers[self.API_KEY_NAME] = self.token
        print(url)
        response = requests.get(url, headers=headers, verify=False)

        return response

    def post(self, endpoint, data, headers, params=None):
        url = f"{self.server}{endpoint}"
        headers[self.API_KEY_NAME] = self.token
        if params is None:
            params = {}
        print(url)
        response = requests.post(url, data=json.dumps(data),
                                 params=params, headers=headers, verify=False)

        return response

    def delete(self, endpoint, headers):
        url = f"{self.server}{endpoint}"
        headers[self.API_KEY_NAME] = self.token
        print(url)
        response = requests.delete(url, headers=headers, verify=False)

        return response

    def put(self, endpoint, data, headers):
        url = f"{self.server}{endpoint}"
        headers[self.API_KEY_NAME] = self.token
        print(url)
        response = requests.put(url, data=json.dumps(data), headers=headers,
                                verify=False)

        return response


class ReportAPI(RestClient):
    _version = "/api/v1"
    _suites = f"/suites"
    _testcases = f"/testcases"
    _mappings = f"/mappings"
    _environments = f"/environments"
    _test_types = f"/test-types"
    _headers = {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache'
    }

    def __init__(self, server, token):
        self.server = server
        self.token = token
        super().__init__(server, token)

    @property
    def server(self):
        return self.__server

    @server.setter
    def server(self, value):
        if value is None or value.strip() == "":
            raise ValueError("Server name cannot be empty")
        self.__server = value

    @property
    def token(self):
        return self.__token

    @token.setter
    def token(self, value):
        if value is None or value.strip() == "":
            raise ValueError("Token cannot be empty")
        self.__token = value

    def get_suites(self):
        endpoint = f"{self._version}{self._suites}"
        return self.get(endpoint=endpoint, headers=self._headers)

    def get_suite(self, suite_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}"
        return self.get(endpoint=endpoint, headers=self._headers)

    def create_suite(self, data, overwrite=False):
        endpoint = f"{self._version}{self._suites}"
        params = {"overwrite": overwrite}
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers, params=params)

    def delete_suite(self, suite_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}"
        return self.delete(endpoint=endpoint, headers=self._headers)

    def update_suite(self, suite_id, data):
        endpoint = f"{self._version}{self._suites}/{suite_id}"
        return self.put(endpoint=endpoint, data=data,
                        headers=self._headers)

    def get_testcases(self, suite_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}{self._testcases}"
        print(endpoint)
        return self.get(endpoint=endpoint, headers=self._headers)

    def get_testcase(self, suite_id, testcase_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}/{testcase_id}"
        print(endpoint)
        return self.get(endpoint=endpoint, headers=self._headers)

    def create_testcase(self, suite_id, data, overwrite=False):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}"
        params = {"overwrite": overwrite}
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers, params=params)

    def create_testcases(self, suite_id, data, overwrite=False):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}/bulk"
        params = {"overwrite": overwrite}
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers, params=params)

    def delete_testcases(self, suite_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}"
        print(endpoint)
        return self.delete(endpoint=endpoint, headers=self._headers)

    def delete_testcase(self, suite_id, testcase_id):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}/{testcase_id}"
        print(endpoint)
        return self.delete(endpoint=endpoint, headers=self._headers)

    def update_testcase(self, suite_id, testcase_id, data):
        endpoint = f"{self._version}{self._suites}/{suite_id}" \
                   f"{self._testcases}/{testcase_id}"
        print(endpoint)
        return self.put(endpoint=endpoint, data=data, headers=self._headers)

    def create_mapping(self, data):
        endpoint = f"{self._version}{self._mappings}"
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers)

    def create_environment(self, data):
        endpoint = f"{self._version}{self._environments}"
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers)

    def create_test_type(self, data):
        endpoint = f"{self._version}{self._test_types}"
        print(endpoint)
        return self.post(endpoint=endpoint, data=data,
                         headers=self._headers)


class ReportServer:
    def __init__(self, server, token):
        self.server = server
        self.token = token
        self._client = ReportAPI(server, token)

    def push_results_using_junit(self, suite, junit_xml, option="suites", overwrite=False):
        parser = JUnitParser(file=junit_xml, option=option)
        junit_json = parser.parse()

        if option == "suites":
            suite = self.__populate_suite_data(suite, junit_json)
            print(suite)
            suite_res = self.push_suite(suite, overwrite=overwrite)

            suite_id = suite_res.json()["id"]
            testcases = {"testcases": junit_json["testcases"]}
            print(testcases)
            testcases_res = self.push_testcases(suite_id, testcases, overwrite=overwrite)
        else:
            for item in junit_json["suites"]:
                suite = self.__populate_suite_data(suite, item)
                if item["name"].strip() != "":
                    suite["suite"] = item["name"]
                print(suite)
                suite_res = self.push_suite(suite, overwrite=overwrite)

                suite_id = suite_res.json()["id"]
                testcases = {"testcases": item["testcases"]}
                print(testcases)
                testcases_res = self.push_testcases(suite_id, testcases, overwrite=overwrite)

    def push_suite(self, suite, overwrite=False):
        response = self._client.create_suite(suite, overwrite)
        print(f"{response.status_code} : {response.reason}")
        print(f"{response.json()}")
        if response.status_code != 201:
            raise Exception(f"Response Code: {response.status_code}"
                            f" {response.reason}\n"
                            f"Response Body:\n{response.json()}")
        return response

    def push_testcases(self, suite_id, testcases, overwrite=False):
        response = self._client.create_testcases(suite_id, testcases, overwrite)
        print(f"{response.status_code} : {response.reason}")
        print(f"{response.json()}")
        if response.status_code != 201:
            raise Exception(f"Response Code: {response.status_code}"
                            f" {response.reason}\n"
                            f"Response Body:\n{response.json()}")
            return response

    def push_testcase(self, suite_id, testcase, overwrite=False):
        response = self._client.create_testcase(suite_id, testcase, overwrite)
        print(f"{response.status_code} : {response.reason}")
        print(f"{response.json()}")
        if response.status_code != 201:
            raise Exception(f"Response Code: {response.status_code}"
                            f" {response.reason}\n"
                            f"Response Body:\n{response.json()}")
        return response

    def parse_junit_xml(self, junit_xml):
        parser = JUnitParser(file=junit_xml, option="suite")
        return parser.parse()

    @staticmethod
    def __populate_suite_data(suite, data):
        suite["total"] = data["tests"]
        suite["passed"] = data["passed"]
        suite["failed"] = data["failed"]
        suite["skipped"] = data["skipped"]
        suite["status"] = data["status"]
        suite["duration"] = data["time"]
        # suite["created"] = data["timestamp"]

        return suite


def parse_firebase_log(filename):

    with open(filename) as fo:
        contents = fo.readlines()

    result = {"type": ""}
    tests = []
    matrix = {}

    for line in contents:

        if "GCS bucket at" in line:
            match = re.search(r"\[(.*)\]", line)
            bucket = match.group(1).strip()

            result["bucket"] = bucket[0:-1] if bucket.endswith("/") else bucket
            bucket_dirs = result["bucket"].split("/")[-2:]
            result["bucket_name"] = bucket_dirs[0]
            result["bucket_path"] = bucket_dirs[1]

        if "More details are available at " in line:
            match = re.search(r"\[(.*)\]", line)
            report = match.group(1).strip()
            matrix["matrix"] = report

        match = re.search(r" (matrix-.*) (https://.*)", line)
        if match:
            key = match.group(1).strip()
            value = match.group(2).strip()
            matrix[key] = value

        if " │ " in line and not re.search("TEST.AXIS.VALUE", line):
            row = line.split("│")
            if result["type"] == "":
                result["type"] = "firebase" if len(row) == 5 else "flank"

            status = row[1].strip().lower()
            if "failed" in status or "failure" in status:
                outcome = "FAILED"
            elif "passed" in status or "success" in status:
                outcome = "PASSED"
            elif "flaky" in status:
                outcome = "FLAKY"
            else:
                outcome = status

            test = {
                "axis": row[-3].strip(),
                "details": row[-2].strip(),
                "outcome": outcome
            }

            if result["type"] == "flank":
                matrix_id = row[2].strip()
                test["matrix_id"] = matrix_id
                test["report"] = matrix[matrix_id]
            else:
                test["report"] = matrix["matrix"]
            tests.append(test)

    result["tests"] = tests
    pprint(result)
    return result


def download_from_bucket(bucket_name, source_name, destination_file_name):
    """Downloads a blob from the bucket.
    https://cloud.google.com/storage/docs/downloading-objects#code-samples
    """

    storage_client = storage.Client()

    bucket = storage_client.bucket(bucket_name)

    blob = bucket.blob(source_name)
    blob.download_to_filename(destination_file_name)

    print(
        "Downloaded storage object {} from bucket {} to local file {}.".format(
            source_name, bucket_name, destination_file_name
        )
    )
