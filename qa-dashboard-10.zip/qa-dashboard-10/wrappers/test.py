import argparse
import os
from dashboard import parse_firebase_log
import traceback
import csv

#file = "/Users/vkhar/vkharge/repo/dolby-io-sdk/groot/firebase-test-scheduled.txt"
transcode_unit = "xml/junit_unit_transcode.xml"
transcode_api = "xml/junit_webapi_transcode.xml"

#results = parse_firebase_log(file)
#import pprint
#pprint.pprint(results)
#FIREBASE_LOG = ""
#GCLOUD_CRED = "service-account.json"

ORG = "DOLBY.IO"
PRODUCT = "MAPI"
SUBPRODUCT = "TRANSCODE"
ENV = "DEV"
TEST_TYPE = "System"
SUITE_NAME = "API-Test-System"
INFRA = "AWS"


junit_script = f'python push_results_to_dashboard.py --org {ORG} --product {PRODUCT} --sub-product {SUBPRODUCT} --test-type {TEST_TYPE} --environment {ENV} --suite-name {SUITE_NAME} --release "1.1.0" --branch "master" --build-number "111" --junit-xml {transcode_api} --infra {INFRA} --overwrite True'
print(junit_script)

#script = f'python scripts/push_results_to_dashboard.py --org {ORG} --product {PRODUCT} --sub-product {SUBPRODUCT} --test-type {TEST_TYPE} --environment {ENV} --suite-name {SUITE_NAME} --firebase-log {FIREBASE_LOG} --infra {INFRA} --gcloud-cred-file {GCLOUD_CRED}'

#print(script)
#python scripts/push_results_to_dashboard.py --org $ORG --product $PRODUCT --sub-product $SUBPRODUCT --test-type "Integration" --environment $ENV --suite-name "IntegrationTest" --firebase-log $FIREBASE_LOG --infra "Firebase" --gcloud-cred-file service-account.json


