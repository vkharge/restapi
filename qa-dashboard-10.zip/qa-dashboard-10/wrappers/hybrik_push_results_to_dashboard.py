import argparse
import os
from dashboard import ReportServer
import traceback
import csv


def read_csv(csv_file_path):

    if not os.path.isfile(csv_file_path):
        raise Exception("File Not Found: " + csv_file_path)

    json_array = []

    # read csv file
    with open(csv_file_path, encoding='utf-8') as csvf:

        # load csv file data using csv library's dictionary reader
        csv_reader = csv.DictReader(csvf)

        # convert each csv row into python dict
        for row in csv_reader:
            # add this python dict to json array
            json_array.append(row)

    return json_array


def get_hybrik_suite_details(suite_json):
    test_cases = []
    suite_status = "PASSED"
    passed = 0
    failed = 0
    skipped = 0

    for index, test_result in enumerate(suite_json):
        test_name = test_result.get("TEST_NAME")
        test_status = test_result.get("TEST_RESULT", "").lower()
        if test_status in ["passed", "pass"]:
            test_status = "PASSED"
            passed += 1
        elif test_status in ["failed", "fail"]:
            test_status = "FAILED"
            suite_status = test_status
            failed += 1
        else:
            test_status = "SKIPPED"
            if suite_status != "FAILED":
                suite_status = test_status
            skipped += 1

        test = {"testno": index + 1,
                "testclass": "",
                "testname": test_name,
                "status": test_status,
                "message": ',\n\r'.join(
                    ['{}: {}'.format(key, value)
                     for key, value in test_result.items()
                     ])}

        test_cases.append(test)

    suite = {"total": passed + failed + skipped,
             "passed": passed,
             "failed": failed,
             "skipped": skipped,
             "status": suite_status}

    return suite, test_cases


SERVER = "http://syd-dolby-io-qa.apac-eng.dolby.net"
TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJyZWFkb25seXVzZXIifQ" \
        ".v_6EWKcDWe6k40HxjGG6tN-69Ruw5BrYUcl_nvjRSEo"

try:
    parser = argparse.ArgumentParser()
    parser.add_argument("--org", default="DOLBY.IO", dest="org")
    parser.add_argument("--product", dest="product", required=True)
    parser.add_argument("--sub-product", dest="sub_product", required=True)
    parser.add_argument("--test-type", dest="test_type", required=True)
    parser.add_argument("--environment", dest="environment", required=True)

    parser.add_argument("--suite-name", dest="suite_name", required=True)
    parser.add_argument("--release", dest="release", required=True)
    parser.add_argument("--branch", dest="branch", required=True)

    parser.add_argument("--build-number",
                        default=os.environ.get("CI_COMMIT_SHORT_SHA", ""),
                        dest="build_number")
    parser.add_argument("--build-url",
                        default=os.environ.get("CI_PIPELINE_URL", ""),
                        dest="build_url")

    parser.add_argument("--csv", default=None, dest="csv_file")
    parser.add_argument("--report-url", default=None, dest="report_url")
    parser.add_argument("--job-url", default=None, dest="job_url")
    parser.add_argument("--log-url", default=None, dest="log_url")
    parser.add_argument("--infra", default="", dest="infra")

    args = parser.parse_args()

    if args.job_url is None:
        args.job_url = os.environ.get("CI_JOB_URL", "")

    execution = {
        "org": args.org,
        "product": args.product,
        "sub_product": args.sub_product,
        "test_type": args.test_type,
        "environment": args.environment,
        "suite": args.suite_name,

        "release": args.release,
        "branch": args.branch,
        "build": args.build_number,

        "console_url": args.job_url,
        "infra": args.infra
    }

    server = ReportServer(SERVER, TOKEN)

    if args.csv_file:
        if args.report_url is not None:
            execution["report_url"] = args.report_url
        if args.log_url is not None:
            execution["log_url"] = args.log_url

        suite_data = read_csv(args.csv_file)
        if len(suite_data) == 0:
            raise Exception("CSV file does not contain any data")

        suite, test_cases = get_hybrik_suite_details(suite_data)

        suite_execution = {**execution, **suite}
        response = server.push_suite(suite_execution, overwrite=True)
        suite_test_cases = {
            "testcases": test_cases
        }
        server.push_testcases(response.json()["id"], suite_test_cases,
                              overwrite=True)
except Exception as e:
    print("ERROR: " + str(e))
    print("Traceback: " + str(traceback.format_exc()))
    exit(1)
exit(0)
